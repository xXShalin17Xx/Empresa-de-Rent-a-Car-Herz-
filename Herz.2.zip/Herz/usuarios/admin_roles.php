<?php
include("../principal/config.php");
session_start();

// Verificar si el usuario logueado es Admin
if (!isset($_SESSION['cliente_id']) || !isset($_SESSION['cliente_rol']) || $_SESSION['cliente_rol'] != 5) {
    header("Location: ../Sesion/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'] ?? null;
    $newRole = $_POST['role_id'] ?? null;
    $newSucursal = $_POST['sucursal_id'] ?? null;

    if ($userId && $newRole && $newSucursal) {

        // Validar que el rol exista
        $stmt = $conn->prepare("SELECT id FROM Roles WHERE id = ?");
        $stmt->bind_param("i", $newRole);
        $stmt->execute();
        $roleExists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        // Validar que la sucursal exista
        $stmt = $conn->prepare("SELECT id FROM Sucursales WHERE id = ?");
        $stmt->bind_param("i", $newSucursal);
        $stmt->execute();
        $sucursalExists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($roleExists && $sucursalExists) {
            // Actualizar el rol y la sucursal del usuario
            $stmt = $conn->prepare("UPDATE Clientes SET idRol = ?, idSucursal = ? WHERE id = ?");
            $stmt->bind_param("iii", $newRole, $newSucursal, $userId);

            if ($stmt->execute()) {
                $message = "Rol y sucursal actualizados correctamente.";
            } else {
                $error = "Error al actualizar los datos.";
            }
            $stmt->close();
        } else {
            $error = "Rol o sucursal inválidos.";
        }
    } else {
        $error = "Faltan datos para actualizar.";
    }
}

// Obtener usuarios con su rol y sucursal actual
$users = $conn->query("
    SELECT c.id, c.nombre, c.email, r.nombre AS rol, s.nombre AS sucursal, c.idSucursal
    FROM Clientes c
    LEFT JOIN Roles r ON c.idRol = r.id
    LEFT JOIN Sucursales s ON c.idSucursal = s.id
    ORDER BY c.id ASC
");

// Obtener todos los roles y sucursales para los selects
$roles = $conn->query("SELECT id, nombre FROM Roles ORDER BY id ASC");
$sucursales = $conn->query("SELECT id, nombre FROM Sucursales ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administrar Roles y Sucursales - Panel Admin</title>
    <link rel="stylesheet" href="roles.css">
   
    
</head>
<body>

<header class="main-header">
    <a href="../usuarios/admin.php" class="logo">Herz</a>
    <h2>Panel de Administración de Roles y Sucursales</h2>
    <a href="../sesion/logout.php" style="color:white; text-decoration:none;">Cerrar sesión</a>
</header>
    

    <?php if (isset($message)) echo "<p class='message'>$message</p>"; ?>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol Actual</th>
            <th>Sucursal Actual</th>
            <th>Nuevo Rol</th>
            <th>Nueva Sucursal</th>
            <th>Acción</th>
        </tr>

        <?php while ($user = $users->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td><?= htmlspecialchars($user['nombre']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['rol'] ?? 'Sin rol') ?></td>
                <td><?= htmlspecialchars($user['sucursal'] ?? 'Sin sucursal') ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">

                        <select name="role_id" required>
                            <?php while ($role = $roles->fetch_assoc()): ?>
                                <option value="<?= $role['id'] ?>" <?= ($role['nombre'] == $user['rol']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($role['nombre']) ?>
                                </option>
                            <?php endwhile; ?>
                            <?php $roles->data_seek(0); // resetear cursor ?>
                        </select>
                </td>
                <td>
                        <select name="sucursal_id" required>
                            <?php while ($sucursal = $sucursales->fetch_assoc()): ?>
                                <option value="<?= $sucursal['id'] ?>" <?= ($sucursal['id'] == $user['idSucursal']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($sucursal['nombre']) ?>
                                </option>
                            <?php endwhile; ?>
                            <?php $sucursales->data_seek(0); // resetear cursor ?>
                        </select>
                </td>
                <td>
                        <button type="submit">Actualizar</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
