<?php
session_start();

$rolesPermitidos = [3, 5]; // 3 = Coordinador de Flota, 5 = Administrador

if (!isset($_SESSION['cliente_id']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../sesion/login.php");
    exit();
}

include("../principal/config.php");

$vehiculos = $conn->query("SELECT * FROM Vehiculos");

$mantenimientos = $conn->query("
    SELECT m.id, v.patente, m.tipo, m.estado, m.fecha
    FROM Mantenimiento m
    JOIN Vehiculos v ON m.idVehiculo = v.id
    WHERE m.estado = 'pendiente'
");

$reservas = $conn->query("
    SELECT r.id, c.nombre AS cliente, v.patente AS vehiculo, v.tipo AS tipoVehiculo, r.fechaInicio, r.fechaFin, r.estado
    FROM Reservas r
    LEFT JOIN Clientes c ON r.idCliente = c.id
    LEFT JOIN Vehiculos v ON r.idVehiculo = v.id
    ORDER BY r.fechaInicio ASC
");


// Contadores
$totalVehiculos = $conn->query("SELECT COUNT(*) AS total FROM Vehiculos")->fetch_assoc()['total'];
$totalMantenimientos = $conn->query("SELECT COUNT(*) AS total FROM Mantenimiento WHERE estado='pendiente'")->fetch_assoc()['total'];
$totalReservas = $conn->query("SELECT COUNT(*) AS total FROM Reservas WHERE estado IN ('pendiente', 'en curso')")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel - Coordinador de Flota</title>
    <link rel="stylesheet" href="all.css">
   <style>
        body { font-family: 'Segoe UI', sans-serif; margin:0; background:#f5f7f7; }
       .resumen { display:flex; gap:15px; }
        .card { flex:1; padding:15px; border-radius:8px; text-align:center; color:#fff; font-weight:600; }
        .card h3 { margin:0 0 10px; font-size:1.1rem; }
        .card p { margin:0; font-size:1.5rem; }
        .card.completado { background:#27ae60; }
        .card:not(.completado) { background:#e74c3c; }
        table { width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
        th, td { padding:10px 12px; border-bottom:1px solid #ddd; text-align:left; }
        th { background:#04926f; color:#fff; }
        tr:hover { background:#f0f8f6; }
        .accion { padding:6px 10px; background:#04926f; color:#fff; border:none; border-radius:6px; cursor:pointer; transition:0.2s; }
        .accion:hover { background:#02785d; transform:scale(1.05); }
        footer { text-align:center; padding:12px; background:#f5f7f7; border-top:1px solid #ddd; font-size:0.9rem; margin-top:20px; }
        .alerta { background:#f39c12; color:#fff; }
    </style>
</head>
<body>

<header class="main-header">
    <div class="left">
            <div class="logo">
                <img src="../img/logo.png" alt="Herz" class="logo-img">
            </div>
        </div>

    <div class="center"><h1>Coordinador de Flota</h1></div>
    <div class="right"></div>
</header>

<main>

    <section class="resumen">
        <div class="card">
            <h3>Vehículos</h3>
            <p><?= $totalVehiculos ?></p>
        </div>
        <div class="card completado">
            <h3>Mantenimientos Pendientes</h3>
            <p><?= $totalMantenimientos ?></p>
        </div>
        <div class="card alerta">
            <h3>Reservas Activas</h3>
            <p><?= $totalReservas ?></p>
        </div>
    </section>

    <section>
        <h2>Flota de Vehículos</h2>
        <table>
            <tr><th>ID</th><th>Patente</th><th>Modelo</th><th>Estado</th><th>Acciones</th></tr>
            <?php while($v = $vehiculos->fetch_assoc()): ?>
            <tr>
                <td><?= $v['id'] ?></td>
                <td><?= htmlspecialchars($v['patente']) ?></td>
                <td><?= htmlspecialchars($v['modelo']) ?></td>
                <td><?= htmlspecialchars($v['estado']) ?></td>
                <td>
                    <a href="editar_vehiculo.php?id=<?= $v['id'] ?>" class="accion">Editar</a>
                    <a href="eliminar_vehiculo.php?id=<?= $v['id'] ?>" class="accion" onclick="return confirm('¿Seguro que quieres eliminar este vehículo?')">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </section>

    <section>
        <h2>Solicitar Mantenimiento</h2>
        <form action="crear_mantenimiento.php" method="POST">
            <label for="vehiculo">Vehículo:</label>
            <select name="idVehiculo" id="vehiculo" required>
                <option value="">Seleccione un vehículo</option>
                <?php mysqli_data_seek($vehiculos, 0); // reiniciamos el puntero ?>
                <?php while($v = $vehiculos->fetch_assoc()): ?>
                    <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['patente']) ?> - <?= htmlspecialchars($v['modelo']) ?></option>
                <?php endwhile; ?>
            </select>

            <label for="tipo">Tipo de mantenimiento:</label>
            <input type="text" name="tipo" id="tipo" placeholder="Ej: cambio de aceite" required>

            <button type="submit" class="accion">Solicitar</button>
        </form>
    </section>

    <section>
        <h2>Mantenimientos Pendientes</h2>
        <table>
            <tr><th>ID</th><th>Patente</th><th>Tipo</th><th>Fecha</th></tr>
            <?php while ($m = $mantenimientos->fetch_assoc()): ?>
            <tr>
                <td><?= $m['id'] ?></td>
                <td><?= htmlspecialchars($m['patente']) ?></td>
                <td><?= htmlspecialchars($m['tipo']) ?></td>
                <td><?= $m['fecha'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </section>

    <section>
        <h2>Reservas Activas</h2>
        <table>
            <tr><th>ID</th><th>Cliente</th><th>Vehículo</th><th>Tipo Vehículo</th><th>Inicio</th><th>Fin</th><th>Estado</th><th>Acción</th></tr>
<?php while($r = $reservas->fetch_assoc()): ?>
<tr>
    <td><?= $r['id'] ?? 'N/A' ?></td>
    <td><?= htmlspecialchars($r['cliente'] ?? 'N/A') ?></td>
    <td><?= htmlspecialchars($r['vehiculo'] ?? 'N/A') ?></td>
    <td><?= htmlspecialchars($r['tipoVehiculo'] ?? 'N/A') ?></td>
    <td><?= $r['fechaInicio'] ?? 'N/A' ?></td>
    <td><?= $r['fechaFin'] ?? 'N/A' ?></td>
    <td><?= htmlspecialchars($r['estado'] ?? 'N/A') ?></td>
    <td>Acción</td>
</tr>
<?php endwhile; ?>

<?php if ($reservas->num_rows == 0) echo "<tr><td colspan='8'>No hay reservas</td></tr>"; ?>

        </table>
    </section>

</main>

<footer>
    © <?= date("Y") ?> Sistema de Mantenimiento de Flota
</footer>

</body>
</html>
