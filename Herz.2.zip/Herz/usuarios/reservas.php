<?php
session_start();
if (!isset($_SESSION['cliente_id']) || $_SESSION['cliente_rol'] != 2) {
    header("Location: ../Sesion/login.php");
    exit();
}

include("../principal/config.php");

$idEmpleado = $_SESSION['cliente_id'];
$sqlSucursal = "SELECT idSucursal FROM Clientes WHERE id = ?";
$stmt = $conn->prepare($sqlSucursal);
$stmt->bind_param("i", $idEmpleado);
$stmt->execute();
$result = $stmt->get_result();
$empleado = $result->fetch_assoc();

if (!$empleado || !$empleado['idSucursal']) {
    echo "<p>Error: No se encontró la sucursal del empleado.</p>";
    exit();
}

$idSucursal = $empleado['idSucursal'];

// Consulta para obtener reservas sin duplicar y con datos del vehículo
$sql = "
    SELECT 
        r.id AS idReserva,
        c.nombre AS cliente,
        r.tipoVehiculo,
        r.fechaInicio,
        r.fechaFin,
        r.estado,
        (SELECT CONCAT(v.modelo, ' ', v.patente)
         FROM Vehiculos v
         WHERE v.tipo = r.tipoVehiculo AND v.idSucursal = r.idSucursal
         LIMIT 1) AS vehiculo
    FROM Reservas r
    JOIN Clientes c ON r.idCliente = c.id
    WHERE r.idSucursal = ? AND r.estado IN ('pendiente', 'en curso')
    ORDER BY r.fechaInicio ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idSucursal);
$stmt->execute();
$reservas = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Empleado - Reservas</title>
    <link rel="stylesheet" href="../principal.css">
</head>
<body>
    <h1>Reservas Pendientes / En Curso</h1>
    <table border="1">
        <tr>
            <th>ID Reserva</th>
            <th>Cliente</th>
            <th>Tipo Vehículo</th>
            <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <th>Vehículo</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        <?php while($r = $reservas->fetch_assoc()): ?>
        <tr>
            <td><?= $r['idReserva'] ?></td>
            <td><?= htmlspecialchars($r['cliente']) ?></td>
            <td><?= htmlspecialchars($r['tipoVehiculo']) ?></td>
            <td><?= htmlspecialchars($r['fechaInicio']) ?></td>
            <td><?= htmlspecialchars($r['fechaFin']) ?></td>
            <td><?= htmlspecialchars($r['vehiculo']) ?: 'No asignado' ?></td>
            <td><?= htmlspecialchars(ucfirst($r['estado'])) ?></td>
            <td>
                <?php if ($r['estado'] == 'pendiente'): ?>
                    <a href="../principal/admin_reservas.php"> ver reservas</a>
                <?php elseif ($r['estado'] == 'en curso'): ?>
                    <a href="registrar_devolucion.php?idReserva=<?= $r['idReserva'] ?>">Registrar Devolución</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
