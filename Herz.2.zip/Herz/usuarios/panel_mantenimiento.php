<?php
session_start();
$rolesPermitidos = [4, 5]; // 2 = empleado, 3 = admin

if (!isset($_SESSION['cliente_id']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../sesion/login.php");
    exit();
}
include("../principal/config.php");

$sql = "SELECT m.id, v.patente, m.tipo, m.estado, m.fecha
        FROM Mantenimiento m
        JOIN Vehiculos v ON m.idVehiculo = v.id
        WHERE m.estado = 'pendiente'";
$pendientes = $conn->query($sql);

$totalPendientes = $conn->query("SELECT COUNT(*) AS total FROM Mantenimiento WHERE estado='pendiente'")->fetch_assoc()['total'];
$totalCompletados = $conn->query("SELECT COUNT(*) AS total FROM Mantenimiento WHERE estado='completado'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel - Personal de Mantenimiento</title>
    <link rel="stylesheet" href="all.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin:0; background:#f5f7f7; }
         .resumen { display:flex; gap:15px; }
        .card { flex:1; padding:15px; border-radius:8px; text-align:center; color:#fff; font-weight:600; }
        .card h3 { margin:0 0 10px; font-size:1.1rem; }
        .card p { margin:0; font-size:1.5rem; }
        .card.completado { background:#27ae60; }
        .card:not(.completado) { background:#e74c3c; }
        table { width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
        th, td { padding:10px 12px; border-bottom:1px solid #ddd; text-align:left; }
        th { background:#04926f; color:#fff; }
        tr:hover { background:#f0f8f6; }
        .accion { padding:6px 10px; background:#04926f; color:#fff; border:none; border-radius:6px; cursor:pointer; transition:0.2s; }
        .accion:hover { background:#02785d; transform:scale(1.05); }
        footer { text-align:center; padding:12px; background:#f5f7f7; border-top:1px solid #ddd; font-size:0.9rem; margin-top:20px; }
    </style>
</head>
<body>

<header class="main-header">
    <div class="left">
            <div class="logo">
                <img src="../img/logo.png" alt="Herz" class="logo-img">
            </div>
        </div>

    <div class="center"><h1>Panel mantenimiento</h1></div>
    <div class="right"></div>
    
</header>

<main>

    <section class="resumen">
        <div class="card">
            <h3>Pendientes</h3>
            <p><?= $totalPendientes ?></p>
        </div>
        <div class="card completado">
            <h3>Completados</h3>
            <p><?= $totalCompletados ?></p>
        </div>
    </section>

    <section>
        <h2>Órdenes de Mantenimiento Pendientes</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Patente</th>
                <th>Tipo</th>
                <th>Fecha</th>
                <th>Acción</th>
            </tr>
            <?php while ($m = $pendientes->fetch_assoc()): ?>
            <tr>
                <td><?= $m['id'] ?></td>
                <td><?= htmlspecialchars($m['patente']) ?></td>
                <td><?= htmlspecialchars($m['tipo']) ?></td>
                <td><?= $m['fecha'] ?></td>
                <td>
                    <form action="completar_mantenimiento.php" method="POST">
                        <input type="hidden" name="mantenimiento_id" value="<?= $m['id'] ?>">
                        <input type="number" name="costo" step="0.01" placeholder="Ingrese costo" required>
                        <button type="submit" class="accion">Marcar completado</button>
                    </form>

                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </section>

</main>

<footer>
    © <?= date("Y") ?> Sistema de Mantenimiento de Flota
</footer>

</body>
</html>
