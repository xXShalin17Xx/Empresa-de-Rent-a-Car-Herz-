<?php
session_start();
if (!isset($_SESSION['empleado_id']) || $_SESSION['empleado_rol'] != 2) {
    header("Location: ../Sesion/login.php");
    exit();
}
include("../principal/config.php");
$idSucursal = $_SESSION['empleado_sucursal'];

// Ingresos diarios
$sqlIngresos = "SELECT DATE(a.fechaRetiro) AS dia, COUNT(a.id) AS ocupacion, SUM(v.precio) AS ingresos
                FROM Alquileres a
                JOIN Vehiculos v ON a.idVehiculo=v.id
                WHERE v.idSucursal=? AND a.fechaDevolucion IS NOT NULL
                GROUP BY DATE(a.fechaRetiro)";
$stmt = $conn->prepare($sqlIngresos);
$stmt->bind_param("i",$idSucursal);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reportes Sucursal</title>
</head>
<body>
<h1>Reportes diarios</h1>
<table border="1">
<tr>
    <th>Fecha</th>
    <th>Ocupación (alquileres)</th>
    <th>Ingresos</th>
</tr>
<?php while($r = $result->fetch_assoc()): ?>
<tr>
    <td><?= $r['dia'] ?></td>
    <td><?= $r['ocupacion'] ?></td>
    <td>$<?= $r['ingresos'] ?></td>
</tr>
<?php endwhile; ?>
</table>
</body>
</html>
