<?php
session_start();

$rolesPermitidos = [2, 5]; // 2 = empleado, 5 = otro rol

if (!isset($_SESSION['cliente_id']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../sesion/login.php");
    exit();
}

include("../principal/config.php");

// Obtener la sucursal del empleado
$idEmpleado = $_SESSION['cliente_id'];
$sqlSucursal = "SELECT idSucursal FROM Clientes WHERE id = ?";
$stmt = $conn->prepare($sqlSucursal);
$stmt->bind_param("i", $idEmpleado);
$stmt->execute();
$result = $stmt->get_result();
$empleado = $result->fetch_assoc();

if (!$empleado || !$empleado['idSucursal']) {
    echo "<p>Error: No se encontró la sucursal del empleado.</p>";
    exit();
}

$idSucursal = $empleado['idSucursal'];
$section = $_GET['section'] ?? 'panel';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Empleado - Sucursal</title>
    <link rel="stylesheet" href="panel_empleado.css">
</head>
<body>


<div class="sidebar">
    <div class="sidebar-header">
        <a href="../usuarios/empleado_home.php" class="logo">
            <img src="../img/logo.png" alt="Herz Logo">
        </a>
    </div>

    <div class="sidebar-links">
        <a href="?section=panel" class="<?= $section == 'panel' ? 'active' : '' ?>">Reservas</a>
        <a href="?section=devolucion" class="<?= $section == 'devolucion' ? 'active' : '' ?>">Devoluciones</a>
        <a href="?section=reportes" class="<?= $section == 'reportes' ? 'active' : '' ?>">Reportes</a>
    </div>

    <div class="sidebar-logout">
        <a href="../Sesion/logout.php">Cerrar sesión</a>
    </div>
</div>

<main>
<header>
    <h1>Panel del Empleado - Sucursal</h1>
</header>

<?php if ($section == 'panel'): ?>

    <?php
    $sql = "
        SELECT r.id, c.nombre AS cliente, r.tipoVehiculo, r.fechaInicio, r.fechaFin, r.estado
        FROM Reservas r
        JOIN Clientes c ON r.idCliente = c.id
        WHERE r.idSucursal = ?
          AND r.estado IN ('pendiente','confirmada')
        ORDER BY r.fechaInicio ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idSucursal);
    $stmt->execute();
    $reservas = $stmt->get_result();
    ?>

    <section>
        <h2>Reservas pendientes / confirmadas</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Tipo</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $reservas->fetch_assoc()): ?>
                <tr onclick="window.location.href='../principal/admin_reservas.php?idReserva=<?= $r['id'] ?>'">
                    <td><?= $r['id'] ?></td>
                    <td><?= htmlspecialchars($r['cliente']) ?></td>
                    <td><?= htmlspecialchars($r['tipoVehiculo']) ?></td>
                    <td><?= $r['fechaInicio'] ?></td>
                    <td><?= $r['fechaFin'] ?></td>
                    <td><?= ucfirst($r['estado']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php elseif ($section == 'devolucion'): ?>

    <?php
    $sql = "
        SELECT a.id AS idAlquiler, c.nombre AS cliente, v.patente, v.modelo, r.fechaInicio, r.fechaFin
        FROM Alquileres a
        JOIN Reservas r ON a.idReserva = r.id
        JOIN Clientes c ON r.idCliente = c.id
        JOIN Vehiculos v ON a.idVehiculo = v.id
        WHERE v.idSucursal = ? AND a.estado = 'en curso'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idSucursal);
    $stmt->execute();
    $devoluciones = $stmt->get_result();
    ?>

    <section>
        <h2>Vehículos en alquiler (para devolución)</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Alquiler</th>
                    <th>Cliente</th>
                    <th>Patente</th>
                    <th>Modelo</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($d = $devoluciones->fetch_assoc()): ?>
                <tr>
                    <td><?= $d['idAlquiler'] ?></td>
                    <td><?= htmlspecialchars($d['cliente']) ?></td>
                    <td><?= htmlspecialchars($d['patente']) ?></td>
                    <td><?= htmlspecialchars($d['modelo']) ?></td>
                    <td><?= $d['fechaInicio'] ?></td>
                    <td><?= $d['fechaFin'] ?></td>
                    <td><a href="../usuarios/devolucion.php?id=<?= $d['idAlquiler'] ?>" class="btn">Procesar</a></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php elseif ($section == 'reportes'): ?>

    <?php
    $sql = "SELECT estado, COUNT(*) AS cantidad FROM Vehiculos WHERE idSucursal = ? GROUP BY estado";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idSucursal);
    $stmt->execute();
    $reportes = $stmt->get_result();
    ?>

    <section>
        <h2>Reporte de estado de vehículos</h2>
        <table>
            <thead>
                <tr>
                    <th>Estado</th>
                    <th>Cantidad</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $reportes->fetch_assoc()): ?>
                <tr>
                    <td><?= ucfirst($r['estado']) ?></td>
                    <td><?= $r['cantidad'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>

<?php endif; ?>

<footer>
    © <?= date("Y") ?> Sistema de Gestión de Sucursal - Herz
</footer>
</main>

</body>
</html>
