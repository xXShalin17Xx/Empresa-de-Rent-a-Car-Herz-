<?php
session_start();
if (!isset($_SESSION['cliente_id']) || $_SESSION['cliente_rol'] != 2) {
    header("Location: ../Sesion/login.php");
    exit();
}
include("../principal/config.php");

$idAlquiler = $_GET['id'] ?? null;
if (!$idAlquiler) die("Alquiler no especificado.");

$sql = "SELECT * FROM Alquileres WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idAlquiler);
$stmt->execute();
$alquiler = $stmt->get_result()->fetch_assoc();

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kmFinal = $_POST['kmFinal'];
    $daños = isset($_POST['daños']) ? implode(', ', $_POST['daños']) : '';

    $sqlUp = "UPDATE Alquileres 
          SET kmFinal = ?, fechaDevolucion = NOW(), estado = 'finalizado' 
          WHERE id = ?";
    $stmtUp = $conn->prepare($sqlUp);
    $stmtUp->bind_param("di", $kmFinal, $alquiler['id']);
    $stmtUp->execute();


    $message = "Devolución registrada correctamente";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Devolución / Retiro</title>
<link rel="stylesheet" href="devolucion.css">
</head>
<body>

<header class="main-header">
    <div class="left">
        <div class="logo">
            <a href="../usuarios/empleado_home.php"><img src="../img/logo.png" alt="Herz" class="logo-img"></a>
        </div>
    </div>

    <div class="center">
        <h1>Herz - Autos Rentables</h1>
    </div>
    <div class="right"></div>
</header>

<main>
    <h1>Devolución / Retiro</h1>

    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="POST">
        <p>Vehículo ID: <?= $alquiler['idVehiculo'] ?></p>
        <p>KM Inicial: <?= $alquiler['kmInicial'] ?></p>

        <label>KM Final:
            <input type="number" name="kmFinal" step="0.01" required>
        </label>

        <fieldset>
            <legend>Checklist de daños</legend>
            <label><input type="checkbox" name="daños[]" value="rayones"> Rayones</label>
            <label><input type="checkbox" name="daños[]" value="golpes"> Golpes</label>
            <label><input type="checkbox" name="daños[]" value="interior"> Manchas interiores</label>
            <label><input type="checkbox" name="daños[]" value="combustible"> Nivel combustible</label>
        </fieldset>

        <button type="submit">Registrar</button>
    </form>
</main>

</body>
</html>
