<?php
session_start();

$rolesPermitidos = [4, 5]; // 4 = Personal de mantenimiento, 5 = Coordinador de flota

if (!isset($_SESSION['cliente_id']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../sesion/login.php");
    exit();
}

include("../principal/config.php");

if (!isset($_POST['mantenimiento_id']) || !is_numeric($_POST['mantenimiento_id'])) {
    die("ID de mantenimiento inválido.");
}

$mantenimiento_id = intval($_POST['mantenimiento_id']);

$costo = isset($_POST['costo']) ? floatval($_POST['costo']) : 0;
if ($costo <= 0) {
    die("El costo debe ser un valor positivo.");
}

$sql = "UPDATE Mantenimiento 
        SET estado='completado', costo=$costo, fechaCompletado=NOW() 
        WHERE id=$mantenimiento_id";

if ($conn->query($sql)) {

    $sqlVehiculo = "UPDATE Vehiculos v
                    JOIN Mantenimiento m ON m.idVehiculo = v.id
                    SET v.estado='disponible'
                    WHERE m.id=$mantenimiento_id";

    if ($conn->query($sqlVehiculo)) {
        header("Location: panel_mantenimiento.php?success=1");
        exit();
    } else {
        die("Error al actualizar el vehículo: " . $conn->error);
    }

} else {
    die("Error al actualizar mantenimiento: " . $conn->error);
}


// Verificamos si la consulta se preparó correctamente
if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

// Enlazamos los parámetros y ejecutamos
$stmt->bind_param("di", $costo, $mantenimiento_id);

// Ejecutamos la sentencia
if ($stmt->execute()) {
    // Redirigimos a la página de mantenimiento con un parámetro de éxito
    header("Location: panel_mantenimiento.php?success=1");
    exit();
} else {
    // Si ocurre un error, mostramos un mensaje
    die("Error al actualizar el mantenimiento: " . $stmt->error);
}

?>
