<?php
session_start();

 
if (!isset($_SESSION['cliente_id']) || !isset($_SESSION['cliente_rol']) || $_SESSION['cliente_rol'] != 5) {
    header("Location: ../Sesion/login.php");
    exit();
}


include("../principal/config.php");


$vista = $_GET['vista'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body>
  <div class="sidebar">
    <h2>
      <a href="../principal/home.php">
        <img src="../img/logo.png" alt="Herz" class="sidebar-logo">
      </a>
    </h2>

    <ul>
      <li><a href="?vista=dashboard">dashboard</a></li>
      <li><a href="?vista=usuarios">Usuarios</a></li>
      <li><a href="?vista=vehiculos">Vehículos</a></li>
      <li><a href="?vista=reservas">Reservas</a></li>
      <li><a href="?vista=alquileres">Alquileres</a></li>
      <li><a href="?vista=mantenimiento">Mantenimiento</a></li>
      <li><a href="?vista=sucursales">Sucursales</a></li>
      <li><a href="?vista=reportes">Reportes</a></li>
      <li><a href="../usuarios/admin_roles.php">Roles y Sucursal</a></li>
    </ul>
      <div class="logout-container">
        <a href="../Sesion/logout.php" class="logout-btn">Cerrar sesión</a>
      </div>

  </div>

  <div class="main-content">
    <header>
      <h1>Panel de Administración</h1>
      <p>Bienvenido, <?php echo htmlspecialchars($_SESSION['cliente_nombre'] ?? 'Administrador'); ?></p>
    </header>

    <section class="dashboard">
      <?php
      switch ($vista) {
          
          case 'usuarios':
              $usuarios = $conn->query("
                SELECT c.id, c.nombre, c.dni, c.email, c.idRol
                FROM Clientes c
              ");

              echo "<h2>Usuarios</h2>
                    <table>
                      <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>DNI</th>
                        <th>Email</th>
                        <th>Rol</th>
                      </tr>";

              while ($u = $usuarios->fetch_assoc()) {
                  
                  switch ($u['idRol']) {
                      case 1:
                          $rolMostrar = 'Cliente';
                          break;
                      case 2:
                          $rolMostrar = 'Empleado de Sucursal';
                          break;
                      case 3:
                          $rolMostrar = 'Coordinador de Flotas';
                          break;
                      case 4:
                          $rolMostrar = 'Personal de Mantenimiento';
                          break;
                      case 5:
                          $rolMostrar = 'Administrador';
                          break;
                      default:
                          $rolMostrar = 'Sin rol';
                          break;
                  }

                  echo "<tr>
                          <td>{$u['id']}</td>
                          <td>" . htmlspecialchars($u['nombre']) . "</td>
                          <td>{$u['dni']}</td>
                          <td>{$u['email']}</td>
                          <td>{$rolMostrar}</td>
                        </tr>";
              }
              echo "</table>";
              break;

          
          case 'vehiculos':
              $vehiculos = $conn->query("SELECT * FROM Vehiculos");
              echo "<h2>Vehículos</h2><table><tr><th>ID</th><th>Patente</th><th>Modelo</th><th>Tipo</th><th>Estado</th><th>Kilometraje</th></tr>";
              while ($v = $vehiculos->fetch_assoc()) {
                  echo "<tr><td>{$v['id']}</td><td>{$v['patente']}</td><td>{$v['modelo']}</td><td>{$v['tipo']}</td><td>{$v['estado']}</td><td>{$v['kilometraje']}</td></tr>";
              }
              echo "</table>";
              break;

          
          case 'reservas':
              $reservas = $conn->query("SELECT * FROM Reservas");
              echo "<h2>Reservas</h2><table><tr><th>ID</th><th>Cliente</th><th>Tipo Vehículo</th><th>Inicio</th><th>Fin</th><th>Estado</th></tr>";
              while ($r = $reservas->fetch_assoc()) {
                  echo "<tr><td>{$r['id']}</td><td>{$r['idCliente']}</td><td>{$r['tipoVehiculo']}</td><td>{$r['fechaInicio']}</td><td>{$r['fechaFin']}</td><td>{$r['estado']}</td></tr>";
              }
              echo "</table>";
              break;

          
          case 'alquileres':
              $alquileres = $conn->query("SELECT * FROM Alquileres");
              echo "<h2>Alquileres</h2><table><tr><th>ID</th><th>Reserva</th><th>Vehículo</th><th>Retiro</th><th>Devolución</th><th>KM Inicial</th><th>KM Final</th></tr>";
              while ($a = $alquileres->fetch_assoc()) {
                  echo "<tr><td>{$a['id']}</td><td>{$a['idReserva']}</td><td>{$a['idVehiculo']}</td><td>{$a['fechaRetiro']}</td><td>{$a['fechaDevolucion']}</td><td>{$a['kmInicial']}</td><td>{$a['kmFinal']}</td></tr>";
              }
              echo "</table>";
              break;

          
          case 'mantenimiento':
              $mantenimientos = $conn->query("SELECT * FROM Mantenimiento");
              echo "<h2>Mantenimiento</h2><table><tr><th>ID</th><th>Vehículo</th><th>Fecha</th><th>Tipo</th><th>Costo</th><th>Estado</th></tr>";
              while ($m = $mantenimientos->fetch_assoc()) {
                  echo "<tr><td>{$m['id']}</td><td>{$m['idVehiculo']}</td><td>{$m['fecha']}</td><td>{$m['tipo']}</td><td>{$m['costo']}</td><td>{$m['estado']}</td></tr>";
              }
              echo "</table>";
              break;

          
          case 'sucursales':
              $sucursales = $conn->query("SELECT * FROM Sucursales");
              echo "<h2>Sucursales</h2><table><tr><th>ID</th><th>Nombre</th><th>Dirección</th><th>Teléfono</th></tr>";
              while ($s = $sucursales->fetch_assoc()) {
                  echo "<tr><td>{$s['id']}</td><td>{$s['nombre']}</td><td>{$s['direccion']}</td><td>{$s['telefono']}</td></tr>";
              }
              echo "</table>";
              break;

          
          case 'reportes':
              echo "<h2>Reportes</h2><p>Funcionalidad de reportes aún no implementada.</p>";
              break;

          
          default:
              $totalUsuarios = $conn->query("SELECT COUNT(*) FROM Clientes")->fetch_row()[0];
              $totalVehiculos = $conn->query("SELECT COUNT(*) FROM Vehiculos")->fetch_row()[0];
              $reservasActivas = $conn->query("SELECT COUNT(*) FROM Reservas WHERE estado = 'en curso'")->fetch_row()[0];
              $alquileresActivos = $conn->query("SELECT COUNT(*) FROM Alquileres WHERE fechaDevolucion IS NULL")->fetch_row()[0];
              $mantenimientoPendiente = $conn->query("SELECT COUNT(*) FROM Mantenimiento WHERE estado = 'pendiente'")->fetch_row()[0];

              echo "<div class='card'>Total de Usuarios: $totalUsuarios</div>";
              echo "<div class='card'>Total de Vehículos: $totalVehiculos</div>";
              echo "<div class='card'>Reservas Activas: $reservasActivas</div>";
              echo "<div class='card'>Alquileres Activos: $alquileresActivos</div>";
              echo "<div class='card'>Mantenimientos Pendientes: $mantenimientoPendiente</div>";
              break;
      }
      ?>
    </section>
  </div>
</body>
</html>

<?php $conn->close(); ?>
