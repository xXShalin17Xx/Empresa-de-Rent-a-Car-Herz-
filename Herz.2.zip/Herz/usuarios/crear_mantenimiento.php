<?php
session_start();
$rolesPermitidos = [4, 5]; // 2 = empleado, 3 = admin

if (!isset($_SESSION['cliente_id']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../sesion/login.php");
    exit();
}

include("../principal/config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehiculo_id = intval($_POST['vehiculo_id']);
    $tipo = $conn->real_escape_string($_POST['tipo']);
    
    $sql = "INSERT INTO Mantenimiento (idVehiculo, tipo, estado, fecha) VALUES ($vehiculo_id, '$tipo', 'pendiente', NOW())";
    
    if ($conn->query($sql)) {
        header("Location: coordinador_flota.php?success=1");
        exit();
    } else {
        echo "Error al crear la orden: " . $conn->error;
    }
}
?>
