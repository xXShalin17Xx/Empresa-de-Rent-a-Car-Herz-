<?php
session_start();
include("../principal/config.php");

// Consulta de reservas pendientes (aún no confirmadas)
$sql = "
    SELECT 
        R.id AS idReserva,
        C.id AS cliente_id,
        C.nombre,
        C.email,
        R.tipoVehiculo,
        R.fechaInicio,
        R.fechaFin,
        S.nombre AS sucursal,
        V.id AS vehiculo_id,
        V.modelo,
        V.patente
    FROM Reservas R
    INNER JOIN Clientes C ON R.idCliente = C.id
    INNER JOIN Sucursales S ON R.idSucursal = S.id
    LEFT JOIN Vehiculos V 
        ON V.tipo = R.tipoVehiculo 
        AND V.idSucursal = R.idSucursal 
        AND V.estado = 'disponible'
    WHERE R.estado = 'pendiente'
    ORDER BY R.fechaInicio ASC
";

$stmt = $conn->prepare($sql);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Pendientes - Herz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;700&display=swap');
        :root {
          --accent: #04926f;
          --accent-dark: #046f55;
          --bg-light: #f4f4f4;
          --text: #222;
          --white: #fff;
          --shadow: rgba(4,146,111,0.25);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Rajdhani', sans-serif; }
        body { background: var(--bg-light); color: var(--text); }
        .main-header { background: var(--accent); color: var(--white); display: flex; align-items: center; justify-content: space-between; padding: 16px 28px; box-shadow: 0 3px 10px var(--shadow); }
        .logo { font-size: 26px; font-weight: 700; text-decoration: none; color: var(--white); }
        h1 { font-size: 24px; font-weight: 600; }
        .panel { max-width: 1100px; margin: 40px auto; background: var(--white); padding: 30px; border-radius: 12px; box-shadow: 0 6px 20px var(--shadow); }
        .panel h2 { text-align: center; margin-bottom: 25px; color: var(--accent-dark); font-size: 28px; }
        table { width: 100%; border-collapse: collapse; box-shadow: 0 3px 8px rgba(0,0,0,0.05); }
        th, td { padding: 10px 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background: var(--accent); color: var(--white); font-weight: 700; }
        tr:hover { background: #f1f1f1; }
        .btn { background: var(--accent); color: var(--white); padding: 6px 12px; border-radius: 6px; text-decoration: none; font-weight: 600; border: none; cursor: pointer; }
        .btn:hover { background: var(--accent-dark); }
        .no-data { text-align: center; font-weight: 600; margin-top: 20px; color: var(--accent-dark); }
    </style>
</head>

<body>

<header class="main-header">
    <div class="left"><a href="../usuarios/empleado_home.php" class="logo">Herz</a></div>
    <div class="center"><h1>Confirmaciones Pendientes</h1></div>
    <div class="right"></div>
</header>

<main class="panel">
    <h2>Reservas en espera de confirmación</h2>

    <?php if ($resultado->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th><th>Cliente</th><th>Email</th><th>Tipo</th>
                    <th>Sucursal</th><th>Modelo</th><th>Patente</th>
                    <th>Inicio</th><th>Fin</th><th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?= $r['idReserva'] ?></td>
                        <td><?= htmlspecialchars($r['nombre']) ?></td>
                        <td><?= htmlspecialchars($r['email']) ?></td>
                        <td><?= ucfirst($r['tipoVehiculo']) ?></td>
                        <td><?= htmlspecialchars($r['sucursal']) ?></td>
                        <td><?= htmlspecialchars($r['modelo'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($r['patente'] ?? '-') ?></td>
                        <td><?= $r['fechaInicio'] ?></td>
                        <td><?= $r['fechaFin'] ?></td>
                        <td>
                            <form method="POST" action="procesar_retiro.php" style="display:inline;">
                                <input type="hidden" name="reserva_id" value="<?= $r['idReserva'] ?>">
                                <input type="hidden" name="vehiculo_id" value="<?= $r['vehiculo_id'] ?? '' ?>">
                                <input type="hidden" name="cliente_id" value="<?= $r['cliente_id'] ?? '' ?>">
                                <button type="submit" class="btn">Confirmar</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="no-data">No hay reservas pendientes.</p>
    <?php endif; ?>
</main>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
