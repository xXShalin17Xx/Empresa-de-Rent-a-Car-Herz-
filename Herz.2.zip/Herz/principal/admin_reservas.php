<?php
session_start();
require_once("../principal/config.php");

if (empty($_SESSION['cliente_id'])) {
    header("Location: ../sesion/login.php");
    exit("No hay sesión activa.");
}

$idEmpleado = (int)$_SESSION['cliente_id'];

$sqlSucursal = "SELECT idSucursal FROM Clientes WHERE id = ?";
$stmt = $conn->prepare($sqlSucursal);
if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conn->error);
}
$stmt->bind_param("i", $idEmpleado);
$stmt->execute();
$result = $stmt->get_result();
$empleado = $result->fetch_assoc();

if (!$empleado || empty($empleado['idSucursal'])) {
    die("<p>Error: El empleado no tiene asignada una sucursal.</p>");
}
$idSucursal = (int)$empleado['idSucursal'];
$stmt->close();

$sqlReservas = "
    SELECT 
        R.id AS idReserva,
        C.nombre,
        C.email,
        R.tipoVehiculo,
        R.fechaInicio,
        R.fechaFin
    FROM Reservas R
    INNER JOIN Clientes C ON R.idCliente = C.id
    WHERE R.idSucursal = ? AND R.estado = 'pendiente'
    ORDER BY R.fechaInicio ASC
";
$stmt = $conn->prepare($sqlReservas);
if (!$stmt) {
    die("Error en la preparación de la consulta de reservas: " . $conn->error);
}
$stmt->bind_param("i", $idSucursal);
$stmt->execute();
$reservas = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Pendientes - Herz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="principal.css">
    <style>
        main {
            max-width: 1100px;
            margin: 2rem auto;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #04926f;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            background-color: #04926f;
            color: white;
            padding: 6px 10px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9em;
        }
        .btn:hover {
            background-color: #2e57b8;
        }
        header.main-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #04926f;
            color: white;
            padding: 10px 20px;
        }
        .logo {
            color: white;
            font-weight: bold;
            text-decoration: none;
            font-size: 1.4em;
        }
        h2 {
            text-align: center;
            margin-top: 0;
        }
        p {
            text-align: center;
        }
    </style>
</head>
<body>

<header class="main-header">
    <a href="../usuarios/empleado_home.php" class="logo">Herz</a>
    <h1>Reservas Pendientes</h1>
    <a href="../sesion/logout.php" style="color:white; text-decoration:none;">Cerrar sesión</a>
</header>

<main>
    <h2>Reservas en espera de confirmación</h2>

    <?php if ($reservas->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID Reserva</th>
                    <th>Cliente</th>
                    <th>Email</th>
                    <th>Tipo Vehículo</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $reservas->fetch_assoc()): ?>
                    <tr>
                        <td><?= $r['idReserva'] ?></td>
                        <td><?= htmlspecialchars($r['nombre']) ?></td>
                        <td><?= htmlspecialchars($r['email']) ?></td>
                        <td><?= ucfirst($r['tipoVehiculo']) ?></td>
                        <td><?= htmlspecialchars($r['fechaInicio']) ?></td>
                        <td><?= htmlspecialchars($r['fechaFin']) ?></td>
                        <td>
                            <a class="btn" href="confirmar_retiro.php?idReserva=<?= $r['idReserva'] ?>">
                                Confirmar Retiro
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No hay reservas pendientes para tu sucursal.</p>
    <?php endif; ?>
</main>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
