<?php
session_start();
include("config.php");

// Verificar sesión
if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../Sesion/login.php");
    exit();
}

$idCliente = $_SESSION['cliente_id'];
$mensaje = '';

// Cancelar reserva si se solicita
if (isset($_GET['cancelar']) && is_numeric($_GET['cancelar'])) {
    $idReserva = $_GET['cancelar'];

    // Verificar que la reserva pertenece al cliente y está pendiente o confirmada
    $sqlCheck = "SELECT * FROM Reservas WHERE id=? AND idCliente=? AND estado IN ('pendiente','confirmada')";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("ii", $idReserva, $idCliente);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck->num_rows > 0) {
        $sqlCancel = "UPDATE Reservas SET estado='cancelada' WHERE id=?";
        $stmtCancel = $conn->prepare($sqlCancel);
        $stmtCancel->bind_param("i", $idReserva);
        $stmtCancel->execute();

        $mensaje = "Reserva cancelada correctamente.";
    } else {
        $mensaje = "No se puede cancelar esta reserva.";
    }
}

// Obtener reservas del cliente y sus alquileres asociados
$sql = "SELECT 
            r.id AS idReserva,
            r.estado AS estadoReserva,
            a.id AS alquiler_id,
            v.modelo,
            v.patente,
            a.fechaRetiro,
            a.fechaDevolucion,
            s.nombre AS sucursal
        FROM Reservas r
        LEFT JOIN Alquileres a ON r.id = a.idReserva
        LEFT JOIN Vehiculos v ON a.idVehiculo = v.id
        LEFT JOIN Sucursales s ON v.idSucursal = s.id
        WHERE r.idCliente = ?
        ORDER BY r.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idCliente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Alquileres - Herz</title>
    <link rel="stylesheet" href="principal.css">
    <style>
        .btn-cancel {
            padding: 5px 10px;
            background: #d9534f;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }
        .btn-cancel:hover {
            background: #c9302c;
        }
        .message {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 8px 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #04926f;
            color: #fff;
        }
        tr:hover {
            background: #f0f8f6;
        }
    </style>
</head>
<body>

<header class="main-header">
    <div class="left"><a href="home.php" class="logo">Herz</a></div>
    <div class="center"><h1>Mis Alquileres</h1></div>
    <div class="right">
        <a href="buscar_vehiculos.php">Buscar Vehículos</a>
        <a href="../Sesion/logout.php">Cerrar sesión</a>
    </div>
</header>

<main class="alquileres-container">
    <?php if($mensaje) echo "<p class='message'>{$mensaje}</p>"; ?>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Vehículo</th>
                <th>Patente</th>
                <th>Sucursal</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Estado Reserva</th>
                <th>Comprobante</th>
                <th>Acciones</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['modelo'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['patente'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['sucursal'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['fechaRetiro'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['fechaDevolucion'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['estadoReserva']) ?></td>
                    <td>
                        <?php if(isset($row['alquiler_id'])): ?>
                            <a href="comprobante.php?id=<?= $row['alquiler_id'] ?>">Descargar</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($row['estadoReserva'] == 'pendiente' || $row['estadoReserva'] == 'confirmada'): ?>
                            <a href="?cancelar=<?= $row['idReserva'] ?>" class="btn-cancel" onclick="return confirm('¿Desea cancelar esta reserva?');">Cancelar</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No tenés reservas o alquileres registrados.</p>
    <?php endif; ?>
</main>

</body>
</html>
