<?php
require('../fpdf/fpdf.php');
include("config.php");

date_default_timezone_set('America/Argentina/Buenos_Aires');

$id = $_GET['id'] ?? null;
if (!$id) {
    die("ID de alquiler no especificado.");
}

// Consulta del alquiler adaptada
$sql = "SELECT a.id, v.modelo, v.patente, s.nombre AS sucursal, a.fechaRetiro, a.fechaDevolucion,
               c.nombre AS cliente, r.fechaInicio, r.fechaFin
        FROM Alquileres a
        JOIN Reservas r ON a.idReserva = r.id
        JOIN Clientes c ON r.idCliente = c.id
        JOIN Vehiculos v ON a.idVehiculo = v.id
        JOIN Sucursales s ON v.idSucursal = s.id
        WHERE a.id = ?";


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) die("Alquiler no encontrado.");

// Clase PDF con encabezado y pie
class PDF extends FPDF {
    function Header() {
        $this->Image('../img/logo.png',10,6,30);
        $this->SetFont('Arial','B',14);
        $this->Cell(0,10,'Herz Rent a Car',0,1,'C');
        $this->Ln(5);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

// Crear PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// Título
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Comprobante de Alquiler',0,1,'C');

// Fecha de emisión
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,'Fecha de Emision: '.date('d/m/Y'),0,1,'R');
$pdf->Ln(10);

// Datos del alquiler
$pdf->Cell(50,10,"Cliente:",0,0);
$pdf->Cell(0,10,$data['cliente'],0,1);
$pdf->Cell(50,10,"Vehiculo:",0,0);
$pdf->Cell(0,10,$data['modelo']." (".$data['patente'].")",0,1);
$pdf->Cell(50,10,"Sucursal:",0,0);
$pdf->Cell(0,10,$data['sucursal'],0,1);

// Validar que los campos existan
$fechaInicio = $data['fechaInicio'] ?? 'N/A';
$fechaFin    = $data['fechaFin'] ?? 'N/A';
$total       = isset($data['total']) ? "$".$data['total'] : 'N/A';

$pdf->Cell(50,10,"Inicio:",0,0);
$pdf->Cell(0,10,$fechaInicio,0,1);
$pdf->Cell(50,10,"Fin:",0,0);
$pdf->Cell(0,10,$fechaFin,0,1);

$pdf->Ln(10);
$pdf->Cell(0,10,"Gracias por elegir Herz.",0,1,'C');

// Cerrar conexión
$conn->close();

// Mostrar PDF en navegador
$pdf->Output('I', 'Comprobante_Alquiler_'.$data['id'].'.pdf');
?>
