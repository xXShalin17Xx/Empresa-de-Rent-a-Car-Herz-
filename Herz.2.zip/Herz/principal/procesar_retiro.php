<?php
include("../principal/config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reserva_id = $_POST['reserva_id'] ?? null;

    if (!$reserva_id) {
        http_response_code(400);
        echo "Faltan datos para procesar el retiro.";
        exit;
    }

    try {
        // Iniciar transacción
        $conn->begin_transaction();

        // 1. Obtener datos de la reserva
        $stmt = $conn->prepare("
            SELECT tipoVehiculo, idSucursal 
            FROM Reservas 
            WHERE id = ? AND estado = 'pendiente'
        ");
        $stmt->bind_param("i", $reserva_id);
        $stmt->execute();
        $reserva = $stmt->get_result()->fetch_assoc();

        if (!$reserva) {
            throw new Exception("Reserva no encontrada o ya confirmada.");
        }

        $tipoVehiculo = $reserva['tipoVehiculo'];
        $idSucursal = $reserva['idSucursal'];

        // 2. Buscar un vehículo disponible de ese tipo en la sucursal
        $stmt = $conn->prepare("
            SELECT id, kilometraje 
            FROM Vehiculos 
            WHERE tipo = ? AND idSucursal = ? AND estado = 'disponible'
            LIMIT 1
        ");
        $stmt->bind_param("si", $tipoVehiculo, $idSucursal);
        $stmt->execute();
        $vehiculo = $stmt->get_result()->fetch_assoc();

        if (!$vehiculo) {
            throw new Exception("No hay vehículos disponibles de este tipo en la sucursal.");
        }

        $vehiculo_id = $vehiculo['id'];
        $kmInicial = $vehiculo['kilometraje'];

        // 3. Crear registro en Alquileres
        $stmt = $conn->prepare("
            INSERT INTO Alquileres (idReserva, idVehiculo, fechaRetiro, kmInicial)
            VALUES (?, ?, NOW(), ?)
        ");
        $stmt->bind_param("iid", $reserva_id, $vehiculo_id, $kmInicial);
        $stmt->execute();

        // 4. Cambiar estado del vehículo a 'alquilado'
        $stmt = $conn->prepare("
            UPDATE Vehiculos 
            SET estado = 'alquilado' 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $vehiculo_id);
        $stmt->execute();

        // 5. Actualizar reserva con idVehiculo y estado 'en curso'
        $stmt = $conn->prepare("
            UPDATE Reservas 
            SET estado = 'en curso', idVehiculo = ?
            WHERE id = ?
        ");
        $stmt->bind_param("ii", $vehiculo_id, $reserva_id);
        $stmt->execute();

        // Confirmar transacción
        $conn->commit();

        header("Location: confirmar_retiro.php?reserva_id=" . urlencode($reserva_id));
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo "Error al procesar el retiro: " . $e->getMessage();
    }
} else {
    http_response_code(405);
    echo "Método no permitido.";
}
?>
