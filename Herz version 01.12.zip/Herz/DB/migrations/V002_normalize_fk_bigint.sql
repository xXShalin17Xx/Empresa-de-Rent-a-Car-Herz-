-- V002_normalize_fk_bigint_FIXED.sql
-- Ejecutar en STAGING. Hacer BACKUP antes.
SET FOREIGN_KEY_CHECKS = 0;

DELIMITER $$
  
DROP PROCEDURE IF EXISTS sp_normalize_v002$$

CREATE PROCEDURE sp_normalize_v002()
BEGIN
  DECLARE v_sql TEXT;
  DECLARE v_count INT;
  DECLARE v_fk_name VARCHAR(64);
  DECLARE done INT DEFAULT 0;
 
  -- Cursor para encontrar y borrar FKs dinámicamente en las tablas afectadas
  DECLARE cur_fks CURSOR FOR
    SELECT CONSTRAINT_NAME, TABLE_NAME
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND REFERENCED_TABLE_NAME IS NOT NULL
    AND TABLE_NAME IN ('alquileres', 'reservas', 'vehiculos', 'clientes', 'mantenimiento');
   
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

  -- 1) ELIMINAR FKS EXISTENTES (Dinámico)
  OPEN cur_fks;
  read_loop: LOOP
    FETCH cur_fks INTO v_fk_name, v_sql; -- Usamos v_sql temporalmente para guardar table_name
    IF done THEN LEAVE read_loop; END IF;
   
    SET @drop_stmt = CONCAT('ALTER TABLE ', v_sql, ' DROP FOREIGN KEY ', v_fk_name);
    PREPARE stmt FROM @drop_stmt;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END LOOP;
  CLOSE cur_fks;
 
  -- Resetear handler
  SET done = 0;

  -- ==============================================================================
  -- 2) AGREGAR COLUMNAS snake_case (BIGINT) SI NO EXISTEN
  -- ==============================================================================
 
  -- Reservas
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='id_cliente') THEN
    SET @s = 'ALTER TABLE reservas ADD COLUMN id_cliente BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='id_vehiculo') THEN
    SET @s = 'ALTER TABLE reservas ADD COLUMN id_vehiculo BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='id_sucursal') THEN
    SET @s = 'ALTER TABLE reservas ADD COLUMN id_sucursal BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- Alquileres
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='alquileres' AND COLUMN_NAME='id_reserva') THEN
    SET @s = 'ALTER TABLE alquileres ADD COLUMN id_reserva BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='alquileres' AND COLUMN_NAME='id_vehiculo') THEN
    SET @s = 'ALTER TABLE alquileres ADD COLUMN id_vehiculo BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- Vehiculos
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='vehiculos' AND COLUMN_NAME='id_sucursal') THEN
    SET @s = 'ALTER TABLE vehiculos ADD COLUMN id_sucursal BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- Mantenimiento
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='mantenimiento' AND COLUMN_NAME='id_vehiculo') THEN
    SET @s = 'ALTER TABLE mantenimiento ADD COLUMN id_vehiculo BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- Clientes 
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='clientes' AND COLUMN_NAME='id_rol') THEN
    SET @s = 'ALTER TABLE clientes ADD COLUMN id_rol BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='clientes' AND COLUMN_NAME='id_sucursal') THEN
    SET @s = 'ALTER TABLE clientes ADD COLUMN id_sucursal BIGINT DEFAULT NULL'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- ==============================================================================
  -- 3) COPIAR DATOS (camelCase -> snake_case)
  -- ==============================================================================
 
  -- Reservas
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idCliente') THEN
    UPDATE reservas SET id_cliente = idCliente WHERE id_cliente IS NULL;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idVehiculo') THEN
    UPDATE reservas SET id_vehiculo = idVehiculo WHERE id_vehiculo IS NULL;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idSucursal') THEN
    UPDATE reservas SET id_sucursal = idSucursal WHERE id_sucursal IS NULL;
  END IF;

  -- Alquileres
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='alquileres' AND COLUMN_NAME='idReserva') THEN
    UPDATE alquileres SET id_reserva = idReserva WHERE id_reserva IS NULL;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='alquileres' AND COLUMN_NAME='idVehiculo') THEN
    UPDATE alquileres SET id_vehiculo = idVehiculo WHERE id_vehiculo IS NULL;
  END IF;

  -- Vehiculos
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='vehiculos' AND COLUMN_NAME='idSucursal') THEN
    UPDATE vehiculos SET id_sucursal = idSucursal WHERE id_sucursal IS NULL;
  END IF;

  -- Mantenimiento
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='mantenimiento' AND COLUMN_NAME='idVehiculo') THEN
    UPDATE mantenimiento SET id_vehiculo = idVehiculo WHERE id_vehiculo IS NULL;
  END IF;

  -- Clientes
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='clientes' AND COLUMN_NAME='idRol') THEN
    UPDATE clientes SET id_rol = idRol WHERE id_rol IS NULL;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='clientes' AND COLUMN_NAME='idSucursal') THEN
    UPDATE clientes SET id_sucursal = idSucursal WHERE id_sucursal IS NULL;
  END IF;

  -- ==============================================================================
  -- 4) ELIMINAR COLUMNAS camelCase (Solo si existen las snake_case)
  -- ==============================================================================
 
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idCliente') THEN
    SET @s = 'ALTER TABLE reservas DROP COLUMN idCliente'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idVehiculo') THEN
    SET @s = 'ALTER TABLE reservas DROP COLUMN idVehiculo'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='reservas' AND COLUMN_NAME='idSucursal') THEN
    SET @s = 'ALTER TABLE reservas DROP COLUMN idSucursal'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='alquileres' AND COLUMN_NAME='idReserva') THEN
    SET @s = 'ALTER TABLE alquileres DROP COLUMN idReserva'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='alquileres' AND COLUMN_NAME='idVehiculo') THEN
    SET @s = 'ALTER TABLE alquileres DROP COLUMN idVehiculo'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='vehiculos' AND COLUMN_NAME='idSucursal') THEN
    SET @s = 'ALTER TABLE vehiculos DROP COLUMN idSucursal'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='mantenimiento' AND COLUMN_NAME='idVehiculo') THEN
    SET @s = 'ALTER TABLE mantenimiento DROP COLUMN idVehiculo'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='clientes' AND COLUMN_NAME='idRol') THEN
    SET @s = 'ALTER TABLE clientes DROP COLUMN idRol'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
  IF EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='clientes' AND COLUMN_NAME='idSucursal') THEN
    SET @s = 'ALTER TABLE clientes DROP COLUMN idSucursal'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- ==============================================================================
  -- 5) CONVERTIR PRIMARY KEYS A BIGINT
  -- ==============================================================================
  SET @s = 'ALTER TABLE sucursales MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE clientes MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE vehiculos MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE reservas MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE alquileres MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE mantenimiento MODIFY COLUMN id BIGINT AUTO_INCREMENT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  SET @s = 'ALTER TABLE roles MODIFY COLUMN id BIGINT'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  -- ==============================================================================
  -- 6) CAMPOS ADICIONALES (Imagen y Descripción)
  -- ==============================================================================
  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='vehiculos' AND COLUMN_NAME='imagen') THEN
    SET @s = 'ALTER TABLE vehiculos ADD COLUMN imagen VARCHAR(255) NULL AFTER tipo'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  IF NOT EXISTS(SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='vehiculos' AND COLUMN_NAME='descripcion') THEN
    SET @s = 'ALTER TABLE vehiculos ADD COLUMN descripcion TEXT NULL AFTER imagen'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;

  -- ==============================================================================
  -- 7) CREAR ÍNDICES
  -- ==============================================================================
  -- Usamos un bloque anónimo con handler para ignorar error "Duplicate key name"
  BEGIN
    DECLARE CONTINUE HANDLER FOR 1061 BEGIN END; -- Duplicate key name
   
    SET @s = 'CREATE INDEX idx_vehiculos_tipo ON vehiculos(tipo)'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
    SET @s = 'CREATE INDEX idx_vehiculos_estado ON vehiculos(estado)'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
    SET @s = 'CREATE INDEX idx_vehiculos_sucursal ON vehiculos(id_sucursal)'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
    SET @s = 'CREATE INDEX idx_reservas_estado ON reservas(estado)'; PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END;

  -- ==============================================================================
  -- 8) CREAR NUEVAS FOREIGN KEYS (Todas apuntando a BIGINT)
  -- ==============================================================================
 
  -- Clientes (Roles y Sucursales)
  SET @s = 'ALTER TABLE clientes ADD CONSTRAINT fk_clientes_rol FOREIGN KEY (id_rol) REFERENCES roles(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  SET @s = 'ALTER TABLE clientes ADD CONSTRAINT fk_clientes_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursales(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  -- Vehiculos
  SET @s = 'ALTER TABLE vehiculos ADD CONSTRAINT fk_vehiculos_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursales(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  -- Reservas
  SET @s = 'ALTER TABLE reservas ADD CONSTRAINT fk_reservas_cliente FOREIGN KEY (id_cliente) REFERENCES clientes(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  SET @s = 'ALTER TABLE reservas ADD CONSTRAINT fk_reservas_vehiculo FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  SET @s = 'ALTER TABLE reservas ADD CONSTRAINT fk_reservas_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursales(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  -- Alquileres
  SET @s = 'ALTER TABLE alquileres ADD CONSTRAINT fk_alquileres_reserva FOREIGN KEY (id_reserva) REFERENCES reservas(id) ON DELETE CASCADE';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  SET @s = 'ALTER TABLE alquileres ADD CONSTRAINT fk_alquileres_vehiculo FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

  -- Mantenimiento
  SET @s = 'ALTER TABLE mantenimiento ADD CONSTRAINT fk_mantenimiento_vehiculo FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id)';
  PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

END$$

DELIMITER ;

-- Ejecutar el procedimiento
CALL sp_normalize_v002();

-- Limpieza
DROP PROCEDURE IF EXISTS sp_normalize_v002;


SET FOREIGN_KEY_CHECKS = 1;