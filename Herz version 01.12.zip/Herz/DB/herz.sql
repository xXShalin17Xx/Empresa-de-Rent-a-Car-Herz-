CREATE DATABASE IF NOT EXISTS Herz;
USE Herz;

-- Tabla de roles
CREATE TABLE Roles (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

-- Tabla de sucursales
CREATE TABLE Sucursales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(150),
    telefono VARCHAR(20)
);

-- Tabla de clientes
CREATE TABLE Clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    dni VARCHAR(15) NOT NULL UNIQUE,
    licencia VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    telefono VARCHAR(20),
    contrasena VARCHAR(255) NOT NULL,
    fechaRegistro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    idRol INT DEFAULT 1,  -- Por defecto, cliente
    idSucursal INT NULL,  -- Solo aplica a empleados
    FOREIGN KEY (idRol) REFERENCES Roles(id),
    FOREIGN KEY (idSucursal) REFERENCES Sucursales(id)
);


-- Tabla de vehículos
CREATE TABLE Vehiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patente VARCHAR(10) NOT NULL UNIQUE,
    modelo VARCHAR(50),
    tipo VARCHAR(50), 
    estado ENUM('disponible', 'alquilado', 'mantenimiento') DEFAULT 'disponible',
    idSucursal INT,
    kilometraje DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (idSucursal) REFERENCES Sucursales(id)
);

-- Tabla de reservas
CREATE TABLE Reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('pendiente', 'en curso', 'finalizada', 'cancelada') DEFAULT 'pendiente',
    idSucursal INT,
    idCliente INT,
    idVehiculo INT,
    tipoVehiculo VARCHAR(50), 
    fechaInicio DATE,
    fechaFin DATE,
    FOREIGN KEY (idCliente) REFERENCES Clientes(id),
    FOREIGN KEY (idSucursal) REFERENCES Sucursales(id),
    FOREIGN KEY (idVehiculo) REFERENCES Vehiculos(id)
    
);



-- Tabla de alquileres 
CREATE TABLE Alquileres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idReserva INT,
    fechaRetiro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fechaDevolucion TIMESTAMP NULL,
    kmInicial DECIMAL(10,2),
    kmFinal DECIMAL(10,2),
    idVehiculo INT,
    estado ENUM('en curso', 'finalizado', 'cancelado') DEFAULT 'en curso',
    FOREIGN KEY (idReserva) REFERENCES Reservas(id) ON DELETE CASCADE,
    FOREIGN KEY (idVehiculo) REFERENCES Vehiculos(id)
);


-- Tabla de mantenimiento
CREATE TABLE Mantenimiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idVehiculo INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tipo VARCHAR(50), -- ej: cambio de aceite, revisión, etc.
    costo DECIMAL(10,2),
    estado ENUM('pendiente', 'completado') DEFAULT 'pendiente',
    fechaCompletado DATETIME DEFAULT NULL,
    FOREIGN KEY (idVehiculo) REFERENCES Vehiculos(id)
);




INSERT INTO Roles (id, nombre) VALUES
(1, 'cliente'),
(2, 'empleado_sucursal'),
(3, 'coordinador_flotas'),
(4, 'personal_mantenimiento'),
(5, 'admin');



-- para cambiar los roles de los usuarios manualmente
UPDATE Clientes
SET idRol = 3
WHERE id = 5;

--- 1) Insertar sucursales (primero)
INSERT INTO Sucursales (nombre, direccion, telefono) VALUES
('Sucursal Palermo', 'Av. Santa Fe 3456, Palermo, CABA', '011-4321-1000'),
('Sucursal Caballito', 'Av. Rivadavia 5400, Caballito, CABA', '011-4321-1001'),
('Sucursal Belgrano', 'Juramento 2345, Belgrano, CABA', '011-4321-1002'),
('Sucursal Recoleta', 'Av. Callao 1500, Recoleta, CABA', '011-4321-1003'),
('Sucursal Constitución', 'Lima 800, Constitución, CABA', '011-4321-1004');

-- 2) Insertar vehículos Económicos (tipo normalizado: economico)
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('AB123CD', 'Toyota Yaris', 'economico', 'disponible', 1, 25300.75),
('CD234EF', 'Hyundai i10', 'economico', 'disponible', 1, 18750.20),
('EF345GH', 'Kia Picanto', 'economico', 'mantenimiento', 1, 32100.50),
('GH456IJ', 'Chevrolet Spark', 'economico', 'disponible', 1, 29450.10),
('IJ567KL', 'Nissan March', 'economico', 'alquilado', 1, 36890.00);

-- 3) Insertar vehículos Eléctricos (tipo normalizado: electrico)
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('EL101AA', 'Tesla Model 3', 'electrico', 'disponible', 1, 10500.00),
('EL202BB', 'Nissan Leaf', 'electrico', 'disponible', 1, 8800.30),
('EL303CC', 'BMW i3', 'electrico', 'alquilado', 1, 7600.00),
('EL404DD', 'Renault Zoe', 'electrico', 'disponible', 1, 4950.70),
('EL505EE', 'Hyundai Kona Electric', 'electrico', 'mantenimiento', 1, 6200.40);

-- 4) Insertar vehículos SUV (tipo normalizado: suv)
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('SUV111AA', 'Toyota RAV4', 'suv', 'disponible', 1, 45000.00),
('SUV222BB', 'Ford Escape', 'suv', 'disponible', 1, 39200.55),
('SUV333CC', 'Honda CR-V', 'suv', 'alquilado', 1, 41750.90),
('SUV444DD', 'Kia Sportage', 'suv', 'mantenimiento', 1, 46230.20),
('SUV555EE', 'Hyundai Tucson', 'suv', 'disponible', 1, 38500.00);

-- 5) Insertar vehículos De lujo (tipo normalizado: lujo)
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('LUX111AA', 'Mercedes-Benz C-Class', 'lujo', 'disponible', 1, 21400.00),
('LUX222BB', 'BMW 5 Series', 'lujo', 'disponible', 1, 19850.00),
('LUX333CC', 'Audi A6', 'lujo', 'alquilado', 1, 23500.80),
('LUX444DD', 'Lexus ES 350', 'lujo', 'disponible', 1, 17200.10),
('LUX555EE', 'Jaguar XF', 'lujo', 'mantenimiento', 1, 26500.65);


DELIMITER //

-- =============================================
-- 1. sp_ProcesarReserva
-- =============================================
DROP PROCEDURE IF EXISTS sp_ProcesarReserva//

CREATE PROCEDURE sp_ProcesarReserva (
    IN p_nombre VARCHAR(100),
    IN p_email VARCHAR(100),
    IN p_tipoVehiculo VARCHAR(50),
    IN p_fechaInicio DATETIME,
    IN p_fechaFin DATETIME,
    IN p_idSucursal BIGINT
)
BEGIN
    DECLARE v_idCliente BIGINT;

    -- Buscar el cliente por nombre y email
    SELECT id INTO v_idCliente
    FROM Clientes
    WHERE nombre = p_nombre AND email = p_email
    LIMIT 1;

    IF v_idCliente IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente no encontrado. Asegúrese de estar registrado.';
    ELSE
        -- Insertar usando los nuevos nombres de columna (snake_case)
        INSERT INTO Reservas (estado, id_cliente, tipoVehiculo, fechaInicio, fechaFin, id_sucursal)
        VALUES ('pendiente', v_idCliente, p_tipoVehiculo, p_fechaInicio, p_fechaFin, p_idSucursal);
    END IF;
END //

-- =============================================
-- 2. sp_ProcesarRetiroAuto
-- =============================================
DROP PROCEDURE IF EXISTS sp_ProcesarRetiroAuto//

CREATE PROCEDURE sp_ProcesarRetiroAuto (
    IN p_idReserva BIGINT
)
BEGIN
    DECLARE v_tipoVehiculo VARCHAR(50);
    DECLARE v_idSucursal BIGINT;
    DECLARE v_idVehiculo BIGINT;
    DECLARE v_kmInicial DECIMAL(10,2);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error interno al procesar el retiro.';
    END;

    START TRANSACTION;

    -- Usamos id_sucursal (snake_case)
    SELECT tipoVehiculo, id_sucursal
    INTO v_tipoVehiculo, v_idSucursal
    FROM Reservas
    WHERE id = p_idReserva AND estado = 'pendiente'
    LIMIT 1;

    IF v_tipoVehiculo IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Reserva no encontrada o ya confirmada.';
    END IF;

    -- Buscamos vehículo disponible usando id_sucursal
    SELECT id, kilometraje
    INTO v_idVehiculo, v_kmInicial
    FROM Vehiculos
    WHERE tipo = v_tipoVehiculo
      AND id_sucursal = v_idSucursal
      AND estado = 'disponible'
    LIMIT 1;

    IF v_idVehiculo IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'No hay vehículos disponibles de este tipo en la sucursal.';
    END IF;

    -- Insertar en Alquileres usando id_reserva e id_vehiculo
    INSERT INTO Alquileres (id_reserva, id_vehiculo, fechaRetiro, kmInicial)
    VALUES (p_idReserva, v_idVehiculo, NOW(), v_kmInicial);

    UPDATE Vehiculos
    SET estado = 'alquilado'
    WHERE id = v_idVehiculo;
    
    -- Actualizar Reserva usando id_vehiculo
    UPDATE Reservas
    SET estado = 'en curso',
        id_vehiculo = v_idVehiculo
    WHERE id = p_idReserva;

    COMMIT;
END //

-- =============================================
-- 3. sp_RegistrarDevolucionVehiculo
-- =============================================
DROP PROCEDURE IF EXISTS sp_RegistrarDevolucionVehiculo//

CREATE PROCEDURE sp_RegistrarDevolucionVehiculo (
    IN p_idAlquiler BIGINT,
    IN p_kmFinal DECIMAL(10,2),
    IN p_danios TEXT
)
BEGIN
    DECLARE v_idVehiculo BIGINT;
    DECLARE v_idReserva BIGINT;
    DECLARE v_kmInicial DECIMAL(10,2);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error al registrar la devolución.';
    END;

    START TRANSACTION;

    -- Recuperar datos usando los nombres normalizados
    SELECT id_vehiculo, id_reserva, kmInicial
    INTO v_idVehiculo, v_idReserva, v_kmInicial
    FROM Alquileres
    WHERE id = p_idAlquiler
    LIMIT 1;

    IF v_idVehiculo IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Alquiler no encontrado.';
    END IF;

    UPDATE Alquileres
    SET fechaDevolucion = NOW(),
        kmFinal = p_kmFinal,
        estado = 'finalizado'
    WHERE id = p_idAlquiler;

    UPDATE Vehiculos
    SET estado = 'disponible',
        kilometraje = p_kmFinal
    WHERE id = v_idVehiculo;

    UPDATE Reservas
    SET estado = 'finalizada'
    WHERE id = v_idReserva;

    IF p_danios IS NOT NULL AND p_danios != '' THEN
        INSERT INTO Mantenimiento (id_vehiculo, tipo, costo, estado)
        VALUES (v_idVehiculo, p_danios, 0, 'pendiente');
    END IF;

    COMMIT;
END //

-- =============================================
-- 4. sp_CancelarReserva
-- =============================================
DROP PROCEDURE IF EXISTS sp_CancelarReserva//

CREATE PROCEDURE sp_CancelarReserva(IN p_idReserva BIGINT, IN p_idCliente BIGINT)
BEGIN
    DECLARE vEstadoActual VARCHAR(20);

    -- Verificar reserva usando id_cliente
    SELECT estado INTO vEstadoActual
    FROM Reservas
    WHERE id = p_idReserva AND id_cliente = p_idCliente;

    IF vEstadoActual IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La reserva no existe o no pertenece al cliente';
    ELSEIF vEstadoActual NOT IN ('pendiente', 'confirmada') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La reserva no puede cancelarse';
    ELSE
        UPDATE Reservas 
        SET estado = 'cancelada'
        WHERE id = p_idReserva;
    END IF;
END //

-- =============================================
-- 5. sp_HistorialAlquileresPorCliente
-- =============================================
DROP PROCEDURE IF EXISTS sp_HistorialAlquileresPorCliente//

CREATE PROCEDURE sp_HistorialAlquileresPorCliente (IN p_idCliente BIGINT)
BEGIN
    SELECT 
        A.id AS idAlquiler,
        R.id AS idReserva,
        V.modelo,
        V.patente,
        S.nombre AS sucursal,
        A.fechaRetiro,
        A.fechaDevolucion,
        A.kmInicial,
        A.kmFinal,
        R.estado AS estadoReserva
    FROM Alquileres A
        INNER JOIN Reservas R ON A.id_reserva = R.id
        INNER JOIN Vehiculos V ON A.id_vehiculo = V.id
        LEFT JOIN Sucursales S ON V.id_sucursal = S.id
    WHERE R.id_cliente = p_idCliente
    ORDER BY A.fechaRetiro DESC;
END //

DELIMITER ;

-- =============================================
-- TRIGGERS CORREGIDOS
-- =============================================

DELIMITER $$

DROP TRIGGER IF EXISTS trg_actualizar_estado_vehiculo_al_retirar$$
CREATE TRIGGER trg_actualizar_estado_vehiculo_al_retirar
AFTER INSERT ON Alquileres
FOR EACH ROW
BEGIN
  -- id_vehiculo (snake_case)
  UPDATE Vehiculos
  SET estado = 'alquilado'
  WHERE id = NEW.id_vehiculo;
END$$

DROP TRIGGER IF EXISTS trg_actualizar_estado_vehiculo_al_devolver$$
CREATE TRIGGER trg_actualizar_estado_vehiculo_al_devolver
AFTER UPDATE ON Alquileres
FOR EACH ROW
BEGIN
  -- id_vehiculo (snake_case) pero fechaDevolucion (camelCase original)
  IF NEW.fechaDevolucion IS NOT NULL AND OLD.fechaDevolucion IS NULL THEN
    UPDATE Vehiculos
    SET estado = 'disponible'
    WHERE id = NEW.id_vehiculo;
  END IF;
END$$

DROP TRIGGER IF EXISTS trg_registrar_mantenimiento_agregado$$
CREATE TRIGGER trg_registrar_mantenimiento_agregado
AFTER INSERT ON Mantenimiento
FOR EACH ROW
BEGIN
  UPDATE Vehiculos
  SET estado = 'mantenimiento'
  WHERE id = NEW.id_vehiculo;
END$$

DROP TRIGGER IF EXISTS trg_finalizar_mantenimiento$$
CREATE TRIGGER trg_finalizar_mantenimiento
AFTER UPDATE ON Mantenimiento
FOR EACH ROW
BEGIN
  IF NEW.estado = 'completado' AND OLD.estado != 'completado' THEN
    UPDATE Vehiculos
    SET estado = 'disponible'
    WHERE id = NEW.id_vehiculo;
  END IF;
END$$

DELIMITER ;