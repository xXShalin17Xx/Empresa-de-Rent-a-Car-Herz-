# Migrations: V002_normalize_fk_bigint.sql

Precondiciones
- Tener backup: db/backup/herz.sql
- Usuario con permisos ALTER, CREATE, DROP, INDEX en la BD.

Aplicación
1. Conectar a la BD Herz (phpMyAdmin o mysql CLI).
2. Ejecutar: SET FOREIGN_KEY_CHECKS = 0;
3. Ejecutar el archivo: db/migrations/V002_normalize_fk_bigint.sql
4. Ejecutar: SET FOREIGN_KEY_CHECKS = 1;
5. Verificar: SHOW CREATE TABLE reservas; SHOW CREATE TABLE alquileres; SHOW CREATE TABLE vehiculos; SHOW CREATE TABLE clientes; SHOW CREATE TABLE sucursales; SHOW CREATE TABLE mantenimiento;
6. Comprobaciones de integridad:
   - Verificar que no haya FKs huérfanas (consultas en el repo).

Rollback
- Si algo sale mal: restaurar db/backup/herz.sql (IMPORT). No existe rollback automático.

Notas
- El script es idempotente; puede ejecutarse varias veces sin efectos adversos.