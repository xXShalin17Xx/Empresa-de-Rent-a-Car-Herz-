-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2025 a las 15:01:09
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `herz`
--
CREATE DATABASE IF NOT EXISTS `herz` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `herz`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alquileres`
--

DROP TABLE IF EXISTS `alquileres`;
CREATE TABLE `alquileres` (
  `id` bigint(20) NOT NULL,
  `idReserva` int(11) DEFAULT NULL,
  `fechaRetiro` timestamp NOT NULL DEFAULT current_timestamp(),
  `fechaDevolucion` timestamp NULL DEFAULT NULL,
  `kmInicial` decimal(10,2) DEFAULT NULL,
  `kmFinal` decimal(10,2) DEFAULT NULL,
  `idVehiculo` int(11) DEFAULT NULL,
  `estado` enum('en curso','finalizado','cancelado') DEFAULT 'en curso',
  `fecha_devolucion` datetime(6) DEFAULT NULL,
  `fecha_retiro` datetime(6) DEFAULT NULL,
  `km_final` double DEFAULT NULL,
  `km_inicial` double DEFAULT NULL,
  `id_reserva` bigint(20) DEFAULT NULL,
  `id_vehiculo` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `dni` varchar(15) NOT NULL,
  `licencia` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `contrasena` varchar(255) NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp(),
  `idRol` int(11) DEFAULT 1,
  `idSucursal` int(11) DEFAULT NULL,
  `id_rol` bigint(20) DEFAULT NULL,
  `id_sucursal` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `dni`, `licencia`, `email`, `telefono`, `contrasena`, `fechaRegistro`, `idRol`, `idSucursal`, `id_rol`, `id_sucursal`) VALUES
(1, 'Empleado Sucursal', '30123456', 'EMP1234', 'empleado@prueba.com', '011-5555-0002', 'password', '2025-11-18 16:10:37', 2, NULL, NULL, NULL),
(2, 'Coordinador Flotas', '40123456', 'COORD123', 'coordinador@prueba.com', '011-5555-0003', 'password', '2025-11-18 16:10:37', 3, NULL, NULL, NULL),
(3, 'Mantenimiento', '50123456', 'MANT123', 'mantenimiento@prueba.com', '011-5555-0004', 'password', '2025-11-18 16:10:37', 4, NULL, NULL, NULL),
(4, 'Admin', '10123456', 'ADMIN123', 'admin@prueba.com', '011-5555-0005', 'password', '2025-11-18 16:10:37', 5, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimiento`
--

DROP TABLE IF EXISTS `mantenimiento`;
CREATE TABLE `mantenimiento` (
  `id` bigint(20) NOT NULL,
  `idVehiculo` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `tipo` varchar(50) DEFAULT NULL,
  `costo` double DEFAULT NULL,
  `estado` enum('pendiente','completado') DEFAULT 'pendiente',
  `fechaCompletado` datetime DEFAULT NULL,
  `id_vehiculo` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

DROP TABLE IF EXISTS `reservas`;
CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `idSucursal` int(11) DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL,
  `idVehiculo` int(11) DEFAULT NULL,
  `tipoVehiculo` varchar(50) DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `tipo_vehiculo` varchar(255) DEFAULT NULL,
  `id_cliente` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `estado`, `idSucursal`, `idCliente`, `idVehiculo`, `tipoVehiculo`, `fechaInicio`, `fechaFin`, `fecha_fin`, `fecha_inicio`, `tipo_vehiculo`, `id_cliente`) VALUES
(1, 'pendiente', NULL, NULL, NULL, 'electrico', '2025-11-23', '2025-11-25', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`) VALUES
(5, 'admin'),
(1, 'cliente'),
(3, 'coordinador_flotas'),
(2, 'empleado_sucursal'),
(4, 'personal_mantenimiento');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursales`
--

DROP TABLE IF EXISTS `sucursales`;
CREATE TABLE `sucursales` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sucursales`
--

INSERT INTO `sucursales` (`id`, `nombre`, `direccion`, `telefono`) VALUES
(11, 'Sucursal Palermo', 'Av. Santa Fe 3456, Palermo, CABA', '011-4321-1000'),
(12, 'Sucursal Caballito', 'Av. Rivadavia 5400, Caballito, CABA', '011-4321-1001'),
(13, 'Sucursal Belgrano', 'Juramento 2345, Belgrano, CABA', '011-4321-1002'),
(14, 'Sucursal Recoleta', 'Av. Callao 1500, Recoleta, CABA', '011-4321-1003'),
(15, 'Sucursal Constitución', 'Lima 800, Constitución, CABA', '011-4321-1004'),
(16, 'Sucursal Palermo', 'Av. Santa Fe 3456, Palermo, CABA', '011-4321-1000'),
(17, 'Sucursal Caballito', 'Av. Rivadavia 5400, Caballito, CABA', '011-4321-1001'),
(18, 'Sucursal Belgrano', 'Juramento 2345, Belgrano, CABA', '011-4321-1002'),
(19, 'Sucursal Recoleta', 'Av. Callao 1500, Recoleta, CABA', '011-4321-1003'),
(20, 'Sucursal Constitución', 'Lima 800, Constitución, CABA', '011-4321-1004');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

DROP TABLE IF EXISTS `vehiculos`;
CREATE TABLE `vehiculos` (
  `id` int(11) NOT NULL,
  `patente` varchar(10) NOT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `estado` enum('disponible','alquilado','mantenimiento') DEFAULT 'disponible',
  `idSucursal` int(11) DEFAULT NULL,
  `kilometraje` double DEFAULT NULL,
  `id_sucursal` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id`, `patente`, `modelo`, `tipo`, `estado`, `idSucursal`, `kilometraje`, `id_sucursal`) VALUES
(11, 'CD234EF', 'Hyundai i10', 'economico', 'disponible', NULL, 18750.2, NULL),
(12, 'EF345GH', 'Kia Picanto', 'economico', 'mantenimiento', NULL, 32100.5, NULL),
(13, 'GH456IJ', 'Chevrolet Spark', 'economico', 'disponible', NULL, 29450.1, NULL),
(14, 'IJ567KL', 'Nissan March', 'economico', 'alquilado', NULL, 36890, NULL),
(15, 'EL101AA', 'Tesla Model 3', 'electrico', 'disponible', NULL, 10500, NULL),
(16, 'EL202BB', 'Nissan Leaf', 'electrico', 'disponible', NULL, 8800.3, NULL),
(17, 'EL303CC', 'BMW i3', 'electrico', 'alquilado', NULL, 7600, NULL),
(18, 'EL404DD', 'Renault Zoe', 'electrico', 'disponible', NULL, 4950.7, NULL),
(19, 'EL505EE', 'Hyundai Kona Electric', 'electrico', 'mantenimiento', NULL, 6200.4, NULL),
(20, 'SUV111AA', 'Toyota RAV4', 'suv', 'disponible', NULL, 45000, NULL),
(21, 'SUV222BB', 'Ford Escape', 'suv', 'disponible', NULL, 39200.55, NULL),
(22, 'SUV333CC', 'Honda CR-V', 'suv', 'alquilado', NULL, 41750.9, NULL),
(23, 'SUV444DD', 'Kia Sportage', 'suv', 'mantenimiento', NULL, 46230.2, NULL),
(24, 'SUV555EE', 'Hyundai Tucson', 'suv', 'disponible', NULL, 38500, NULL),
(25, 'LUX111AA', 'Mercedes-Benz C-Class', 'lujo', 'disponible', NULL, 21400, NULL),
(26, 'LUX222BB', 'BMW 5 Series', 'lujo', 'disponible', NULL, 19850, NULL),
(27, 'LUX333CC', 'Audi A6', 'lujo', 'alquilado', NULL, 23500.8, NULL),
(28, 'LUX444DD', 'Lexus ES 350', 'lujo', 'disponible', NULL, 17200.1, NULL),
(29, 'LUX555EE', 'Jaguar XF', 'lujo', 'mantenimiento', NULL, 26500.65, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alquileres`
--
ALTER TABLE `alquileres`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idReserva` (`idReserva`),
  ADD KEY `idVehiculo` (`idVehiculo`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dni` (`dni`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idRol` (`idRol`),
  ADD KEY `idSucursal` (`idSucursal`);

--
-- Indices de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idVehiculo` (`idVehiculo`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idCliente` (`idCliente`),
  ADD KEY `idSucursal` (`idSucursal`),
  ADD KEY `idVehiculo` (`idVehiculo`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patente` (`patente`),
  ADD KEY `idSucursal` (`idSucursal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alquileres`
--
ALTER TABLE `alquileres`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alquileres`
--
ALTER TABLE `alquileres`
  ADD CONSTRAINT `alquileres_ibfk_1` FOREIGN KEY (`idReserva`) REFERENCES `reservas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alquileres_ibfk_2` FOREIGN KEY (`idVehiculo`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`idRol`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`idSucursal`) REFERENCES `sucursales` (`id`);

--
-- Filtros para la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD CONSTRAINT `mantenimiento_ibfk_1` FOREIGN KEY (`idVehiculo`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `reservas_ibfk_2` FOREIGN KEY (`idSucursal`) REFERENCES `sucursales` (`id`),
  ADD CONSTRAINT `reservas_ibfk_3` FOREIGN KEY (`idVehiculo`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD CONSTRAINT `vehiculos_ibfk_1` FOREIGN KEY (`idSucursal`) REFERENCES `sucursales` (`id`);


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla alquileres
--

--
-- Metadatos para la tabla clientes
--

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'herz', 'clientes', '{\"sorted_col\":\"`clientes`.`idRol` ASC\"}', '2025-11-18 16:13:38');

--
-- Metadatos para la tabla mantenimiento
--

--
-- Metadatos para la tabla reservas
--

--
-- Metadatos para la tabla roles
--

--
-- Metadatos para la tabla sucursales
--

--
-- Metadatos para la tabla vehiculos
--

--
-- Metadatos para la base de datos herz
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
