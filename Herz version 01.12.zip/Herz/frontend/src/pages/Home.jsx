import "../styles/principal.css";
import { useNavigate } from "react-router-dom";

const categorias = [
  { id: "economico", nombre: "Económicos", imagen: require("../assets/carrousel-img/economico.jpg") },
  { id: "electrico", nombre: "Eléctricos", imagen: require("../assets/carrousel-img/electrico.jpg") },
  { id: "suv", nombre: "SUV", imagen: require("../assets/carrousel-img/suv.jpg") },
  { id: "lujo", nombre: "De lujo", imagen: require("../assets/carrousel-img/xlujo.jpg") },
];

const Home = () => {
  const navigate = useNavigate();

  return (
    <div style={{
      width: "100%",
      height: "100vh",
      display: "flex",
      flexDirection: "column",
      background: "#f5f7f7",
      boxSizing: "border-box"
    }}>
      {/* HEADER */}
      <header className="main-header" style={{
        background: "#04926f", 
        color: "#fff",
        padding: "15px 40px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}>
        <div className="logo">
          <a href="/" style={{ fontSize: "1.8rem", fontWeight: "bold", textDecoration: "none", color: "#fff" }}>Herz</a>
        </div>
        <h1 style={{ margin: 0, fontSize: "1.5rem" }}>Alquiler de vehículos</h1>
        <nav style={{ display: "flex", gap: "20px" }}>
          <a href="/login" style={{ color: "#fff", textDecoration: "none", fontWeight: "bold" }}>Ingresar</a>
          <a href="/register" style={{ color: "#fff", textDecoration: "none", fontWeight: "bold" }}>Registrarse</a>
        </nav>
      </header>

      {/* CONTENIDO */}
      <section className="hero" style={{
        flex: 1,
        padding: "40px 2.5vw",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        boxSizing: "border-box"
      }}>
        <div className="title-row" style={{ textAlign: "center", marginBottom: 20 }}>
          <h2 style={{ fontSize: "2.2rem", color: "#ffffffff" }}>Tu viaje comienza aquí</h2>
        </div>
        <p className="descripcion-tipo" style={{ textAlign: "center", maxWidth: 600, marginBottom: 40 }}>
          Elegí el tipo de vehículo que se adapta a tus necesidades y reservá en segundos.
        </p>

        {/* GRID de categorías */}
        <div className="grid-categorias" style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
          gap: 30,
          width: "100%",
          maxWidth: "1200px"
        }}>
          {categorias.map((cat) => (
            <div key={cat.id} className="categoria-card" style={{
              background: "#fff",
              padding: 20,
              borderRadius: 12,
              boxShadow: "0 6px 15px rgba(0,0,0,0.08)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center"
            }}>
              <img
                src={cat.imagen}
                alt={cat.nombre}
                style={{
                  width: "100%",
                  height: 180,
                  objectFit: "cover",
                  borderRadius: 8,
                  cursor: "pointer"
                }}
                onClick={() => navigate("/login")}
              />
              <h3 style={{ textAlign: "center", marginTop: 15 }}>{cat.nombre}</h3>
              <button onClick={() => navigate("/login")} className="action-btn" style={{
                width: "100%",
                padding: "12px",
                marginTop: 10,
                background: "#04926f",
                color: "#fff",
                border: "none",
                borderRadius: 6,
                cursor: "pointer",
                fontWeight: "bold"
              }}>
                Ver {cat.nombre}
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;