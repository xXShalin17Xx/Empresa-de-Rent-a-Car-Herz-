import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getVehiculo, crearReserva } from "../../services/api";
import "../../styles/principal.css";

const ReservaForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vehiculo, setVehiculo] = useState(null);
  const [form, setForm] = useState({ fechaInicio: "", fechaFin: "" });
  const [mensaje, setMensaje] = useState("");

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const v = await getVehiculo(id);
        if (mounted) setVehiculo(v);
      } catch (e) {
        if (mounted) setMensaje("No se encontró el vehículo");
      }
    })();
    return () => { mounted = false; };
  }, [id]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMensaje("");
    try {
      const dto = {
        idCliente: Number(localStorage.getItem("id")),
        idVehiculo: Number(id),
        fechaInicio: form.fechaInicio,
        fechaFin: form.fechaFin
      };
      await crearReserva(dto);
      navigate("/cliente/reservas");
    } catch (err) {
      const mensajeApi = err?.userMessage ||
        (err?.response?.data && (err.response.data.message || err.response.data.error || JSON.stringify(err.response.data))) ||
        err.message || "Error al crear reserva";
      setMensaje(mensajeApi);
    }
  };

  if (!vehiculo) return <div style={{ padding: 40, textAlign: "center" }}>Cargando vehículo...</div>;

  return (
    // Wrapper para fondo completo y centrado vertical
    <div style={{ width: "100%", minHeight: "100vh", background: "#f5f7f7", padding: "40px 20px", display: "flex", justifyContent: "center", alignItems: "flex-start" }}>
      
      {/* Container del formulario */}
      <div className="reservas-container" style={{ width: "95%", maxWidth: "1200px", margin: "0", background: "white", padding: "40px", borderRadius: "12px", boxShadow: "0 10px 30px rgba(0,0,0,0.1)" }}>
        
        <h2 style={{ textAlign: "center", marginBottom: 30, color: "#04926f" }}>Reservar: {vehiculo.modelo}</h2>

        {mensaje && (
          <div className="alert" role="alert" style={{ background: "#ffecec", color: "#a94442", padding: 15, borderRadius: 6, marginBottom: 20 }}>
            {typeof mensaje === "string" ? mensaje : JSON.stringify(mensaje)}
          </div>
        )}

        <form className="reservas-form" onSubmit={handleSubmit} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 30 }}>
          
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label style={{ fontWeight: 700, marginBottom: 8 }}>Fecha inicio</label>
            <input type="date" name="fechaInicio" value={form.fechaInicio} onChange={handleChange} required style={{ padding: 12, borderRadius: 8, border: "1px solid #ccc" }} />
          </div>

          <div style={{ display: "flex", flexDirection: "column" }}>
            <label style={{ fontWeight: 700, marginBottom: 8 }}>Fecha fin</label>
            <input type="date" name="fechaFin" value={form.fechaFin} onChange={handleChange} required style={{ padding: 12, borderRadius: 8, border: "1px solid #ccc" }} />
          </div>

          <div style={{ gridColumn: "1 / -1", display: "flex", gap: 15, justifyContent: "center", marginTop: 20 }}>
            <button type="submit" className="action-btn" style={{ padding: "12px 30px", fontSize: "1rem", minWidth: "150px" }}>Confirmar reserva</button>
            <button type="button" onClick={() => navigate(-1)} style={{ padding: "12px 30px", fontSize: "1rem", background: "#6c757d", color: "white", border: "none", borderRadius: "5px", cursor: "pointer" }}>Cancelar</button>
          </div>

        </form>
      </div>
    </div>
  );
};

export default ReservaForm;