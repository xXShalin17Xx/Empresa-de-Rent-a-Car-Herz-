import "../../styles/principal.css";
import { useEffect, useState } from "react";
import { getAlquileresCliente } from "../../services/api";

const HistorialAlquileres = () => {
  const [historial, setHistorial] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargar = async () => {
      try {
        const data = await getAlquileresCliente();
        setHistorial(data);
      } catch (error) {
        console.error("Error cargando historial:", error);
      } finally {
        setLoading(false);
      }
    };
    cargar();
  }, []);

  return (
    // Contenedor principal para el fondo
    <div style={{ width: "100%", minHeight: "100vh", background: "#f5f7f7", padding: "40px 0" }}>
        
        {/* Botón de volver y centrado */}
        <div style={{ 
            marginBottom: 20, 
            width: "95vw",
            margin: "0 auto 20px auto" // Centra
        }}>
            <button onClick={() => window.history.back()} style={{ background: "transparent", color: "#04926f", border: "none", cursor: "pointer", fontSize: "1.2rem", display: "flex", alignItems: "center", gap: 5 }}>
            ← Volver
            </button>
        </div>

        {/* CONTENEDOR DE HISTORIAL */}
        <div className="reservas-container" style={{ 
            width: "95vw", 
            maxWidth: "100%", 
            margin: "0 auto", // Centra el contenedor
            background: "white", 
            padding: "40px", 
            borderRadius: "15px", 
            boxShadow: "0 4px 20px rgba(0,0,0,0.05)" 
        }}>
            
            <h2 style={{ fontSize: "2.2rem", marginBottom: "30px", borderBottom: "2px solid #04926f", paddingBottom: "10px", display: "inline-block" }}>
                Historial de alquileres
            </h2>

            {loading ? (
                <p>Cargando historial...</p>
            ) : historial.length === 0 ? (
                <p style={{ fontSize: "1.2rem" }}>No hay historial disponible.</p>
            ) : (
                <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 20 }}>
                        <thead>
                            <tr style={{ background: "#04926f", color: "white", textAlign: "left" }}>
                                <th style={{ padding: "18px 25px", borderTopLeftRadius: 10 }}>Vehículo</th>
                                <th style={{ padding: "18px 25px" }}>Inicio</th>
                                <th style={{ padding: "18px 25px" }}>Fin</th>
                                <th style={{ padding: "18px 25px" }}>Sucursal</th>
                                <th style={{ padding: "18px 25px", borderTopRightRadius: 10 }}>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            {historial.map((h, index) => (
                                <tr key={h.id} style={{ borderBottom: "1px solid #eee", background: index % 2 === 0 ? "#fff" : "#f9fcfb" }}>
                                    <td style={{ padding: "18px 25px" }}>{h.vehiculo}</td>
                                    <td style={{ padding: "18px 25px" }}>{h.fechaInicio}</td>
                                    <td style={{ padding: "18px 25px" }}>{h.fechaFin}</td>
                                    <td style={{ padding: "18px 25px" }}>{h.sucursal}</td>
                                    <td style={{ padding: "18px 25px" }}>{h.estado}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    </div>
  );
};

export default HistorialAlquileres;