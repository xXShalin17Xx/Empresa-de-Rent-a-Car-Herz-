import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { getVehiculos } from "../../services/api";
import Carousel from "../../components/Carousel";
import "../../styles/principal.css";

const getVehicleImage = (imagen) => {
  if (!imagen) {
    try { return require("../../assets/img/placeholder-auto.jpg"); }
    catch { return ""; }
  }
  if (imagen.startsWith("http://") || imagen.startsWith("https://")) return imagen;
  const nombre = imagen.split("/").pop();
  try { return require(`../../assets/img/${nombre}`); }
  catch { try { return require("../../assets/img/placeholder-auto.jpg"); } catch { return ""; } }
};

const ClienteHome = () => {
  const navigate = useNavigate();
  const [vehiculos, setVehiculos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState("economico");
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await getVehiculos();
        const normalizados = (Array.isArray(data) ? data : []).map((v) => ({
          id: v.id,
          modelo: v.modelo,
          tipo: v.tipo,
          categoria: v.tipo || "economico",
          estado: v.estado ? v.estado.toString() : "disponible",
          imagen: v.imagen || null,
          descripcion: v.descripcion || "Vehículo cómodo y eficiente.",
          sucursalId: v.sucursal?.id || v.sucursalId,
        }));
        if (!mounted) return;
        const disponibles = normalizados.filter((v) => v.estado.toLowerCase() === "disponible");
        setVehiculos(disponibles);
        if (disponibles.length > 0 && !disponibles.some(x => x.categoria === categoriaSeleccionada)) {
          setCategoriaSeleccionada(disponibles[0].categoria);
        }
      } catch (e) {
        if (!mounted) return;
        setError("No pudimos cargar los vehículos.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []); [categoriaSeleccionada];

  const listaFiltrada = useMemo(() => {
    if (!categoriaSeleccionada) return vehiculos;
    return vehiculos.filter((v) => v.categoria === categoriaSeleccionada);
  }, [vehiculos, categoriaSeleccionada]);

  const irAReserva = (idVehiculo) => navigate(`/reserva/${idVehiculo}`);

  return (
    <div style={{ 
      width: "100%", 
      minHeight: "100vh", 
      background: "#f5f7f7",
      // Aseguramos que el contenido pueda desbordar verticalmente (scroll)
      overflowY: "auto", 
      boxSizing: "border-box" // Importante para que el padding/border no sume al width
    }}>
      
      {/* HEADER */}
      <header className="main-header" style={{ position: "sticky", top: 0, zIndex: 1000, padding: "15px 40px" }}>
        <div className="logo">
          <span style={{ fontSize: "1.8rem", fontWeight: "bold" }}>HERZ</span>
        </div>
        
        <div className="perfil-dropdown" style={{ position: "relative" }}>
            <div 
              onClick={() => setShowMenu(!showMenu)}
              style={{ width: 45, height: 45, borderRadius: "50%", background: "#ccc", border: "2px solid #fff", cursor: "pointer", overflow:"hidden", display: "flex", alignItems:"center", justifyContent:"center" }}
            >
               <img 
                 src={require("../../assets/img/placeholder-perfil.jpg")} 
                 onError={(e) => e.target.style.display='none'} 
                 style={{width: "100%", height: "100%", objectFit: "cover"}} 
                 alt="P" 
               />
               {/* Fallback visual si no hay imagen */}
               <span style={{position:"absolute", color: "#333", fontWeight:"bold"}}>P</span> 
            </div>
            
            {showMenu && (
              <div className="menu-dropdown show" style={{ position: "absolute", right: 0, top: "55px", background: "white", boxShadow: "0 4px 12px rgba(0,0,0,0.15)", borderRadius: 8, overflow: "hidden", minWidth: 160 }}>
                <Link to="/cliente/reservas" style={{ display: "block", padding: "12px 16px", color: "#333", textDecoration: "none", borderBottom: "1px solid #eee" }}>Mis Reservas</Link>
                <Link to="/cliente/historial" style={{ display: "block", padding: "12px 16px", color: "#333", textDecoration: "none", borderBottom: "1px solid #eee" }}>Historial</Link>
                <Link to="/cliente/perfil" style={{ display: "block", padding: "12px 16px", color: "#333", textDecoration: "none" }}>Perfil</Link>
              </div>
            )}
        </div>
      </header>

      
      <section className="pagina-principal" style={{ 
          padding: "30px 2.5vw", 
          width: "95vw", 
          margin: "0 auto", 
          maxWidth: "100%", 
          boxSizing: "border-box"
      }}>
        
        <div className="banner-info" style={{ textAlign: "center", marginBottom: 30 }}>
          <h2 style={{ fontSize: "2.5rem", color: "#04926f" }}>¡Bienvenido a Herz!</h2>
        </div>

        <div style={{ width: "100%", marginBottom: 40 }}>
             <div className="carousel-wrapper" style={{ width: "100%", maxWidth: "100%" }}>
                <Carousel onSelectCategoria={(cat) => setCategoriaSeleccionada(cat)} />
             </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 20, marginBottom: 30 }}>
           <h3 style={{ fontSize: "2rem", color: "#365a59", textTransform: "capitalize", borderBottom: "2px solid #04926f", display: "inline-block", paddingBottom: 5 }}>
            {categoriaSeleccionada}
          </h3>
        </div>

        {loading && <p>Cargando autos...</p>}
        {error && !loading && <p>{error}</p>}

        {!loading && !error && listaFiltrada.length > 0 && (
          <div className="grid-vehiculos" style={{ 
              display: "grid", 
              gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", 
              gap: 30, 
              width: "100%", 
              maxWidth: "100%", 
              margin: "0" 
            }}>
            {listaFiltrada.map((v) => (
              <div key={v.id} className="vehiculo-card" style={{ background: "#fff", padding: 20, borderRadius: 12, boxShadow: "0 6px 15px rgba(0,0,0,0.08)", display: "flex", flexDirection: "column" }}>
                  <img
                    src={getVehicleImage(v.imagen)}
                    alt={v.modelo}
                    style={{ width: "100%", height: 200, objectFit: "cover", borderRadius: 8, cursor: "pointer" }}
                    onClick={() => irAReserva(v.id)}
                  />
                  <div style={{ marginTop: 15, flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <h4 style={{ fontSize: "1.4rem", margin: 0 }}>{v.modelo}</h4>
                        <span style={{ background: "#e6f7f0", color: "#04926f", padding: "5px 10px", borderRadius: 15, fontWeight: "bold", fontSize: "0.85rem" }}>
                            {v.categoria}
                        </span>
                    </div>
                    <p style={{ color: "#666", margin: "10px 0" }}>{v.descripcion}</p>
                  </div>
                  <button onClick={() => irAReserva(v.id)} className="action-btn" style={{ width: "100%", padding: "12px", fontSize: "1.1rem", marginTop: 15 }}>
                      Reservar Ahora
                  </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default ClienteHome;