import "../../styles/principal.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getClienteInfo, actualizarPerfil } from "../../services/api";
import { useAuth } from "../../context/AuthContext";

const Perfil = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const [perfil, setPerfil] = useState({
    nombre: '',
    email: '',
    telefono: '',
    direccion: ''
  });
  const [perfilOriginal, setPerfilOriginal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [mensaje, setMensaje] = useState('');

  useEffect(() => {
    const idCliente = localStorage.getItem("id");
    if (!idCliente) {
      setError("No se pudo obtener el ID del cliente. Debes iniciar sesión.");
      setLoading(false);
      return;
    }

    const cargarPerfil = async () => {
      try {
        const data = await getClienteInfo(idCliente);
        const datosPerfil = {
          nombre: data.nombre || '',
          email: data.email || '',
          telefono: data.telefono || '',
          direccion: data.direccion || ''
        };
        setPerfil(datosPerfil);
        setPerfilOriginal(datosPerfil);
        setLoading(false);
        setError('');
      } catch (err) {
        const msg = err.userMessage || "Error desconocido al cargar el perfil.";
        setError(`Error al cargar el perfil: ${msg}`);
        setLoading(false);
      }
    };
    cargarPerfil();
  }, []);

  const handleChange = (e) => setPerfil({ ...perfil, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMensaje('');
    setError('');

    const idCliente = localStorage.getItem("id");
    if (!idCliente) {
      setError("ID de cliente no disponible.");
      return;
    }

    try {
      await actualizarPerfil(idCliente, perfil);
      setMensaje("Perfil actualizado con éxito.");
      setPerfilOriginal(perfil);
      setIsEditing(false);
    } catch (err) {
      const msg = err.userMessage || "Error desconocido al actualizar.";
      setError(`Error al actualizar el perfil: ${msg}`);
    }
  };

  const handleCancel = () => {
    if (perfilOriginal) {
      setPerfil(perfilOriginal);
    }
    setIsEditing(false);
    setError('');
    setMensaje('');
  };

  const handleLogout = () => {
    logout();          // limpia localStorage y usuario desde AuthContext
    navigate("/login"); // redirige al login
  };

  if (loading) return <div className="perfil-container">Cargando perfil...</div>;

  return (
    <div className="perfil-container" style={{ maxWidth: 700, margin: "0 auto", padding: 20 }}>
      <h2>Mi Perfil</h2>

      {mensaje && <div className="alert success">{mensaje}</div>}
      {error && <div className="alert error">{error}</div>}

      <div style={{ background: "white", padding: 30, borderRadius: 10, boxShadow: "0 4px 12px rgba(0,0,0,0.08)" }}>
        <div style={{ borderBottom: "1px solid #eee", paddingBottom: 20, marginBottom: 25 }}>
          <h3 style={{ margin: 0 }}>{perfil.nombre || 'Nombre no disponible'}</h3>
          <p style={{ margin: 0, color: '#666' }}>{perfil.email}</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 15 }}>
            <div style={{ marginBottom: 15 }}>
              <label htmlFor="nombre" style={{ fontWeight: "bold", display: "block", marginBottom: 5 }}>Nombre</label>
              <input
                type="text"
                id="nombre"
                name="nombre"
                value={perfil.nombre}
                onChange={handleChange}
                disabled={!isEditing}
                required
                style={{ width: "100%", padding: 10, border: "1px solid #ccc", borderRadius: 6, background: isEditing ? "white" : "#f5f5f5" }}
              />
            </div>

            <div style={{ marginBottom: 15 }}>
              <label htmlFor="email" style={{ fontWeight: "bold", display: "block", marginBottom: 5 }}>Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={perfil.email}
                onChange={handleChange}
                disabled={!isEditing}
                required
                style={{ width: "100%", padding: 10, border: "1px solid #ccc", borderRadius: 6, background: isEditing ? "white" : "#f5f5f5" }}
              />
            </div>

            <div style={{ marginBottom: 15 }}>
              <label htmlFor="telefono" style={{ fontWeight: "bold", display: "block", marginBottom: 5 }}>Teléfono</label>
              <input
                type="text"
                id="telefono"
                name="telefono"
                value={perfil.telefono}
                onChange={handleChange}
                disabled={!isEditing}
                style={{ width: "100%", padding: 10, border: "1px solid #ccc", borderRadius: 6, background: isEditing ? "white" : "#f5f5f5" }}
              />
            </div>

            <div style={{ marginBottom: 15 }}>
              <label htmlFor="direccion" style={{ fontWeight: "bold", display: "block", marginBottom: 5 }}>Dirección</label>
              <input
                type="text"
                id="direccion"
                name="direccion"
                value={perfil.direccion}
                onChange={handleChange}
                disabled={!isEditing}
                style={{ width: "100%", padding: 10, border: "1px solid #ccc", borderRadius: 6, background: isEditing ? "white" : "#f5f5f5" }}
              />
            </div>
          </div>

          <div style={{ marginTop: "20px", display: "flex", gap: 10, justifyContent: "flex-end" }}>
            {isEditing ? (
              <>
                <button type="submit" className="action-btn">Guardar Cambios</button>
                <button
                  type="button"
                  onClick={handleCancel}
                  style={{ padding: "10px 20px", background: "#ccc", border: "none", color: "#333", borderRadius: 8, cursor: "pointer" }}
                >
                  Cancelar
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => setIsEditing(true)}
                className="action-btn"
                style={{ padding: "10px 20px" }}
              >
                Editar Perfil
              </button>
            )}
            {/* Botón de cerrar sesión */}
            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 20 }}>
              <button
                type="button"
                onClick={handleLogout}
                style={{
                  padding: "10px 20px",
                  background: "#d9534f",
                  border: "none",
                  color: "#fff",
                  borderRadius: 8,
                  cursor: "pointer",
                  fontWeight: "bold"
                }}
              >
                Cerrar Sesión
              </button>
            </div>
                </div>
          
        </form>
      </div>
    </div>
  );
};

export default Perfil;