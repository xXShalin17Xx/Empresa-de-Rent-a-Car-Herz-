import "../styles/login.css";
import { useState } from "react";
import { register } from "../services/api";
import { useNavigate } from "react-router-dom";

const Registro = () => {
  const [form, setForm] = useState({
    nombre: "",
    dni: "",
    licencia: "",
    email: "",
    telefono: "",
    password: "", 
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(form);
      alert("Registro exitoso. Ahora puedes iniciar sesión.");
      navigate("/login");
    } catch (err) {
      console.error('Register error:', err);
      if (err?.response) {
        alert('Error: ' + (err.response.data?.message || err.response.data?.detail || "Error en el servidor"));
      } else {
        alert('Error: ' + err.message);
      }
    }
  };

  return (
    <div className="container register-mode">
      <div className="box">
        <div className="switch">
          <h2>¿Ya tenés cuenta?</h2>
          <p>Iniciá sesión para continuar</p>
          <button onClick={() => navigate("/login")}>Volver al login</button>
        </div>
        <div className="form-container register">
          <h2>Registro</h2>
          <form onSubmit={handleSubmit}>
            <input name="nombre" placeholder="Nombre" onChange={handleChange} required />
            <input name="dni" placeholder="DNI" onChange={handleChange} required />
            <input name="licencia" placeholder="Licencia" onChange={handleChange} required />
            <input name="email" type="email" placeholder="Correo" onChange={handleChange} required />
            <input name="telefono" placeholder="Teléfono" onChange={handleChange} required />
            <input name="password" type="password" placeholder="Contraseña" onChange={handleChange} required />
            <button type="submit">Crear cuenta</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Registro;