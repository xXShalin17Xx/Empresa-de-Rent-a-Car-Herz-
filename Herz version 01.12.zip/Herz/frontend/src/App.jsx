// src/App.jsx
import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Registro from "./pages/Register";

// Cliente
import ClienteHome from "./pages/Cliente/Home";
import Reservar from "./pages/Cliente/Reservar";
import ReservaForm from "./pages/Cliente/ReservaForm";
import MisReservas from "./pages/Cliente/MisReservas";
import HistorialAlquileres from "./pages/Cliente/HistorialAlquileres";
import Perfil from "./pages/Cliente/Perfil";

// Empleado / Mantenimiento / Coordinador / Admin
import EmpleadoHome from "./pages/Empleado/Panel";
import MantenimientoHome from "./pages/Mantenimiento/Panel";
import CoordinadorHome from "./pages/Coordinador/Flota";
import AdminHome from "./pages/Admin/Dashboard";

import RutaProtegida from "./components/RutaProtegida";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Rutas públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registro />} />

        {/* Página de reserva genérica (puede requerir login según tu flujo) */}
        <Route path="/reservar" element={<Reservar />} />

        {/* Reserva por vehículo (recibe idVehiculo en params) */}
        <Route path="/reserva/:id" element={<ReservaForm />} />

        {/* Rutas protegidas por rol */}
        <Route
          path="/cliente"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <ClienteHome />
            </RutaProtegida>
          }
        />
        <Route
          path="/cliente/reservas"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <MisReservas />
            </RutaProtegida>
          }
        />
        <Route
          path="/cliente/historial"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <HistorialAlquileres />
            </RutaProtegida>
          }
        />
        <Route
          path="/cliente/perfil"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <Perfil />
            </RutaProtegida>
          }
        />

        <Route
          path="/empleado"
          element={
            <RutaProtegida rolesPermitidos={["empleado_sucursal"]}>
              <EmpleadoHome />
            </RutaProtegida>
          }
        />

        <Route
          path="/mantenimiento"
          element={
            <RutaProtegida rolesPermitidos={["personal_mantenimiento"]}>
              <MantenimientoHome />
            </RutaProtegida>
          }
        />

        <Route
          path="/coordinador"
          element={
            <RutaProtegida rolesPermitidos={["coordinador_flotas"]}>
              <CoordinadorHome />
            </RutaProtegida>
          }
        />

        <Route
          path="/admin"
          element={
            <RutaProtegida rolesPermitidos={["admin"]}>
              <AdminHome />
            </RutaProtegida>
          }
        />

        {/* Fallback: si la ruta no existe, redirigir al home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;