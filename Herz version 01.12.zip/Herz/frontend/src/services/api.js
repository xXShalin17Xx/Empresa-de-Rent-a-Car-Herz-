import axios from 'axios';

const API = axios.create({
  baseURL: "http://localhost:8080/api",
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor: agrega token salvo en auth endpoints
API.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token && !config.url.includes('/auth/login') && !config.url.includes('/auth/register')) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: retorna data y normaliza errores para la UI
API.interceptors.response.use(
  (response) => response.data,
  (error) => {
    // Normalizar mensaje legible para componentes
    const apiData = error?.response?.data;
    const mensaje =
      (apiData && (apiData.message || apiData.error || apiData.msg)) ||
      (typeof apiData === 'string' ? apiData : null) ||
      error.message ||
      'Error de red';
    // adjuntar campo userMessage para uso directo en componentes
    error.userMessage = mensaje;
    return Promise.reject(error);
  }
);

// ------------------ AUTENTICACIÓN ------------------
export const login = (email, password) =>
  API.post('/auth/login', { email, password });

export const register = (data) =>
  API.post('/auth/register', data);


// ------------------ CLIENTE ------------------
export const crearReserva = (data) =>
  API.post('/reservas', data);

export const getReservas = () =>
  API.get('/reservas', { params: { clienteId: localStorage.getItem('id') } });

export const getAlquileresCliente = () =>
  API.get('/alquileres/cliente', { params: { clienteId: localStorage.getItem('id') } });

// Funciones para Perfil del Cliente
export const getClienteInfo = (id) =>
  API.get(`/usuarios/${id}`);

export const actualizarPerfil = (id, data) =>
  API.put(`/usuarios/${id}`, data);


// ------------------ VEHÍCULOS (Coordinador y Cliente) ------------------
export const getVehiculos = () =>
  API.get('/vehiculos');

export const getVehiculo = (id) =>
  API.get(`/vehiculos/${id}`);


// ------------------ EMPLEADO ------------------
export const getReservasActivas = () =>
  API.get('/reservas/activas');

export const confirmarRetiro = (idReserva, idVehiculo) =>
  API.post('/alquileres/confirmar', { idReserva, idVehiculo });

export const registrarDevolucion = (idAlquiler, kmFinal) =>
  API.post(`/alquileres/devolver/${idAlquiler}`, { kmFinal });


// ------------------ COORDINADOR ------------------
export const getVehiculosSucursal = (id) =>
  API.get(`/vehiculos/sucursal?id=${id}`);

export const getDisponibilidadVehiculos = () =>
  API.get('/vehiculos/disponibles');


// ------------------ MANTENIMIENTO ------------------
export const getMantenimientosPendientes = () =>
  API.get('/mantenimientos/pendientes');

export const crearMantenimiento = (data) =>
  API.post('/mantenimientos', data);

export const completarMantenimiento = (id) =>
  API.put(`/mantenimientos/${id}/completar`);


// ------------------ ADMIN ------------------
export const getUsuarios = () =>
  API.get('/usuarios');

export const cambiarRolUsuario = (id, rol) =>
  API.put(`/usuarios/${id}/rol`, { rol });

export const getReportesIngresos = () =>
  API.get('/reportes/ingresos');

export const getDashboardAdmin = () =>
  API.get('/admin/dashboard');

// Exportar API (aunque no se usa en este caso, se mantiene la convención)
export default API;