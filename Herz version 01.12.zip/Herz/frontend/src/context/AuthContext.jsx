import { createContext, useContext, useState, useEffect } from "react";
import { login } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [usuario, setUsuario] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const rol = localStorage.getItem("rol");
    const nombre = localStorage.getItem("nombre");
    const id = localStorage.getItem("id");
    if (token && rol) {
      setUsuario({ token, rol, nombre, id });
    }
  }, []);

  const iniciarSesion = async (email, contrasena) => {
    try {
      const res = await login(email, contrasena);
      if (res && res.token) {
        localStorage.setItem("token", res.token);
        localStorage.setItem("rol", res.rol);
        localStorage.setItem("nombre", res.nombre || res.email);
        localStorage.setItem("id", res.id);
        setUsuario({ token: res.token, rol: res.rol, nombre: res.nombre, id: res.id });
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error en iniciarSesion:", error);
      throw error;
    }
  };

  const logout = () => {
    localStorage.clear();
    setUsuario(null);
  };

  return (
    <AuthContext.Provider value={{ usuario, iniciarSesion, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);