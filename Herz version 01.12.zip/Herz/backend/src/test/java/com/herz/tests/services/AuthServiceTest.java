package com.herz.tests.services;

import com.herz.dtos.AuthRequest;
import com.herz.dtos.AuthResponse;
import com.herz.models.Cliente;
import com.herz.models.Rol;
import com.herz.repositories.ClienteRepository;
import com.herz.security.JwtUtil;
import com.herz.services.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @InjectMocks
    private AuthService authService;

    @Mock
    private ClienteRepository clienteRepository;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private PasswordEncoder passwordEncoder;

    private Cliente cliente;
    private Rol rol;

    @BeforeEach
    void setUp() {
        rol = new Rol();
        rol.setId(1L);
        rol.setNombre("cliente");

        cliente = new Cliente();
        cliente.setId(1L);
        cliente.setEmail("usuario@herz.com");
        cliente.setPassword("hashedPassword");
        cliente.setRol(rol);
    }

    @Test
    void login_credencialesValidas_retornaAuthResponse() {
        // 🔹 Arrange
        AuthRequest request = new AuthRequest();
        request.email = "usuario@herz.com";
        request.password = "123456";

        when(clienteRepository.findByEmail("usuario@herz.com")).thenReturn(Optional.of(cliente));
        when(passwordEncoder.matches("123456", "hashedPassword")).thenReturn(true);
        when(jwtUtil.generateToken(1L, "usuario@herz.com", "cliente")).thenReturn("mocked.jwt.token");

        // 🔹 Act
        AuthResponse response = authService.login(request);

        // 🔹 Assert
        assertNotNull(response);
        assertEquals("mocked.jwt.token", response.token);
        assertEquals(1L, response.id);
        assertEquals("usuario@herz.com", response.email);
        assertEquals("cliente", response.rol);

        verify(clienteRepository).findByEmail("usuario@herz.com");
        verify(passwordEncoder).matches("123456", "hashedPassword");
        verify(jwtUtil).generateToken(1L, "usuario@herz.com", "cliente");
    }

    @Test
    void login_usuarioNoExiste_lanzaExcepcion() {
        // 🔹 Arrange
        AuthRequest request = new AuthRequest();
        request.email = "noexiste@herz.com";
        request.password = "123456";

        when(clienteRepository.findByEmail("noexiste@herz.com")).thenReturn(Optional.empty());

        // 🔹 Act & Assert
        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                authService.login(request)
        );
        assertEquals("Usuario no encontrado", ex.getMessage());
    }

    @Test
    void login_contrasenaIncorrecta_lanzaExcepcion() {
        // 🔹 Arrange
        AuthRequest request = new AuthRequest();
        request.email = "usuario@herz.com";
        request.password = "wrongpass";

        when(clienteRepository.findByEmail("usuario@herz.com")).thenReturn(Optional.of(cliente));
        when(passwordEncoder.matches("wrongpass", "hashedPassword")).thenReturn(false);

        // 🔹 Act & Assert
        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                authService.login(request)
        );
        assertEquals("Contraseña incorrecta", ex.getMessage());
    }
}