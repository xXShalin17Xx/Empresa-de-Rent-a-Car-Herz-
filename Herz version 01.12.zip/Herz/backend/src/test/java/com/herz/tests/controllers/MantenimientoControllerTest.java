package com.herz.tests.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herz.controllers.MantenimientoController;
import com.herz.dtos.MantenimientoDTO;
import com.herz.models.Mantenimiento;
import com.herz.models.Vehiculo;
import com.herz.security.JwtUtil;
import com.herz.models.Mantenimiento.Estado;
import com.herz.services.MantenimientoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(MantenimientoController.class)
class MantenimientoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MantenimientoService mantenimientoService;

    @MockBean
    private JwtUtil jwtUtil;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void crearOrden_datosValidos_retornaMantenimiento() throws Exception {
        // 🔹 Arrange
        MantenimientoDTO dto = new MantenimientoDTO();
        dto.idVehiculo = 1L;
        dto.tipo = "aceite";
        dto.costo = 500.0;

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(1L);

        Mantenimiento mantenimiento = new Mantenimiento();
        mantenimiento.setId(10L);
        mantenimiento.setTipo("aceite");
        mantenimiento.setCosto(500.0);
        mantenimiento.setEstado(Estado.pendiente);
        mantenimiento.setVehiculo(vehiculo);

        Mockito.when(mantenimientoService.crearOrden(any())).thenReturn(mantenimiento);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/mantenimientos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.tipo").value("aceite"))
                .andExpect(jsonPath("$.costo").value(500.0))
                .andExpect(jsonPath("$.estado").value("pendiente"));
    }

    @Test
    void listarPendientes_devuelveListaDeMantenimientos() throws Exception {
        // 🔹 Arrange
        Mantenimiento m1 = new Mantenimiento();
        m1.setId(1L);
        m1.setEstado(Estado.pendiente);

        Mantenimiento m2 = new Mantenimiento();
        m2.setId(2L);
        m2.setEstado(Estado.pendiente);

        Mockito.when(mantenimientoService.listarPendientes()).thenReturn(List.of(m1, m2));

        // 🔹 Act & Assert
        mockMvc.perform(get("/api/mantenimientos/pendientes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));
    }

    @Test
    void marcarCompletado_idValido_retornaMantenimientoActualizado() throws Exception {
        // 🔹 Arrange
        Mantenimiento mantenimiento = new Mantenimiento();
        mantenimiento.setId(3L);
        mantenimiento.setEstado(Estado.completado);

        Mockito.when(mantenimientoService.marcarCompletado(3L)).thenReturn(mantenimiento);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/mantenimientos/marcar-completado")
                        .param("idMantenimiento", "3"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.estado").value("completado"));
    }
}   