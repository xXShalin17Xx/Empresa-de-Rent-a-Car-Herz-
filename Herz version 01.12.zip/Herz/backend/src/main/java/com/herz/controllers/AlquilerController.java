package com.herz.controllers;

import com.herz.dtos.AlquilerDTO;
import com.herz.models.Alquiler;
import com.herz.services.AlquilerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/alquileres")
public class AlquilerController {

    @Autowired
    private AlquilerService alquilerService;

    @PostMapping("/confirmar")
    public Alquiler confirmarRetiro(@RequestBody AlquilerDTO dto) {
        return alquilerService.confirmarRetiro(dto);
    }

    @PostMapping("/devolver/{id}")
    public Alquiler registrarDevolucion(@PathVariable Long id, @RequestBody AlquilerDTO dto) {
        return alquilerService.registrarDevolucion(id, dto.getKmFinal());
    }
}