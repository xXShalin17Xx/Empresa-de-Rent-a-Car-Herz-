package com.herz.controllers;

import com.herz.dtos.ErrorResponse;
import com.herz.dtos.ReservaDTO;
import com.herz.models.Reserva;
import com.herz.services.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservas")
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    @PostMapping
    public ResponseEntity<?> crearReserva(@RequestBody ReservaDTO dto) {
        try {
            Reserva creada = reservaService.crearReserva(dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(creada);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
                    new ErrorResponse("No se pudo crear la reserva", ex.getMessage())
            );
        }
    }

    @GetMapping
    public ResponseEntity<?> listarReservas(@RequestParam(value = "clienteId", required = false) Long clienteId) {
        try {
            if (clienteId != null) {
                List<Reserva> porCliente = reservaService.listarPorCliente(clienteId);
                return ResponseEntity.ok(porCliente);
            } else {
                List<Reserva> todas = reservaService.listarTodas();
                return ResponseEntity.ok(todas);
            }
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new ErrorResponse("Error al listar reservas", ex.getMessage())
            );
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        try {
            Reserva r = reservaService.obtenerPorId(id);
            return ResponseEntity.ok(r);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ErrorResponse("Reserva no encontrada", ex.getMessage())
            );
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancelarReserva(
            @PathVariable("id") Long idReserva,
            @RequestParam(value = "clienteId", required = false) Long idCliente
    ) {
        try {
            reservaService.cancelarReserva(idReserva, idCliente);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException iae) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse("Solicitud inválida", iae.getMessage()));
        } catch (SecurityException se) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorResponse("Acceso denegado", se.getMessage()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ErrorResponse("No se pudo cancelar la reserva", ex.getMessage()));
        }
    }
}