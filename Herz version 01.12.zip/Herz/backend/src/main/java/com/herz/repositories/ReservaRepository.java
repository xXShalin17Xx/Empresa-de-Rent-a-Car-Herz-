package com.herz.repositories;

import com.herz.models.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    List<Reserva> findByCliente_Id(Long clienteId);
    List<Reserva> findByEstado(String estado);
}
