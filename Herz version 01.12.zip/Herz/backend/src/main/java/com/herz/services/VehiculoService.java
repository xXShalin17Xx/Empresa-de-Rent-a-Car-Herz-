package com.herz.services;

import com.herz.models.Vehiculo;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.repositories.VehiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class VehiculoService {

    @Autowired
    private VehiculoRepository vehiculoRepository;

    public List<Vehiculo> listarDisponibles() {
        return vehiculoRepository.findByEstado(EstadoVehiculo.disponible);
    }

    public Vehiculo obtenerPorId(Long id) {
        return vehiculoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehículo no encontrado"));
    }

    public List<Vehiculo> listarPorSucursal(Long idSucursal) {
        return vehiculoRepository.findBySucursal_IdAndEstado(idSucursal, EstadoVehiculo.disponible);
    }

    public Vehiculo crearVehiculo(com.herz.dtos.VehiculoDTO dto) {
        Vehiculo v = new Vehiculo();
        v.setPatente(dto.getPatente());
        v.setModelo(dto.getModelo());
        v.setTipo(dto.getTipo());
        v.setKilometraje(dto.getKilometraje());
        
        try {
            if (dto.getEstado() != null) {
                v.setEstado(EstadoVehiculo.valueOf(dto.getEstado()));
            } else {
                v.setEstado(EstadoVehiculo.disponible);
            }
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Estado inválido: " + dto.getEstado());
        }

        return vehiculoRepository.save(v);
    }
}