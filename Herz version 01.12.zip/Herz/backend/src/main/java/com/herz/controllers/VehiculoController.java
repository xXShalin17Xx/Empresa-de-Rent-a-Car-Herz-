package com.herz.controllers;

import com.herz.models.Vehiculo;
import com.herz.services.VehiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehiculos")
public class VehiculoController {

    @Autowired
    private VehiculoService vehiculoService;

    // Catálogo público: solo disponibles
    @GetMapping
    public List<Vehiculo> listarVehiculos() {
        return vehiculoService.listarDisponibles();
    }

    @GetMapping("/{id}")
    public Vehiculo obtenerPorId(@PathVariable Long id) {
        return vehiculoService.obtenerPorId(id);
    }

    // Filtrado por sucursal (query param ?id=)
    @GetMapping("/sucursal")
    public List<Vehiculo> listarPorSucursal(@RequestParam Long id) {
        return vehiculoService.listarPorSucursal(id);
    }
}