package com.herz.controllers;

import com.herz.dtos.ErrorResponse;
import com.herz.models.Cliente;
import com.herz.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable Long id) {
        try {
            Cliente cliente = usuarioService.obtenerClientePorId(id);
            return ResponseEntity.ok(cliente);
        } catch (ResponseStatusException rse) {
            return ResponseEntity.status(rse.getStatusCode()).body(
                    new ErrorResponse("Error al buscar usuario", rse.getReason())
            );
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarPerfil(@PathVariable Long id, @RequestBody Cliente clienteUpdate) {
        try {
            Cliente clienteGuardado = usuarioService.actualizarPerfil(id, clienteUpdate);
            return ResponseEntity.ok(clienteGuardado);
        } catch (ResponseStatusException rse) {
            return ResponseEntity.status(rse.getStatusCode()).body(
                    new ErrorResponse("Error al actualizar", rse.getReason())
            );
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new ErrorResponse("Error interno del servidor", ex.getMessage())
            );
        }
    }
}