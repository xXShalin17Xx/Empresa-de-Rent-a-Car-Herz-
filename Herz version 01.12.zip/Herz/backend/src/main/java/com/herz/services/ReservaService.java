package com.herz.services;

import com.herz.dtos.ReservaDTO;
import com.herz.models.Cliente;
import com.herz.models.Reserva;
import com.herz.models.Vehiculo;
import com.herz.repositories.ClienteRepository;
import com.herz.repositories.ReservaRepository;
import com.herz.repositories.VehiculoRepository;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final ClienteRepository clienteRepository;
    private final VehiculoRepository vehiculoRepository;

    public ReservaService(ReservaRepository reservaRepository,
                          ClienteRepository clienteRepository,
                          VehiculoRepository vehiculoRepository) {
        this.reservaRepository = reservaRepository;
        this.clienteRepository = clienteRepository;
        this.vehiculoRepository = vehiculoRepository;
    }

    @Transactional
    public Reserva crearReserva(ReservaDTO dto) {
        if (dto == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Datos de reserva vacíos");
        }
        // CORRECCIÓN: Uso de getters
        if (dto.getIdCliente() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "idCliente es requerido");
        }
        if (dto.getFechaInicio() == null || dto.getFechaFin() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Fechas de inicio y fin son requeridas");
        }
        if (dto.getFechaFin().isBefore(dto.getFechaInicio()) || dto.getFechaFin().isEqual(dto.getFechaInicio())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Fecha fin debe ser posterior a fecha inicio");
        }

        Cliente cliente = clienteRepository.findById(dto.getIdCliente())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente no encontrado"));

        Reserva reserva = new Reserva();
        reserva.setCliente(cliente);
        reserva.setFechaInicio(dto.getFechaInicio());
        reserva.setFechaFin(dto.getFechaFin());
        reserva.setEstado("pendiente");

        if (dto.getIdVehiculo() != null) {
            Vehiculo vehiculo = vehiculoRepository.findById(dto.getIdVehiculo())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehículo no encontrado"));

            String estadoVehiculo = vehiculo.getEstado() != null ? vehiculo.getEstado().toString().toLowerCase() : "disponible";
            if (!"disponible".equalsIgnoreCase(estadoVehiculo)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Vehículo no disponible");
            }

            reserva.setIdVehiculo(vehiculo.getId());
            reserva.setTipoVehiculo(vehiculo.getTipo());
        } else if (dto.getTipoVehiculo() != null && !dto.getTipoVehiculo().trim().isEmpty()) {
            reserva.setTipoVehiculo(dto.getTipoVehiculo());
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Debe indicar idVehiculo o tipoVehiculo");
        }

        if (dto.getIdSucursal() != null) {
            reserva.setIdSucursal(dto.getIdSucursal());
        }

        return reservaRepository.save(reserva);
    }

    @Transactional(readOnly = true)
    public List<Reserva> listarTodas() {
        return reservaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Reserva> listarPorCliente(Long clienteId) {
        if (clienteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "clienteId es requerido");
        }
        return reservaRepository.findByCliente_Id(clienteId);
    }

    @Transactional(readOnly = true)
    public Reserva obtenerPorId(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Reserva no encontrada"));
    }

    @Transactional
    public void cancelarReserva(Long idReserva, Long idCliente) {
        if (idReserva == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "idReserva es requerido");
        }

        Reserva reserva = reservaRepository.findById(idReserva)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Reserva no encontrada"));

        if (idCliente != null) {
            Cliente cliente = reserva.getCliente();
            if (cliente == null || !idCliente.equals(cliente.getId())) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "La reserva no pertenece a ese cliente");
            }
        }

        reserva.setEstado("cancelada");
        reservaRepository.save(reserva);

        Long idVehiculo = reserva.getIdVehiculo();
        if (idVehiculo != null) {
            Optional<Vehiculo> optVeh = vehiculoRepository.findById(idVehiculo);
            if (optVeh.isPresent()) {
                Vehiculo vehiculo = optVeh.get();
                vehiculoRepository.save(vehiculo);
            }
        }
    }

    @Transactional
    public Reserva actualizarReserva(Long id, ReservaDTO dto) {
        if (id == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "id es requerido");
        }
        Reserva existente = reservaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Reserva no encontrada"));

        if (dto.getFechaInicio() != null && dto.getFechaFin() != null) {
            if (dto.getFechaFin().isBefore(dto.getFechaInicio()) || dto.getFechaFin().isEqual(dto.getFechaInicio())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Fecha fin debe ser posterior a fecha inicio");
            }
            existente.setFechaInicio(dto.getFechaInicio());
            existente.setFechaFin(dto.getFechaFin());
        }

        if (dto.getIdSucursal() != null) {
            existente.setIdSucursal(dto.getIdSucursal());
        }

        if (dto.getIdVehiculo() != null && !dto.getIdVehiculo().equals(existente.getIdVehiculo())) {
            Vehiculo nuevoVehiculo = vehiculoRepository.findById(dto.getIdVehiculo())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehículo nuevo no encontrado"));

            String estadoVehiculo = nuevoVehiculo.getEstado() != null ? nuevoVehiculo.getEstado().toString().toLowerCase() : "disponible";
            if (!"disponible".equalsIgnoreCase(estadoVehiculo)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Vehículo nuevo no disponible");
            }

            Long vehAnteriorId = existente.getIdVehiculo();
            if (vehAnteriorId != null) {
                vehiculoRepository.findById(vehAnteriorId).ifPresent(v -> {
                    vehiculoRepository.save(v);
                });
            }

            existente.setIdVehiculo(nuevoVehiculo.getId());
            existente.setTipoVehiculo(nuevoVehiculo.getTipo());
            vehiculoRepository.save(nuevoVehiculo);
        }

        return reservaRepository.save(existente);
    }
}