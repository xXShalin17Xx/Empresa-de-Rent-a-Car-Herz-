package com.herz.services;

import com.herz.dtos.AuthRequest;
import com.herz.dtos.AuthResponse;
import com.herz.models.Cliente;
import com.herz.repositories.ClienteRepository;
import com.herz.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException; // Importante

@Service
public class AuthService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public AuthResponse login(AuthRequest request) {
        if (request.getPassword() == null || request.getPassword().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La contraseña es obligatoria");
        }

        Cliente cliente = clienteRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));

        // Verificamos contraseña
        if (!passwordEncoder.matches(request.getPassword(), cliente.getPassword())) {
            // Usamos UNAUTHORIZED (401) en lugar de lanzar una excepción genérica (500)
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Contraseña incorrecta");
        }

        // Protección contra Roles nulos 
        String nombreRol = "cliente"; // Default fallback
        if (cliente.getRol() != null) {
            nombreRol = cliente.getRol().getNombre();
        } else {
             // Lanzar error si un usuario no tiene rol es inaceptable
             throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Usuario sin rol asignado");
        }

        String token = jwtUtil.generateToken(
                cliente.getId(),
                cliente.getEmail(),
                nombreRol
        );

        return new AuthResponse(token, cliente.getId(), cliente.getEmail(), nombreRol);
    }
}