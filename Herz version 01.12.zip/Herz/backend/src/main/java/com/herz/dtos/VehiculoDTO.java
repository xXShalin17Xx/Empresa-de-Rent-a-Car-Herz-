package com.herz.dtos;

public class VehiculoDTO {
    private String patente;
    private String modelo;
    private String tipo;
    private String estado;
    private Double kilometraje;
    private Long idSucursal;

    public String getPatente() { return patente; }
    public void setPatente(String patente) { this.patente = patente; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Double getKilometraje() { return kilometraje; }
    public void setKilometraje(Double kilometraje) { this.kilometraje = kilometraje; }

    public Long getIdSucursal() { return idSucursal; }
    public void setIdSucursal(Long idSucursal) { this.idSucursal = idSucursal; }
}