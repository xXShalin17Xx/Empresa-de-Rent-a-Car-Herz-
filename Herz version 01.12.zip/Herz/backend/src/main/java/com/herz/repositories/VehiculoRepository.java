package com.herz.repositories;

import com.herz.models.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {
    List<Vehiculo> findBySucursal_Id(Long sucursalId);
    List<Vehiculo> findBySucursal_IdAndEstado(Long sucursalId, Vehiculo.EstadoVehiculo estado);
    List<Vehiculo> findByEstado(Vehiculo.EstadoVehiculo estado);
}