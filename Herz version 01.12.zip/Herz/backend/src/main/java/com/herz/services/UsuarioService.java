package com.herz.services;

import com.herz.models.Cliente;
import com.herz.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UsuarioService {

    private final ClienteRepository clienteRepository;

    @Autowired
    public UsuarioService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    /**
     * Obtiene un cliente por su ID.
     * Corresponde a la operación GET /api/usuarios/{id}.
     */
    public Cliente obtenerClientePorId(Long id) {
        return clienteRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND, 
                    "Cliente no encontrado con ID: " + id
            ));
    }

    /**
     * Actualiza el perfil del cliente (solo nombre y telefono).
     * Corresponde a la operación PUT /api/usuarios/{id}.
     */
    @Transactional
    public Cliente actualizarPerfil(Long id, Cliente clienteUpdate) {
        // 1. Buscar el cliente existente
        Cliente existente = clienteRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND, 
                    "No se puede actualizar. Cliente no encontrado con ID: " + id
            ));
        
        // 2. Aplicar las actualizaciones permitidas (solo nombre y telefono)
        if (StringUtils.hasText(clienteUpdate.getNombre())) {
            existente.setNombre(clienteUpdate.getNombre());
        }

        if (StringUtils.hasText(clienteUpdate.getTelefono())) {
            existente.setTelefono(clienteUpdate.getTelefono());
        }
        return clienteRepository.save(existente);
    }
}