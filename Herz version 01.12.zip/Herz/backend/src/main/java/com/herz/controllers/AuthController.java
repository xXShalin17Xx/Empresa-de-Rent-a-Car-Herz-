package com.herz.controllers;

import com.herz.dtos.AuthRequest;
import com.herz.dtos.AuthResponse;
import com.herz.models.Cliente;
import com.herz.models.Rol;
import com.herz.repositories.ClienteRepository;
import com.herz.repositories.RolRepository;
import com.herz.security.JwtUtil;
import com.herz.services.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {
        // Asegúrate que tu AuthService use request.getEmail() y request.getPassword()
        return authService.login(request);
    }

    @PostMapping("/register")
    public AuthResponse register(@RequestBody Cliente nuevoCliente) {
        // Verificar si ya existe un usuario con el mismo email
        if (clienteRepository.findByEmail(nuevoCliente.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe un usuario con ese email");
        }

        // Buscar rol "cliente" en la base de datos
        Rol rolCliente = rolRepository.findByNombre("cliente")
                .orElseThrow(() -> new RuntimeException("Rol 'cliente' no encontrado."));

        // Encriptar la contraseña antes de guardar
        nuevoCliente.setPassword(passwordEncoder.encode(nuevoCliente.getPassword()));

        // Asignar rol y guardar
        nuevoCliente.setRol(rolCliente);
        clienteRepository.save(nuevoCliente);

        // Generar token JWT automáticamente
        String token = jwtUtil.generateToken(
                nuevoCliente.getId(),
                nuevoCliente.getEmail(),
                rolCliente.getNombre()
        );

        // Retornar AuthResponse con token y datos básicos
        return new AuthResponse(
                token,
                nuevoCliente.getId(),
                nuevoCliente.getEmail(),
                rolCliente.getNombre()
        );
    }
}