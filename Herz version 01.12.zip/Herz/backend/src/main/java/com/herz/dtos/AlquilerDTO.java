package com.herz.dtos;

public class AlquilerDTO {
    private Long idReserva;
    private Long idVehiculo;
    private Double kmFinal;

    public Long getIdReserva() { return idReserva; }
    public void setIdReserva(Long idReserva) { this.idReserva = idReserva; }

    public Long getIdVehiculo() { return idVehiculo; }
    public void setIdVehiculo(Long idVehiculo) { this.idVehiculo = idVehiculo; }

    public Double getKmFinal() { return kmFinal; }
    public void setKmFinal(Double kmFinal) { this.kmFinal = kmFinal; }
}