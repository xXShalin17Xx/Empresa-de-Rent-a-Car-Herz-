package com.herz.tests.security;

import com.herz.security.JwtUtil;
import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class JwtUtilTest {

    private JwtUtil jwtUtil;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil();
    }

    @Test
    void generateToken_and_extractClaims_correctly() {
        // 🔹 Arrange
        Long id = 99L;
        String email = "test@herz.com";
        String rol = "admin";

        // 🔹 Act
        String token = jwtUtil.generateToken(id, email, rol);

        // 🔹 Assert
        assertNotNull(token);
        assertTrue(token.startsWith("ey")); // JWT base64

        String extractedEmail = jwtUtil.extractUsername(token);
        assertEquals(email, extractedEmail);

        Claims claims = jwtUtil.extractClaim(token, c -> c);
        assertEquals("admin", claims.get("rol"));
        assertEquals(99, claims.get("id"));
    }

    @Test
    void validateToken_withCorrectUserDetails_returnsTrue() {
        // 🔹 Arrange
        String email = "valid@herz.com";
        String token = jwtUtil.generateToken(1L, email, "cliente");

        UserDetails userDetails = User.builder()
                .username(email)
                .password("irrelevant")
                .roles("cliente")
                .build();

        // 🔹 Act
        boolean isValid = jwtUtil.validateToken(token, userDetails);

        // 🔹 Assert
        assertTrue(isValid);
    }

    @Test
    void validateToken_withWrongUser_returnsFalse() {
        // 🔹 Arrange
        String token = jwtUtil.generateToken(1L, "real@herz.com", "cliente");

        UserDetails fakeUser = User.builder()
                .username("fake@herz.com")
                .password("irrelevant")
                .roles("cliente")
                .build();

        // 🔹 Act
        boolean isValid = jwtUtil.validateToken(token, fakeUser);

        // 🔹 Assert
        assertFalse(isValid);
    }

    @Test
    void isTokenExpired_returnsFalseForFreshToken() {
        // 🔹 Arrange
        String token = jwtUtil.generateToken(1L, "fresh@herz.com", "cliente");

        // 🔹 Act
        Date expiration = jwtUtil.extractClaim(token, Claims::getExpiration);

        // 🔹 Assert
        assertTrue(expiration.after(new Date()));
    }
}