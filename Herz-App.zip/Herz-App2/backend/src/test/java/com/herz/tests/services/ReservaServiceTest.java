package com.herz.tests.services;

import com.herz.dtos.ReservaDTO;
import com.herz.models.Cliente;
import com.herz.models.Reserva;
import com.herz.repositories.ClienteRepository;
import com.herz.repositories.ReservaRepository;
import com.herz.services.ReservaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReservaServiceTest {

    @InjectMocks
    private ReservaService reservaService;

    @Mock
    private ReservaRepository reservaRepository;

    @Mock
    private ClienteRepository clienteRepository;

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente();
        cliente.setId(1L);
        cliente.setEmail("cliente@herz.com");
    }

    @Test
    void crearReserva_clienteValido_guardaReserva() {
        // 🔹 Arrange
        ReservaDTO dto = new ReservaDTO();
        dto.idCliente = 1L;
        dto.tipoVehiculo = "SUV";
        dto.fechaInicio = LocalDate.of(2025, 11, 20);
        dto.fechaFin = LocalDate.of(2025, 11, 25);

        when(clienteRepository.findById(1L)).thenReturn(Optional.of(cliente));
        when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        reservaService.crearReserva(dto);

        // 🔹 Assert
        ArgumentCaptor<Reserva> captor = ArgumentCaptor.forClass(Reserva.class);
        verify(reservaRepository).save(captor.capture());

        Reserva reservaGuardada = captor.getValue();
        assertEquals(cliente, reservaGuardada.getCliente());
        assertEquals("SUV", reservaGuardada.getTipoVehiculo());
        assertEquals(LocalDate.of(2025, 11, 20), reservaGuardada.getFechaInicio());
        assertEquals(LocalDate.of(2025, 11, 25), reservaGuardada.getFechaFin());
        assertEquals("pendiente", reservaGuardada.getEstado());
    }

    @Test
    void listarTodas_devuelveListaDeReservas() {
        // 🔹 Arrange
        Reserva r1 = new Reserva();
        r1.setId(1L);
        Reserva r2 = new Reserva();
        r2.setId(2L);

        when(reservaRepository.findAll()).thenReturn(List.of(r1, r2));

        // 🔹 Act
        List<Reserva> resultado = reservaService.listarTodas();

        // 🔹 Assert
        assertEquals(2, resultado.size());
        assertEquals(1L, resultado.get(0).getId());
        assertEquals(2L, resultado.get(1).getId());
    }
}