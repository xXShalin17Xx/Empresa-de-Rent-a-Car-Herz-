package com.herz.tests.services;

import com.herz.dtos.AlquilerDTO;
import com.herz.models.Alquiler;
import com.herz.models.Reserva;
import com.herz.models.Vehiculo;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.repositories.AlquilerRepository;
import com.herz.repositories.ReservaRepository;
import com.herz.repositories.VehiculoRepository;
import com.herz.services.AlquilerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AlquilerServiceTest {

    @InjectMocks
    private AlquilerService alquilerService;

    @Mock
    private AlquilerRepository alquilerRepository;

    @Mock
    private ReservaRepository reservaRepository;

    @Mock
    private VehiculoRepository vehiculoRepository;

    private Reserva reserva;
    private Vehiculo vehiculo;

    @BeforeEach
    void setUp() {
        reserva = new Reserva();
        reserva.setId(1L);
        reserva.setEstado("pendiente");

        vehiculo = new Vehiculo();
        vehiculo.setId(2L);
        vehiculo.setEstado(EstadoVehiculo.disponible);
        vehiculo.setKilometraje(10000.0);
    }

    @Test
    void confirmarRetiro_vehiculoDisponible_creaAlquiler() {
        // 🔹 Arrange
        AlquilerDTO dto = new AlquilerDTO();
        dto.idReserva = 1L;
        dto.idVehiculo = 2L;

        when(reservaRepository.findById(1L)).thenReturn(Optional.of(reserva));
        when(vehiculoRepository.findById(2L)).thenReturn(Optional.of(vehiculo));
        when(alquilerRepository.save(any(Alquiler.class))).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        Alquiler resultado = alquilerService.confirmarRetiro(dto);

        // 🔹 Assert
        assertNotNull(resultado);
        assertEquals(vehiculo, resultado.getVehiculo());
        assertEquals(reserva, resultado.getReserva());
        assertEquals(10000.0, resultado.getKmInicial());
        assertEquals(EstadoVehiculo.alquilado, vehiculo.getEstado());
        assertEquals("en curso", reserva.getEstado());

        verify(alquilerRepository).save(any(Alquiler.class));
        verify(vehiculoRepository).save(vehiculo);
        verify(reservaRepository).save(reserva);
    }

    @Test
    void confirmarRetiro_vehiculoNoDisponible_lanzaExcepcion() {
        // 🔹 Arrange
        vehiculo.setEstado(EstadoVehiculo.mantenimiento);
        AlquilerDTO dto = new AlquilerDTO();
        dto.idReserva = 1L;
        dto.idVehiculo = 2L;

        when(reservaRepository.findById(1L)).thenReturn(Optional.of(reserva));
        when(vehiculoRepository.findById(2L)).thenReturn(Optional.of(vehiculo));

        // 🔹 Act & Assert
        IllegalStateException ex = assertThrows(IllegalStateException.class, () ->
                alquilerService.confirmarRetiro(dto)
        );
        assertEquals("El vehículo no está disponible", ex.getMessage());
    }

    @Test
    void registrarDevolucion_actualizaAlquilerVehiculoYReserva() {
        // 🔹 Arrange
        Alquiler alquiler = new Alquiler();
        alquiler.setId(10L);
        alquiler.setKmInicial(10000.0);
        alquiler.setVehiculo(vehiculo);
        alquiler.setReserva(reserva);

        when(alquilerRepository.findById(10L)).thenReturn(Optional.of(alquiler));
        when(alquilerRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(vehiculoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(reservaRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        Alquiler resultado = alquilerService.registrarDevolucion(10L, 10250.0);

        // 🔹 Assert
        assertNotNull(resultado.getFechaDevolucion());
        assertEquals(10250.0, resultado.getKmFinal());
        assertEquals(EstadoVehiculo.disponible, vehiculo.getEstado());
        assertEquals("finalizada", reserva.getEstado());
        assertEquals(10250.0, vehiculo.getKilometraje());

        verify(alquilerRepository).save(alquiler);
        verify(vehiculoRepository).save(vehiculo);
        verify(reservaRepository).save(reserva);
    }
}