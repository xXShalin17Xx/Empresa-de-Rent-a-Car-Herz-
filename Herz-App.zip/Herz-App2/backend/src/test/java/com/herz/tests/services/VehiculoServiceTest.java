package com.herz.tests.services;

import com.herz.dtos.VehiculoDTO;
import com.herz.models.Sucursal;
import com.herz.models.Vehiculo;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.repositories.SucursalRepository;
import com.herz.repositories.VehiculoRepository;
import com.herz.services.VehiculoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VehiculoServiceTest {

    @InjectMocks
    private VehiculoService vehiculoService;

    @Mock
    private VehiculoRepository vehiculoRepository;

    @Mock
    private SucursalRepository sucursalRepository;

    private Sucursal sucursal;

    @BeforeEach
    void setUp() {
        sucursal = new Sucursal();
        sucursal.setId(1L);
        sucursal.setNombre("Sucursal Central");
    }

    @Test
    void crearVehiculo_sucursalValida_creaVehiculoCorrectamente() {
        // 🔹 Arrange
        VehiculoDTO dto = new VehiculoDTO();
        dto.patente = "ABC123";
        dto.modelo = "Toyota Corolla";
        dto.tipo = "sedan";
        dto.estado = "disponible";
        dto.kilometraje = 15000.0;
        dto.idSucursal = 1L;

        when(sucursalRepository.findById(1L)).thenReturn(Optional.of(sucursal));
        when(vehiculoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        Vehiculo resultado = vehiculoService.crearVehiculo(dto);

        // 🔹 Assert
        assertEquals("ABC123", resultado.getPatente());
        assertEquals("Toyota Corolla", resultado.getModelo());
        assertEquals("sedan", resultado.getTipo());
        assertEquals(EstadoVehiculo.disponible, resultado.getEstado());
        assertEquals(15000.0, resultado.getKilometraje());
        assertEquals(sucursal, resultado.getSucursal());

        verify(sucursalRepository).findById(1L);
        verify(vehiculoRepository).save(any());
    }

    @Test
    void listarTodos_devuelveListaDeVehiculos() {
        // 🔹 Arrange
        Vehiculo v1 = new Vehiculo();
        v1.setId(1L);
        Vehiculo v2 = new Vehiculo();
        v2.setId(2L);

        when(vehiculoRepository.findAll()).thenReturn(List.of(v1, v2));

        // 🔹 Act
        List<Vehiculo> resultado = vehiculoService.listarTodos();

        // 🔹 Assert
        assertEquals(2, resultado.size());
        assertEquals(1L, resultado.get(0).getId());
        assertEquals(2L, resultado.get(1).getId());
    }
}