package com.herz.tests.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herz.controllers.VehiculoController;
import com.herz.dtos.VehiculoDTO;
import com.herz.models.Sucursal;
import com.herz.models.Vehiculo;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.services.VehiculoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(VehiculoController.class)
class VehiculoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VehiculoService vehiculoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void crearVehiculo_datosValidos_retornaVehiculo() throws Exception {
        // 🔹 Arrange
        VehiculoDTO dto = new VehiculoDTO();
        dto.patente = "XYZ789";
        dto.modelo = "Ford Focus";
        dto.tipo = "hatchback";
        dto.estado = "disponible";
        dto.kilometraje = 20000.0;
        dto.idSucursal = 1L;

        Sucursal sucursal = new Sucursal();
        sucursal.setId(1L);

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(10L);
        vehiculo.setPatente("XYZ789");
        vehiculo.setModelo("Ford Focus");
        vehiculo.setTipo("hatchback");
        vehiculo.setEstado(EstadoVehiculo.disponible);
        vehiculo.setKilometraje(20000.0);
        vehiculo.setSucursal(sucursal);

        Mockito.when(vehiculoService.crearVehiculo(any())).thenReturn(vehiculo);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/vehiculos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.patente").value("XYZ789"))
                .andExpect(jsonPath("$.modelo").value("Ford Focus"))
                .andExpect(jsonPath("$.tipo").value("hatchback"))
                .andExpect(jsonPath("$.estado").value("disponible"))
                .andExpect(jsonPath("$.kilometraje").value(20000.0));
    }

    @Test
    void listarTodos_devuelveListaDeVehiculos() throws Exception {
        // 🔹 Arrange
        Vehiculo v1 = new Vehiculo();
        v1.setId(1L);
        v1.setPatente("AAA111");

        Vehiculo v2 = new Vehiculo();
        v2.setId(2L);
        v2.setPatente("BBB222");

        Mockito.when(vehiculoService.listarTodos()).thenReturn(List.of(v1, v2));

        // 🔹 Act & Assert
        mockMvc.perform(get("/api/vehiculos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].patente").value("AAA111"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].patente").value("BBB222"));
    }
}