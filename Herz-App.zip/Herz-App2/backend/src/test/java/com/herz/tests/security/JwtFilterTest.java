package com.herz.tests.security;

import com.herz.security.JwtFilter;
import com.herz.security.JwtUtil;
import com.herz.services.CustomUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.IOException;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JwtFilterTest {

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private CustomUserDetailsService userDetailsService;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    private JwtFilterTestWrapper jwtFilter;

    @BeforeEach
    void setUp() {
        jwtFilter = new JwtFilterTestWrapper(jwtUtil, userDetailsService);
        SecurityContextHolder.clearContext();
    }

    @Test
    void doFilterInternal_tokenValido_autenticaUsuario() throws ServletException, IOException {
        // 🔹 Arrange
        String token = "Bearer valid.jwt.token";
        String email = "usuario@herz.com";

        when(request.getHeader("Authorization")).thenReturn(token);
        when(jwtUtil.extractUsername("valid.jwt.token")).thenReturn(email);
        when(jwtUtil.validateToken(eq("valid.jwt.token"), any())).thenReturn(true);

        UserDetails userDetails = new User(email, "irrelevant", Collections.emptyList());
        when(userDetailsService.loadUserByUsername(email)).thenReturn(userDetails);

        // 🔹 Act
        jwtFilter.invokeDoFilterInternal(request, response, filterChain);

        // 🔹 Assert
        var auth = SecurityContextHolder.getContext().getAuthentication();
        assertNotNull(auth);
        assertEquals(email, auth.getName());
        assertTrue(auth instanceof UsernamePasswordAuthenticationToken);

        verify(filterChain).doFilter(request, response);
    }

    @Test
    void doFilterInternal_tokenInvalido_noAutentica() throws ServletException, IOException {
        // 🔹 Arrange
        when(request.getHeader("Authorization")).thenReturn("Bearer invalid.token");
        when(jwtUtil.extractUsername("invalid.token")).thenReturn("usuario@herz.com");
        when(jwtUtil.validateToken(eq("invalid.token"), any())).thenReturn(false);

        // 🔹 Act
        jwtFilter.invokeDoFilterInternal(request, response, filterChain);

        // 🔹 Assert
        assertNull(SecurityContextHolder.getContext().getAuthentication());
        verify(filterChain).doFilter(request, response);
    }

    @Test
    void doFilterInternal_sinHeader_noAutentica() throws ServletException, IOException {
        // 🔹 Arrange
        when(request.getHeader("Authorization")).thenReturn(null);

        // 🔹 Act
        jwtFilter.invokeDoFilterInternal(request, response, filterChain);

        // 🔹 Assert
        assertNull(SecurityContextHolder.getContext().getAuthentication());
        verify(filterChain).doFilter(request, response);
    }

    // Subclase pública para exponer el método protegido
    static class JwtFilterTestWrapper extends JwtFilter {
        public JwtFilterTestWrapper(JwtUtil jwtUtil, CustomUserDetailsService userDetailsService) {
            super(jwtUtil, userDetailsService);
        }

        public void invokeDoFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                throws ServletException, IOException {
            super.doFilterInternal(request, response, chain);
        }
    }
}