package com.herz.tests.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herz.controllers.ReservaController;
import com.herz.dtos.ReservaDTO;
import com.herz.models.Cliente;
import com.herz.models.Reserva;
import com.herz.services.ReservaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ReservaController.class)
class ReservaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReservaService reservaService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void crearReserva_datosValidos_retornaStatusOk() throws Exception {
        // 🔹 Arrange
        ReservaDTO dto = new ReservaDTO();
        dto.idCliente = 1L;
        dto.tipoVehiculo = "SUV";
        dto.fechaInicio = LocalDate.of(2025, 11, 20);
        dto.fechaFin = LocalDate.of(2025, 11, 25);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/reservas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk());

        Mockito.verify(reservaService).crearReserva(any());
    }

    @Test
    void listarTodas_devuelveListaDeReservas() throws Exception {
        // 🔹 Arrange
        Cliente cliente = new Cliente();
        cliente.setId(1L);

        Reserva r1 = new Reserva();
        r1.setId(1L);
        r1.setCliente(cliente);
        r1.setTipoVehiculo("sedan");
        r1.setEstado("pendiente");

        Reserva r2 = new Reserva();
        r2.setId(2L);
        r2.setCliente(cliente);
        r2.setTipoVehiculo("SUV");
        r2.setEstado("pendiente");

        Mockito.when(reservaService.listarTodas()).thenReturn(List.of(r1, r2));

        // 🔹 Act & Assert
        mockMvc.perform(get("/api/reservas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[1].id").value(2));
    }
}