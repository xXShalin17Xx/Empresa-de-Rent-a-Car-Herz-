package com.herz.tests.services;

import com.herz.dtos.MantenimientoDTO;
import com.herz.models.Mantenimiento;
import com.herz.models.Vehiculo;
import com.herz.models.Mantenimiento.Estado;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.repositories.MantenimientoRepository;
import com.herz.repositories.VehiculoRepository;
import com.herz.services.MantenimientoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MantenimientoServiceTest {

    @InjectMocks
    private MantenimientoService mantenimientoService;

    @Mock
    private MantenimientoRepository mantenimientoRepository;

    @Mock
    private VehiculoRepository vehiculoRepository;

    private Vehiculo vehiculo;

    @BeforeEach
    void setUp() {
        vehiculo = new Vehiculo();
        vehiculo.setId(1L);
        vehiculo.setEstado(EstadoVehiculo.disponible);
    }

    @Test
    void crearOrden_vehiculoValido_creaMantenimientoYPoneEnMantenimiento() {
        // 🔹 Arrange
        MantenimientoDTO dto = new MantenimientoDTO();
        dto.idVehiculo = 1L;
        dto.tipo = "aceite";
        dto.costo = 500.0;

        when(vehiculoRepository.findById(1L)).thenReturn(Optional.of(vehiculo));
        when(mantenimientoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(vehiculoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        Mantenimiento resultado = mantenimientoService.crearOrden(dto);

        // 🔹 Assert
        assertEquals("aceite", resultado.getTipo());
        assertEquals(500.0, resultado.getCosto());
        assertEquals(Estado.pendiente, resultado.getEstado());
        assertEquals(vehiculo, resultado.getVehiculo());
        assertEquals(EstadoVehiculo.mantenimiento, vehiculo.getEstado());

        verify(mantenimientoRepository).save(any());
        verify(vehiculoRepository).save(vehiculo);
    }

    @Test
    void listarPendientes_devuelveSoloPendientes() {
        // 🔹 Arrange
        Mantenimiento m1 = new Mantenimiento();
        m1.setId(1L);
        m1.setEstado(Estado.pendiente);

        Mantenimiento m2 = new Mantenimiento();
        m2.setId(2L);
        m2.setEstado(Estado.pendiente);

        when(mantenimientoRepository.findByEstado(Estado.pendiente)).thenReturn(List.of(m1, m2));

        // 🔹 Act
        List<Mantenimiento> resultado = mantenimientoService.listarPendientes();

        // 🔹 Assert
        assertEquals(2, resultado.size());
        assertEquals(1L, resultado.get(0).getId());
        assertEquals(2L, resultado.get(1).getId());
    }

    @Test
    void marcarCompletado_actualizaEstadoYVehiculo() {
        // 🔹 Arrange
        Mantenimiento mantenimiento = new Mantenimiento();
        mantenimiento.setId(3L);
        mantenimiento.setEstado(Estado.pendiente);
        mantenimiento.setVehiculo(vehiculo);

        when(mantenimientoRepository.findById(3L)).thenReturn(Optional.of(mantenimiento));
        when(mantenimientoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(vehiculoRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        // 🔹 Act
        Mantenimiento resultado = mantenimientoService.marcarCompletado(3L);

        // 🔹 Assert
        assertEquals(Estado.completado, resultado.getEstado());
        assertEquals(EstadoVehiculo.disponible, vehiculo.getEstado());

        verify(mantenimientoRepository).save(mantenimiento);
        verify(vehiculoRepository).save(vehiculo);
    }
}