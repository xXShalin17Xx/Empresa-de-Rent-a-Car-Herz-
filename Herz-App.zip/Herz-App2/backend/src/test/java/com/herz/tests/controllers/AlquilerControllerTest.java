package com.herz.tests.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herz.controllers.AlquilerController;
import com.herz.dtos.AlquilerDTO;
import com.herz.models.Alquiler;
import com.herz.models.Reserva;
import com.herz.models.Vehiculo;
import com.herz.services.AlquilerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AlquilerController.class)
class AlquilerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AlquilerService alquilerService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void confirmarRetiro_datosValidos_retornaAlquiler() throws Exception {
        // 🔹 Arrange
        AlquilerDTO dto = new AlquilerDTO();
        dto.idReserva = 1L;
        dto.idVehiculo = 2L;

        Reserva reserva = new Reserva();
        reserva.setId(1L);

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(2L);

        Alquiler alquiler = new Alquiler();
        alquiler.setId(10L);
        alquiler.setReserva(reserva);
        alquiler.setVehiculo(vehiculo);
        alquiler.setKmInicial(10000.0);

        Mockito.when(alquilerService.confirmarRetiro(any())).thenReturn(alquiler);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/alquileres/confirmar-retiro")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.kmInicial").value(10000.0));
    }

    @Test
    void registrarDevolucion_datosValidos_retornaAlquilerActualizado() throws Exception {
        // 🔹 Arrange
        Alquiler alquiler = new Alquiler();
        alquiler.setId(10L);
        alquiler.setKmFinal(10250.0);

        Mockito.when(alquilerService.registrarDevolucion(eq(10L), eq(10250.0))).thenReturn(alquiler);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/alquileres/registrar-devolucion")
                        .param("idAlquiler", "10")
                        .param("kmFinal", "10250.0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.kmFinal").value(10250.0));
    }
}