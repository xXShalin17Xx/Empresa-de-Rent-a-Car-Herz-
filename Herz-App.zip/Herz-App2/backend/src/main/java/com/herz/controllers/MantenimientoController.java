package com.herz.controllers;

import com.herz.dtos.MantenimientoDTO;
import com.herz.models.Mantenimiento;
import com.herz.services.MantenimientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mantenimiento")
public class MantenimientoController {

    @Autowired
    private MantenimientoService mantenimientoService;

    @PostMapping
    public Mantenimiento crearOrden(@RequestBody MantenimientoDTO dto) {
        return mantenimientoService.crearOrden(dto);
    }

    @GetMapping("/pendientes")
    public List<Mantenimiento> listarPendientes() {
        return mantenimientoService.listarPendientes();
    }

    @PostMapping("/completar/{id}")
    public Mantenimiento marcarCompletado(@PathVariable Long id) {
        return mantenimientoService.marcarCompletado(id);
    }
}