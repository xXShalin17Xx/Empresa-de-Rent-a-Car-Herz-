package com.herz.dtos;

public class VehiculoDTO {
    public String patente;
    public String modelo;
    public String tipo;
    public String estado;
    public Double kilometraje;
    public Long idSucursal;
}