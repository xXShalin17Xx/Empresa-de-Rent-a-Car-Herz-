package com.herz.services;

import com.herz.dtos.AlquilerDTO;
import com.herz.models.*;
import com.herz.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AlquilerService {

    @Autowired
    private AlquilerRepository alquilerRepository;

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private VehiculoRepository vehiculoRepository;

    public Alquiler confirmarRetiro(AlquilerDTO dto) {
        Reserva reserva = reservaRepository.findById(dto.idReserva).orElseThrow();
        Vehiculo vehiculo = vehiculoRepository.findById(dto.idVehiculo).orElseThrow();

        if (!vehiculo.getEstado().equals(Vehiculo.EstadoVehiculo.disponible)) {
            throw new IllegalStateException("El vehículo no está disponible");
        }

        Alquiler alquiler = new Alquiler();
        alquiler.setReserva(reserva);
        alquiler.setVehiculo(vehiculo);
        alquiler.setKmInicial(vehiculo.getKilometraje());
        alquilerRepository.save(alquiler);

        vehiculo.setEstado(Vehiculo.EstadoVehiculo.alquilado);
        reserva.setEstado("en curso");
        vehiculoRepository.save(vehiculo);
        reservaRepository.save(reserva);

        return alquiler;
    }

    public Alquiler registrarDevolucion(Long idAlquiler, Double kmFinal) {
        Alquiler alquiler = alquilerRepository.findById(idAlquiler).orElseThrow();
        Vehiculo vehiculo = alquiler.getVehiculo();
        Reserva reserva = alquiler.getReserva();

        alquiler.setFechaDevolucion(LocalDateTime.now());
        alquiler.setKmFinal(kmFinal);
        alquilerRepository.save(alquiler);

        vehiculo.setKilometraje(kmFinal);
        vehiculo.setEstado(Vehiculo.EstadoVehiculo.disponible);
        reserva.setEstado("finalizada");
        vehiculoRepository.save(vehiculo);
        reservaRepository.save(reserva);

        return alquiler;
    }
}