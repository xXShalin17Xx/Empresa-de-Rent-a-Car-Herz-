package com.herz.dtos;

public class AuthResponse {
    public String token;
    public Long id;
    public String email;
    public String rol;

    public AuthResponse(String token, Long id, String email, String rol) {
        this.token = token;
        this.id = id;
        this.email = email;
        this.rol = rol;
    }
}