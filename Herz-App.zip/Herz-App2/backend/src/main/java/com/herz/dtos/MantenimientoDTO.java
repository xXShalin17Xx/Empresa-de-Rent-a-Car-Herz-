package com.herz.dtos;

public class MantenimientoDTO {
    public Long idVehiculo;
    public String tipo;
    public Double costo;
}