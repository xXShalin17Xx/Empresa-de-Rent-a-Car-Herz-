package com.herz.services;

import com.herz.models.Cliente;
import com.herz.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Cliente cliente = clienteRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + email));

        // Usamos cliente.getContrasena(), no getPassword()
        return User.builder()
                .username(cliente.getEmail())
                .password(cliente.getContrasena())
                .roles(cliente.getRol().getNombre())
                .build();
    }
}
