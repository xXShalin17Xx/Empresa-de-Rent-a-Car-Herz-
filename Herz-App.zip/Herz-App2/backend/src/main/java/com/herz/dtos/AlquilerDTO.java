package com.herz.dtos;

public class AlquilerDTO {
    public Long idReserva;
    public Long idVehiculo;
    public Double kmFinal; // solo se usa en devolución
}