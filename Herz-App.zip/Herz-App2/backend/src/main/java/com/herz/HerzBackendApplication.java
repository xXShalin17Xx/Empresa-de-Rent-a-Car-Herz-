package com.herz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HerzBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(HerzBackendApplication.class, args);
    }
}