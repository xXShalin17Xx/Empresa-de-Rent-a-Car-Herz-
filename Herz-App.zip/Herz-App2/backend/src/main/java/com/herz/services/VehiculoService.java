package com.herz.services;

import com.herz.dtos.VehiculoDTO;
import com.herz.models.Vehiculo;
import com.herz.models.Sucursal;
import com.herz.models.Vehiculo.EstadoVehiculo;
import com.herz.repositories.VehiculoRepository;
import com.herz.repositories.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehiculoService {

    @Autowired
    private VehiculoRepository vehiculoRepository;

    @Autowired
    private SucursalRepository sucursalRepository;

    public Vehiculo crearVehiculo(VehiculoDTO dto) {
        Sucursal sucursal = sucursalRepository.findById(dto.idSucursal).orElseThrow();
        Vehiculo v = new Vehiculo();
        v.setPatente(dto.patente);
        v.setModelo(dto.modelo);
        v.setTipo(dto.tipo);
        v.setEstado(EstadoVehiculo.valueOf(dto.estado));
        v.setKilometraje(dto.kilometraje);
        v.setSucursal(sucursal);
        return vehiculoRepository.save(v);
    }

    public List<Vehiculo> listarTodos() {
        return vehiculoRepository.findAll();
    }
}