package com.herz.services;

import com.herz.dtos.MantenimientoDTO;
import com.herz.models.Mantenimiento;
import com.herz.models.Vehiculo;
import com.herz.repositories.MantenimientoRepository;
import com.herz.repositories.VehiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MantenimientoService {

    @Autowired
    private MantenimientoRepository mantenimientoRepository;

    @Autowired
    private VehiculoRepository vehiculoRepository;

    public Mantenimiento crearOrden(MantenimientoDTO dto) {
        Vehiculo vehiculo = vehiculoRepository.findById(dto.idVehiculo).orElseThrow();

        Mantenimiento m = new Mantenimiento();
        m.setVehiculo(vehiculo);
        m.setTipo(dto.tipo);
        m.setCosto(dto.costo);
        m.setEstado(Mantenimiento.Estado.pendiente);

        vehiculo.setEstado(Vehiculo.EstadoVehiculo.mantenimiento);
        vehiculoRepository.save(vehiculo);

        return mantenimientoRepository.save(m);
    }

    public List<Mantenimiento> listarPendientes() {
        return mantenimientoRepository.findByEstado(Mantenimiento.Estado.pendiente);
    }

    public Mantenimiento marcarCompletado(Long id) {
        Mantenimiento m = mantenimientoRepository.findById(id).orElseThrow();
        m.setEstado(Mantenimiento.Estado.completado);
        mantenimientoRepository.save(m);

        Vehiculo v = m.getVehiculo();
        v.setEstado(Vehiculo.EstadoVehiculo.disponible);
        vehiculoRepository.save(v);

        return m;
    }
}