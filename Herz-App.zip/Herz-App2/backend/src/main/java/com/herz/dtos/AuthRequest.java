package com.herz.dtos;

public class AuthRequest {
    public String email;
    public String contrasena;
}