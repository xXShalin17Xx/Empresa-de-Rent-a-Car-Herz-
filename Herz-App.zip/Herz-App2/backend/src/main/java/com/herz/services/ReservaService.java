    package com.herz.services;

    import com.herz.dtos.ReservaDTO;
    import com.herz.models.Cliente;
    import com.herz.models.Reserva;
    import com.herz.repositories.ReservaRepository;
    import com.herz.repositories.ClienteRepository;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Service;

    import java.util.List;

    @Service
    public class ReservaService {

        @Autowired
        private ReservaRepository reservaRepository;

        @Autowired
        private ClienteRepository clienteRepository;

        public void crearReserva(ReservaDTO dto) {
            Cliente cliente = clienteRepository.findById(dto.idCliente).orElseThrow();
            Reserva reserva = new Reserva();
            reserva.setCliente(cliente);
            reserva.setTipoVehiculo(dto.tipoVehiculo);
            reserva.setFechaInicio(dto.fechaInicio);
            reserva.setFechaFin(dto.fechaFin);
            reserva.setEstado("pendiente");
            reservaRepository.save(reserva);
        }

        public List<Reserva> listarTodas() {
            return reservaRepository.findAll();
        }
    }