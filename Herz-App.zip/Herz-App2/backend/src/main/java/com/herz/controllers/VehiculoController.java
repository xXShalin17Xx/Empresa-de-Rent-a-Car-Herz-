package com.herz.controllers;

import com.herz.dtos.VehiculoDTO;
import com.herz.models.Vehiculo;
import com.herz.services.VehiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehiculos")
public class VehiculoController {

    @Autowired
    private VehiculoService vehiculoService;

    @PostMapping
    public Vehiculo crearVehiculo(@RequestBody VehiculoDTO dto) {
        return vehiculoService.crearVehiculo(dto);
    }

    @GetMapping
    public List<Vehiculo> listarVehiculos() {
        return vehiculoService.listarTodos();
    }
}