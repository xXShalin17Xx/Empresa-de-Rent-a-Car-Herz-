package com.herz.controllers;

import com.herz.dtos.ReservaDTO;
import com.herz.models.Reserva;
import com.herz.services.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservas")
public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    @PostMapping
    public String crearReserva(@RequestBody ReservaDTO dto) {
        reservaService.crearReserva(dto);
        return "Reserva creada correctamente";
    }

    @GetMapping
    public List<Reserva> listarReservas() {
        return reservaService.listarTodas();
    }
}