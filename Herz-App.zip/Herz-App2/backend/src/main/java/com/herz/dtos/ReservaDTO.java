package com.herz.dtos;

import java.time.LocalDate;

public class ReservaDTO {
    public Long idCliente;
    public String tipoVehiculo;
    public LocalDate fechaInicio;
    public LocalDate fechaFin;
}