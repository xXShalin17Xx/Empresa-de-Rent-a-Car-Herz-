import axios from 'axios';

const API = axios.create({
  baseURL: "http://localhost:8080/api",
});

// 🧩 Interceptor para agregar token automáticamente (excepto en login y register)
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');

  // No enviar token en rutas públicas
  if (
    token &&
    !config.url.includes('/auth/login') &&
    !config.url.includes('/auth/register')
  ) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

// ------------------ AUTENTICACIÓN ------------------

export const login = (email, password) =>
  API.post('/auth/login', { email, password });

export const register = (data) =>
  API.post('/auth/register', data);

export const getPerfil = () =>
  API.get('/clientes/me');

// ------------------ CLIENTE ------------------

export const getReservas = () =>
  API.get('/reservas');

export const crearReserva = (data) =>
  API.post('/reservas', data);

export const cancelarReserva = (id) =>
  API.delete(`/reservas/${id}`);

export const getAlquileresCliente = () =>
  API.get('/alquileres/mios');

// ------------------ EMPLEADO ------------------

export const getReservasActivas = () =>
  API.get('/reservas/activas');

export const confirmarRetiro = (idReserva, idVehiculo) =>
  API.post('/alquileres/confirmar', { idReserva, idVehiculo });

export const registrarDevolucion = (idReserva) =>
  API.post(`/alquileres/devolver`, { idReserva });

// ------------------ COORDINADOR ------------------

export const getVehiculosSucursal = () =>
  API.get('/vehiculos/sucursal');

export const crearMantenimiento = (data) =>
  API.post('/mantenimientos', data);

export const getMantenimientosSucursal = () =>
  API.get('/mantenimientos/sucursal');

export const getDisponibilidadVehiculos = () =>
  API.get('/vehiculos/disponibles');

// ------------------ MANTENIMIENTO ------------------

export const getMantenimientosPendientes = () =>
  API.get('/mantenimientos/pendientes');

export const completarMantenimiento = (id) =>
  API.put(`/mantenimientos/${id}/completar`);

// ------------------ ADMIN ------------------

export const getUsuarios = () =>
  API.get('/usuarios');

export const cambiarRolUsuario = (id, nuevoRol) =>
  API.put(`/usuarios/${id}/rol`, { rol: nuevoRol });

export const getReportesIngresos = () =>
  API.get('/reportes/ingresos');

export const getDashboardAdmin = () =>
  API.get('/reportes/dashboard');

export const actualizarPerfil = (data) =>
  API.put('/clientes/me', data);
