import { useAuth } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

const RutaProtegida = ({ children, rolesPermitidos }) => {
  const { usuario } = useAuth();

  if (!usuario || !rolesPermitidos.includes(usuario.rol)) {
    return <Navigate to="/login" />;
  }

  return children;
};

export default RutaProtegida;