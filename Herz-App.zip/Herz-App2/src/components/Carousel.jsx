const categorias = [
  { tipo: "economico", label: "Económico", img: "/carrousel-img/economico.jpg" },
  { tipo: "electrico", label: "Eléctrico", img: "/carrousel-img/electrico.jpg" },
  { tipo: "suv", label: "SUV", img: "/carrousel-img/suv.jpg" },
  { tipo: "lujo", label: "De lujo", img: "/carrousel-img/lujo.jpg" },
];

const Carousel = ({ onSelect }) => {
  return (
    <div className="carousel">
      {categorias.map((cat) => (
        <div key={cat.tipo} className="card" onClick={() => onSelect(cat.tipo)}>
          <img src={cat.img} alt={cat.label} />
          <h3>{cat.label}</h3>
        </div>
      ))}
    </div>
  );
};

export default Carousel;