import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const { usuario } = useAuth();
  const navigate = useNavigate();

  const linksPorRol = {
    cliente: [
      { label: "Reservar", path: "/reservar" },
      { label: "Mis reservas", path: "/cliente/reservas" },
      { label: "Historial", path: "/cliente/historial" },
    ],
    empleado_sucursal: [
      { label: "Panel", path: "/empleado" },
    ],
    coordinador_flotas: [
      { label: "Panel", path: "/coordinador" },
    ],
    personal_mantenimiento: [
      { label: "Panel", path: "/mantenimiento" },
    ],
    admin: [
      { label: "Dashboard", path: "/admin" },
    ],
  };

  const links = linksPorRol[usuario?.rol] || [];

  return (
    <aside className="sidebar">
      <h3>Menú</h3>
      <ul>
        {links.map((link) => (
          <li key={link.path}>
            <button onClick={() => navigate(link.path)}>{link.label}</button>
          </li>
        ))}
      </ul>
    </aside>
  );
};

export default Sidebar;