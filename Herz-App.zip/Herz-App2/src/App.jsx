import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Registro from "./pages/Register";
import Home from "./pages/Home";

import Reservar from "./pages/Cliente/Reservar";
import ClienteHome from "./pages/Cliente/Home";
import AdminHome from "./pages/Admin/Dashboard";
import EmpleadoHome from "./pages/Empleado/Panel";
import CoordinadorHome from "./pages/Coordinador/Flota";
import MantenimientoHome from "./pages/Mantenimiento/Panel";
import MisReservas from "./pages/Cliente/MisReservas";
import HistorialAlquileres from "./pages/Cliente/HistorialAlquileres";
import Perfil from "./pages/Cliente/Perfil";

import RutaProtegida from "./components/RutaProtegida";

function App() {
  return (

    <BrowserRouter>
      <Routes>
        {/* Públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registro />} />

        {/* Acceso con sesión */}
        <Route path="/reservar" element={<Reservar />} />

        {/* Protegidas por rol */}
        <Route
          path="/cliente"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <ClienteHome />
            </RutaProtegida>
          }
        />
        <Route
          path="/admin"
          element={
            <RutaProtegida rolesPermitidos={["admin"]}>
              <AdminHome />
            </RutaProtegida>
          }
        />
        <Route
          path="/empleado"
          element={
            <RutaProtegida rolesPermitidos={["empleado_sucursal"]}>
              <EmpleadoHome />
            </RutaProtegida>
          }
        />
        <Route
          path="/coordinador"
          element={
            <RutaProtegida rolesPermitidos={["coordinador_flotas"]}>
              <CoordinadorHome />
            </RutaProtegida>
          }
        />
        <Route
          path="/mantenimiento"
          element={
            <RutaProtegida rolesPermitidos={["personal_mantenimiento"]}>
              <MantenimientoHome />
            </RutaProtegida>
          }
        />
        <Route
            path="/cliente/reservas"
            element={
              <RutaProtegida rolesPermitidos={["cliente"]}>
                <MisReservas />
              </RutaProtegida>
            }
        />
        <Route
          path="/cliente/historial"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <HistorialAlquileres />
            </RutaProtegida>
          }
        />
        <Route
          path="/perfil"
          element={
            <RutaProtegida rolesPermitidos={["cliente"]}>
              <Perfil />
            </RutaProtegida>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;