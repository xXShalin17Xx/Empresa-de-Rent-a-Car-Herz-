import { createContext, useContext, useState, useEffect } from "react";
import { login } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [usuario, setUsuario] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const rol = localStorage.getItem("rol");
    const nombre = localStorage.getItem("nombre");
    if (token && rol) {
      setUsuario({ token, rol, nombre });
    }
  }, []);

  const iniciarSesion = async (email, contrasena) => {
    const res = await login(email, contrasena);
    if (res.token) {
      localStorage.setItem("token", res.token);
      localStorage.setItem("rol", res.rol);
      localStorage.setItem("nombre", res.nombre);
      setUsuario({ token: res.token, rol: res.rol, nombre: res.nombre });
    }
  };

  const logout = () => {
    localStorage.clear();
    setUsuario(null);
  };

  return (
    <AuthContext.Provider value={{ usuario, iniciarSesion, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);