import "../../styles/admin.css";
import "../../styles/roles.css";
import { useEffect, useState } from "react";
import {
  getUsuarios,
  getReportesIngresos,
  getDashboardAdmin,
  cambiarRolUsuario,
} from "../../services/api";
import Sidebar from "../../components/Sidebar";

const AdminHome = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [ingresos, setIngresos] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [mensaje, setMensaje] = useState("");

  const cargar = async () => {
    const u = await getUsuarios();
    const i = await getReportesIngresos();
    const d = await getDashboardAdmin();
    setUsuarios(u);
    setIngresos(i);
    setDashboard(d);
  };

  useEffect(() => {
    cargar();
  }, []);

  return (
    <>
      <Sidebar />
      <main className="main-content">
        <header className="main-header">
          <div className="logo">Herz</div>
          <h2>Dashboard administrativo</h2>
          <a className="logout" href="/logout">Cerrar sesión</a>
        </header>

        {mensaje && <div className="message">{mensaje}</div>}

        <section>
          <h3>Usuarios registrados</h3>
          <p>Total: {usuarios.length}</p>
          <table>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Modificar</th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map((u) => (
                <tr key={u.id}>
                  <td>{u.nombre}</td>
                  <td>{u.email}</td>
                  <td>{u.rol}</td>
                  <td>
                    <select
                      value={u.rol}
                      onChange={async (e) => {
                        await cambiarRolUsuario(u.id, e.target.value);
                        setMensaje(`Rol de ${u.nombre} actualizado`);
                        cargar();
                      }}
                    >
                      <option value="cliente">Cliente</option>
                      <option value="empleado_sucursal">Empleado</option>
                      <option value="coordinador_flotas">Coordinador</option>
                      <option value="personal_mantenimiento">Mantenimiento</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section>
          <h3>Ingresos por sucursal</h3>
          {ingresos && ingresos.map((r) => (
            <p key={r.sucursal}>{r.sucursal}: ${r.total}</p>
          ))}
        </section>

        <section>
          <h3>Métricas generales</h3>
          {dashboard && (
            <ul className="dashboard">
              <li className="card">Reservas totales: {dashboard.reservas}</li>
              <li className="card">Alquileres activos: {dashboard.alquileres}</li>
              <li className="card">Vehículos disponibles: {dashboard.vehiculosDisponibles}</li>
            </ul>
          )}
        </section>
      </main>
    </>
  );
};

export default AdminHome;