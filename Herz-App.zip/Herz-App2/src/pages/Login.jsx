import "../styles/login.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const [email, setEmail] = useState("");
  const [contrasena, setContrasena] = useState("");
  const { iniciarSesion } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await iniciarSesion(email, contrasena);
    const rol = localStorage.getItem("rol");

    switch (rol) {
      case "cliente":
        navigate("/cliente");
        break;
      case "empleado_sucursal":
        navigate("/empleado");
        break;
      case "coordinador_flotas":
        navigate("/coordinador");
        break;
      case "personal_mantenimiento":
        navigate("/mantenimiento");
        break;
      case "admin":
        navigate("/admin");
        break;
      default:
        navigate("/login");
    }
  };

  return (
    <div className="container">
      <div className="box">
        <div className="form-container login">
          <h2>Iniciar sesión</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Correo"
              required
            />
            <input
              type="password"
              value={contrasena}
              onChange={(e) => setContrasena(e.target.value)}
              placeholder="Contraseña"
              required
            />
            <button type="submit">Ingresar</button>
          </form>
        </div>
        <div className="switch">
          <h2>¿Nuevo en Herz?</h2>
          <p>Registrate para comenzar tu viaje</p>
          <button onClick={() => navigate("/register")}>Crear cuenta</button>
        </div>
      </div>
    </div>
  );
};

export default Login;