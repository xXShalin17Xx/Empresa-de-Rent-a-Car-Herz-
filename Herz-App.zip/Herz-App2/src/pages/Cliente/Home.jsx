import "../../styles/principal.css";
import { useEffect, useState } from "react";
import { getVehiculosSucursal } from "../../services/api";

const ClienteHome = () => {
  const [sucursales, setSucursales] = useState([]);

  useEffect(() => {
    const cargar = async () => {
      const data = await getVehiculosSucursal(); // función válida en api.js
      setSucursales(data);
    };
    cargar();
  }, []);

  return (
    <section className="sucursales-home">
      <h2>Bienvenido a Herz</h2>
      <p className="subtitulo">Seleccioná una sucursal para comenzar tu reserva</p>
      <div className="sucursal-grid">
        {sucursales.map((s) => (
          <div key={s.id} className="sucursal-card">
            <h3>{s.nombre}</h3>
            <p>{s.direccion}</p>
            <p>{s.telefono}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ClienteHome;