import "../../styles/principal.css";
import { useEffect, useState } from "react";
import { getAlquileresCliente } from "../../services/api";

const HistorialAlquileres = () => {
  const [historial, setHistorial] = useState([]);

  useEffect(() => {
    const cargar = async () => {
      const data = await getAlquileresCliente();
      setHistorial(data);
    };
    cargar();
  }, []);

  return (
    <div className="reservas-container">
      <h2>Historial de alquileres</h2>
      {historial.length === 0 ? (
        <p>No hay historial disponible.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Vehículo</th>
              <th>Inicio</th>
              <th>Fin</th>
              <th>Sucursal</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {historial.map((h) => (
              <tr key={h.id}>
                <td>{h.vehiculo}</td>
                <td>{h.fechaInicio}</td>
                <td>{h.fechaFin}</td>
                <td>{h.sucursal}</td>
                <td>{h.estado}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default HistorialAlquileres;