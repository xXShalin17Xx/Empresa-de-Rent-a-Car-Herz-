import "../../styles/principal.css";
import { useEffect, useState } from "react";
import { getReservas } from "../../services/api";

const MisReservas = () => {
  const [reservas, setReservas] = useState([]);

  useEffect(() => {
    const cargar = async () => {
      const data = await getReservas();
      setReservas(data);
    };
    cargar();
  }, []);

  return (
    <div className="reservas-container">
      <h2>Mis reservas</h2>
      {reservas.length === 0 ? (
        <p>No tenés reservas activas.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Vehículo</th>
              <th>Inicio</th>
              <th>Fin</th>
              <th>Sucursal</th>
            </tr>
          </thead>
          <tbody>
            {reservas.map((r) => (
              <tr key={r.id}>
                <td>{r.vehiculo}</td>
                <td>{r.fechaInicio}</td>
                <td>{r.fechaFin}</td>
                <td>{r.sucursal}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default MisReservas;