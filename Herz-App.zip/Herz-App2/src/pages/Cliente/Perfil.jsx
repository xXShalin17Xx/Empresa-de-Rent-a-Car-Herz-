import "../../styles/perfil.css";
import { useEffect, useState } from "react";
import { getPerfil } from "../../services/api";
import { useNavigate } from "react-router-dom";

const Perfil = () => {
  const [perfil, setPerfil] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const cargarPerfil = async () => {
      const data = await getPerfil();
      setPerfil(data);
    };
    cargarPerfil();
  }, []);

  return (
    <>
      <header className="main-header">
        <a href="/" className="logo">Herz</a>
        <div className="center">
          <h1>Mi perfil</h1>
        </div>
        <div className="right">
          <div className="perfil-dropdown">
            <img src="/img/perfil.jpg" alt="Perfil" className="perfil-icono" />
            <div className="menu-dropdown">
              <span>{perfil?.nombre}</span>
              <a href="/logout">Cerrar sesión</a>
            </div>
          </div>
        </div>
      </header>

      <div className="perfil-container">
        <h2>Información personal</h2>
        <div className="perfil-box">
          <p><strong>Nombre:</strong> {perfil?.nombre}</p>
          <p><strong>Email:</strong> {perfil?.email}</p>
          <p><strong>DNI:</strong> {perfil?.dni}</p>
          <p><strong>Licencia:</strong> {perfil?.licencia}</p>
          <p><strong>Teléfono:</strong> {perfil?.telefono}</p>
          <a className="btn-reservas" href="/cliente">Volver</a>
          <a className="btn-cerrar" href="/logout">Cerrar sesión</a>
        </div>
      </div>
    </>
  );
};

export default Perfil;