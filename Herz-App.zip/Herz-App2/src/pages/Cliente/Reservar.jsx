import "../../styles/principal.css";
import { useState } from "react";
import { crearReserva } from "../../services/api";

const Reservar = () => {
  const [form, setForm] = useState({
    tipo: "",
    fechaInicio: "",
    fechaFin: "",
    sucursal: "",
    comentarios: "",
  });
  const [mensaje, setMensaje] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await crearReserva(form);
    setMensaje("Reserva realizada correctamente");
  };

  return (
    <div className="reservas-container">
      <h2>Reservar vehículo</h2>
      {mensaje && <div className="alert success">{mensaje}</div>}
      <form className="reservas-form" onSubmit={handleSubmit}>
        <label>Tipo de vehículo</label>
        <select name="tipo" onChange={handleChange} required>
          <option value="">Seleccionar</option>
          <option value="auto">Auto</option>
          <option value="camioneta">Camioneta</option>
          <option value="electrico">Eléctrico</option>
        </select>

        <label>Fecha inicio</label>
        <input type="date" name="fechaInicio" onChange={handleChange} required />

        <label>Fecha fin</label>
        <input type="date" name="fechaFin" onChange={handleChange} required />

        <label>Sucursal</label>
        <input type="text" name="sucursal" onChange={handleChange} required />

        <label>Comentarios</label>
        <textarea name="comentarios" onChange={handleChange} />

        <button type="submit">Reservar</button>
      </form>
    </div>
  );
};

export default Reservar;