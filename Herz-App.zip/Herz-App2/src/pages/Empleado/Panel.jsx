import "../../styles/panel_empleado.css";
import { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar";
import {
  getReservasActivas,
  confirmarRetiro,
  registrarDevolucion,
} from "../../services/api";

const EmpleadoHome = () => {
  const [reservas, setReservas] = useState([]);
  const [mensaje, setMensaje] = useState("");

  const cargar = async () => {
    try {
      const res = await getReservasActivas();
      setReservas(res.data || []);
    } catch (error) {
      setMensaje("Error al cargar reservas");
    }
  };

  useEffect(() => {
    cargar();
  }, []);

  const handleRetiro = async (idReserva, idVehiculo) => {
    try {
      await confirmarRetiro(idReserva, idVehiculo);
      setMensaje("Retiro confirmado");
      cargar();
    } catch {
      setMensaje("Error al confirmar retiro");
    }
  };

  const handleDevolucion = async (idReserva) => {
    try {
      await registrarDevolucion(idReserva);
      setMensaje("Devolución registrada");
      cargar();
    } catch {
      setMensaje("Error al registrar devolución");
    }
  };

  return (
    <>
      <Sidebar />
      <main>
        <header>
          <h1>Panel de reservas activas</h1>
        </header>
        <section>
          {mensaje && <p className="mensaje">{mensaje}</p>}
          {reservas.length === 0 ? (
            <p>No hay reservas activas.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Vehículo</th>
                  <th>Tipo</th>
                  <th>Inicio</th>
                  <th>Fin</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {reservas.map((r) => (
                  <tr key={r.id}>
                    <td>{r.vehiculo}</td>
                    <td>{r.tipoVehiculo}</td>
                    <td>{r.fechaInicio}</td>
                    <td>{r.fechaFin}</td>
                    <td>
                      <button className="btn" onClick={() => handleRetiro(r.id, r.vehiculoId)}>
                        Confirmar retiro
                      </button>
                      <button className="btn" onClick={() => handleDevolucion(r.id)}>
                        Registrar devolución
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </>
  );
};

export default EmpleadoHome;