import "../../styles/all.css";
import { useEffect, useState } from "react";
import {
  getVehiculosSucursal,
  crearMantenimiento,
  getDisponibilidadVehiculos,
} from "../../services/api";
import Sidebar from "../../components/Sidebar";

const CoordinadorHome = () => {
  const [vehiculos, setVehiculos] = useState([]);
  const [disponibles, setDisponibles] = useState([]);
  const [mensaje, setMensaje] = useState("");

  const cargar = async () => {
    const v = await getVehiculosSucursal();
    const d = await getDisponibilidadVehiculos();
    setVehiculos(v);
    setDisponibles(d);
  };

  useEffect(() => {
    cargar();
  }, []);

  const asignarMantenimiento = async (idVehiculo) => {
    await crearMantenimiento({ idVehiculo });
    setMensaje("Mantenimiento asignado");
    cargar();
  };

  return (
    <>
      <Sidebar />
      <main>
        <header>
          <h1>Gestión de flota</h1>
        </header>
        {mensaje && <div className="alert success">{mensaje}</div>}

        <section>
          <h2>Vehículos por sucursal</h2>
          <table>
            <thead>
              <tr>
                <th>Modelo</th>
                <th>Tipo</th>
                <th>Estado</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody>
              {vehiculos.map((v) => (
                <tr key={v.id}>
                  <td>{v.modelo}</td>
                  <td>{v.tipo}</td>
                  <td>{v.estado}</td>
                  <td>
                    <button className="action-btn" onClick={() => asignarMantenimiento(v.id)}>
                      Asignar mantenimiento
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section>
          <h2>Disponibilidad actual</h2>
          <ul>
            {disponibles.map((v) => (
              <li key={v.id}>{v.modelo} - Disponible</li>
            ))}
          </ul>
        </section>
      </main>
    </>
  );
};

export default CoordinadorHome;