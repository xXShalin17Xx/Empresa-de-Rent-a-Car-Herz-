import "../../styles/all.css";
import { useEffect, useState } from "react";
import {
  getMantenimientosPendientes,
  completarMantenimiento,
} from "../../services/api";
import Sidebar from "../../components/Sidebar";

const MantenimientoHome = () => {
  const [pendientes, setPendientes] = useState([]);
  const [mensaje, setMensaje] = useState("");

  const cargar = async () => {
    const res = await getMantenimientosPendientes();
    setPendientes(res);
  };

  useEffect(() => {
    cargar();
  }, []);

  const completar = async (id) => {
    await completarMantenimiento(id);
    setMensaje("Mantenimiento completado");
    cargar();
  };

  return (
    <>
      <Sidebar />
      <main>
        <header>
          <h1>Órdenes de mantenimiento</h1>
        </header>
        {mensaje && <div className="alert success">{mensaje}</div>}
        <section>
          {pendientes.length === 0 ? (
            <p>No hay órdenes pendientes.</p>
          ) : (
            <ul>
              {pendientes.map((m) => (
                <li key={m.id}>
                  Vehículo: {m.vehiculo} - Estado: {m.estado}
                  <button className="action-btn" onClick={() => completar(m.id)}>
                    Completar
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </>
  );
};

export default MantenimientoHome;