import "../styles/login.css";
import { useState } from "react";
import { register } from "../services/api";
import { useNavigate } from "react-router-dom";

const Registro = () => {
  const [form, setForm] = useState({
    nombre: "",
    dni: "",
    licencia: "",
    email: "",
    telefono: "",
    contrasena: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(form);
      navigate("/login");
    } catch (err) {
      console.error('Register error:', err);
      // Axios error details
      if (err?.response) {
        console.error('response data:', err.response.data);
        alert('Error del servidor: ' + (err.response.data?.message || err.response.status));
      } else if (err?.request) {
        alert('No hubo respuesta del servidor. Verifica que el backend esté iniciado en http://localhost:8080');
      } else {
        alert('Error: ' + err.message);
      }
    }
  };

  return (
    <div className="container register-mode">
      <div className="box">
        <div className="switch">
          <h2>¿Ya tenés cuenta?</h2>
          <p>Iniciá sesión para continuar</p>
          <button onClick={() => navigate("/login")}>Volver al login</button>
        </div>
        <div className="form-container register">
          <h2>Registro</h2>
          <form onSubmit={handleSubmit}>
            <input name="nombre" placeholder="Nombre" onChange={handleChange} required />
            <input name="dni" placeholder="DNI" onChange={handleChange} required />
            <input name="licencia" placeholder="Licencia" onChange={handleChange} required />
            <input name="email" type="email" placeholder="Correo" onChange={handleChange} required />
            <input name="telefono" placeholder="Teléfono" onChange={handleChange} required />
            <input name="contrasena" type="password" placeholder="Contraseña" onChange={handleChange} required />
            <button type="submit">Crear cuenta</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Registro;