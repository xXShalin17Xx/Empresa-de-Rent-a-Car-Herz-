import "../styles/principal.css";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();

  return (
    <>
      <header className="main-header">
        <div className="logo"><a href="../frontend/src/assets/img/logo.png">Herz</a></div>
        <h1>Alquiler de vehículos</h1>
        <nav>
          <a href="/login">Ingresar</a>
          <a href="/register">Registrarse</a>
        </nav>
      </header>

      <section className="hero">
        <div className="title-row">
          <h2>Tu viaje comienza aquí</h2>
        </div>
        <p className="descripcion-tipo">
          Elegí el tipo de vehículo que se adapta a tus necesidades y reservá en segundos.
        </p>
        <div className="filters">
          <button onClick={() => navigate("/login")}>Autos</button>
          <button onClick={() => navigate("/login")}>Camionetas</button>
          <button onClick={() => navigate("/login")}>Eléctricos</button>
        </div>
      </section>
    </>
  );
};

export default Home;