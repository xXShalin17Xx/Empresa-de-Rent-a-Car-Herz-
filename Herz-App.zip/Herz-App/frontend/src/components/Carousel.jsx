import React, { useEffect, useState } from 'react';
import './Carousel.css';

const Carousel = ({ slides }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [visibleSlides, setVisibleSlides] = useState(slides);
  const [autoplay, setAutoplay] = useState(true);

  useEffect(() => {
    if (autoplay) {
      const timer = setInterval(() => next(), 4000);
      return () => clearInterval(timer);
    }
  }, [currentIndex, visibleSlides, autoplay]);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % visibleSlides.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + visibleSlides.length) % visibleSlides.length);
  };

  const filtrar = (tipo) => {
    if (!tipo || tipo === 'all') {
      setVisibleSlides(slides);
    } else {
      setVisibleSlides(slides.filter(s => s.tipo === tipo));
    }
    setCurrentIndex(0);
  };

  return (
    <div className="carousel-wrapper" onMouseEnter={() => setAutoplay(false)} onMouseLeave={() => setAutoplay(true)}>
      <button onClick={prev}>&lsaquo;</button>
      <div className="carousel">
        {visibleSlides.length > 0 && (
          <div className="slide">
            <img src={visibleSlides[currentIndex].img} alt={visibleSlides[currentIndex].titulo} />
            <div className="caption">{visibleSlides[currentIndex].descripcion}</div>
          </div>
        )}
      </div>
      <button onClick={next}>&rsaquo;</button>
      <div className="carousel-dots">
        {visibleSlides.map((_, i) => (
          <button key={i} className={i === currentIndex ? 'active' : ''} onClick={() => setCurrentIndex(i)} />
        ))}
      </div>
      <div className="filters">
        <button onClick={() => filtrar('all')}>Todos</button>
        <button onClick={() => filtrar('economico')}>Económicos</button>
        <button onClick={() => filtrar('electrico')}>Eléctricos</button>
        <button onClick={() => filtrar('suv')}>SUV</button>
        <button onClick={() => filtrar('lujo')}>De Lujo</button>
      </div>
    </div>
  );
};

export default Carousel;