import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:8080/api',
});

export const login = (email, password) => API.post('/auth/login', { email, password });
export const register = (data) => API.post('/auth/register', data);
export const getPerfil = () => API.get('/clientes/me');
export const getReservas = () => API.get('/reservas');
export const crearReserva = (data) => API.post('/reservas', data);
export const confirmarRetiro = (idReserva, idVehiculo) => API.post(`/alquileres/confirmar`, { idReserva, idVehiculo });