package com.herz.tests.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herz.controllers.AuthController;
import com.herz.dtos.AuthRequest;
import com.herz.dtos.AuthResponse;
import com.herz.repositories.ClienteRepository;
import com.herz.security.JwtUtil;
import com.herz.services.AuthService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private ClienteRepository clienteRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void login_credencialesValidas_retornaTokenYDatos() throws Exception {
        // 🔹 Arrange
        AuthRequest request = new AuthRequest();
        request.email = "usuario@herz.com";
        request.contrasena = "123456";

        AuthResponse response = new AuthResponse("mocked.jwt.token", 1L, "usuario@herz.com", "cliente");

        Mockito.when(authService.login(any())).thenReturn(response);

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("mocked.jwt.token"))
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("usuario@herz.com"))
                .andExpect(jsonPath("$.rol").value("cliente"));
    }

    @Test
    void login_credencialesInvalidas_retornaError() throws Exception {
        // 🔹 Arrange
        AuthRequest request = new AuthRequest();
        request.email = "usuario@herz.com";
        request.contrasena = "wrongpass";

        Mockito.when(authService.login(any())).thenThrow(new RuntimeException("Contraseña incorrecta"));

        // 🔹 Act & Assert
        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Contraseña incorrecta"));
    }
}