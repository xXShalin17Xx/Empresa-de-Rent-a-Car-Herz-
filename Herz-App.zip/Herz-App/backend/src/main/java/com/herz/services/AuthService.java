package com.herz.services;

import com.herz.dtos.AuthRequest;
import com.herz.dtos.AuthResponse;
import com.herz.models.Cliente;
import com.herz.repositories.ClienteRepository;
import com.herz.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthResponse login(AuthRequest request) {
        Cliente cliente = clienteRepository.findByEmail(request.email)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (!cliente.getContrasena().equals(request.contrasena)) {
            throw new RuntimeException("Contraseña incorrecta");
        }

        String token = jwtUtil.generateToken(cliente.getId(), cliente.getEmail(), cliente.getRol().getNombre());
        return new AuthResponse(token, cliente.getId(), cliente.getEmail(), cliente.getRol().getNombre());
    }
}