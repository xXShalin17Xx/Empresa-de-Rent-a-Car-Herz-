package com.herz.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {

    private final String secret = "claveSecreta123";
    private final long expiration = 1000 * 60 * 60 * 24;

    public String generateToken(Long id, String email, String rol) {
        return Jwts.builder()
            .setSubject(email)
            .claim("id", id)
            .claim("rol", rol)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + expiration))
            .signWith(SignatureAlgorithm.HS256, secret)
            .compact();
    }
}