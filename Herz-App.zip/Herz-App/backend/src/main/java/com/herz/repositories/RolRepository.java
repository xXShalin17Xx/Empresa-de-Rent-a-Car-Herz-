package main.java.com.herz.repositories;

public class RolRepository {
    
}
