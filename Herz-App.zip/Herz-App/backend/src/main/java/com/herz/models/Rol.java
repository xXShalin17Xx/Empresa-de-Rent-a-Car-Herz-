public class Rol {
    
}
