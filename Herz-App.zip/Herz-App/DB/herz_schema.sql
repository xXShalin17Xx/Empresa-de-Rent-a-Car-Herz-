-- Crear base de datos
CREATE DATABASE IF NOT EXISTS Herz;
USE Herz;

-- Tabla de roles
CREATE TABLE Roles (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

-- Tabla de sucursales
CREATE TABLE Sucursales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(150),
    telefono VARCHAR(20)
);

-- Tabla de clientes
CREATE TABLE Clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    dni VARCHAR(15) NOT NULL UNIQUE,
    licencia VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    telefono VARCHAR(20),
    contrasena VARCHAR(255) NOT NULL,
    idRol INT DEFAULT 1,  -- Por defecto, cliente
    idSucursal INT NULL,  -- Solo aplica a empleados
    FOREIGN KEY (idRol) REFERENCES Roles(id),
    FOREIGN KEY (idSucursal) REFERENCES Sucursales(id)
);


-- Tabla de vehículos
CREATE TABLE Vehiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patente VARCHAR(10) NOT NULL UNIQUE,
    modelo VARCHAR(50),
    tipo VARCHAR(50), 
    estado ENUM('disponible', 'alquilado', 'mantenimiento') DEFAULT 'disponible',
    idSucursal INT,
    kilometraje DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (idSucursal) REFERENCES Sucursales(id)
);

-- Tabla de reservas
CREATE TABLE Reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('pendiente', 'en curso', 'finalizada', 'cancelada') DEFAULT 'pendiente',
    idCliente INT,
    tipoVehiculo VARCHAR(50), 
    fechaInicio DATE,
    fechaFin DATE,
    FOREIGN KEY (idCliente) REFERENCES Clientes(id),
    CHECK (fechaInicio <= fechaFin)
);

-- Tabla de alquileres (modificada según tu instrucción)
CREATE TABLE Alquileres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idReserva INT,
    fechaRetiro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fechaDevolucion TIMESTAMP NULL,
    kmInicial DECIMAL(10,2),
    kmFinal DECIMAL(10,2),
    idVehiculo INT,
    FOREIGN KEY (idReserva) REFERENCES Reservas(id) ON DELETE CASCADE,
    FOREIGN KEY (idVehiculo) REFERENCES Vehiculos(id)
);

-- Tabla de mantenimiento
CREATE TABLE Mantenimiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idVehiculo INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tipo VARCHAR(50), -- ej: cambio de aceite, revisión, etc.
    costo DECIMAL(10,2),
    estado ENUM('pendiente', 'completado') DEFAULT 'pendiente',
    FOREIGN KEY (idVehiculo) REFERENCES Vehiculos(id)
);




INSERT INTO Roles (id, nombre) VALUES
(1, 'cliente'),
(2, 'empleado_sucursal'),
(3, 'coordinador_flotas'),
(4, 'personal_mantenimiento'),
(5, 'admin');



-- para cambiar los roles de los usuarios manualmente
UPDATE Clientes
SET idRol = 3
WHERE id = 5;

--  Económicos
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('AB123CD', 'Toyota Yaris', 'Económico', 'disponible', 1, 25300.75),
('CD234EF', 'Hyundai i10', 'Económico', 'disponible', 1, 18750.20),
('EF345GH', 'Kia Picanto', 'Económico', 'mantenimiento', 1, 32100.50),
('GH456IJ', 'Chevrolet Spark', 'Económico', 'disponible', 1, 29450.10),
('IJ567KL', 'Nissan March', 'Económico', 'alquilado', 1, 36890.00);

--  Eléctricos
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('EL101AA', 'Tesla Model 3', 'Eléctrico', 'disponible', 1, 10500.00),
('EL202BB', 'Nissan Leaf', 'Eléctrico', 'disponible', 1, 8800.30),
('EL303CC', 'BMW i3', 'Eléctrico', 'alquilado', 1, 7600.00),
('EL404DD', 'Renault Zoe', 'Eléctrico', 'disponible', 1, 4950.70),
('EL505EE', 'Hyundai Kona Electric', 'Eléctrico', 'mantenimiento', 1, 6200.40);

--  SUV
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('SUV111AA', 'Toyota RAV4', 'SUV', 'disponible', 1, 45000.00),
('SUV222BB', 'Ford Escape', 'SUV', 'disponible', 1, 39200.55),
('SUV333CC', 'Honda CR-V', 'SUV', 'alquilado', 1, 41750.90),
('SUV444DD', 'Kia Sportage', 'SUV', 'mantenimiento', 1, 46230.20),
('SUV555EE', 'Hyundai Tucson', 'SUV', 'disponible', 1, 38500.00);

--  De lujo
INSERT INTO Vehiculos (patente, modelo, tipo, estado, idSucursal, kilometraje) VALUES
('LUX111AA', 'Mercedes-Benz C-Class', 'De lujo', 'disponible', 1, 21400.00),
('LUX222BB', 'BMW 5 Series', 'De lujo', 'disponible', 1, 19850.00),
('LUX333CC', 'Audi A6', 'De lujo', 'alquilado', 1, 23500.80),
('LUX444DD', 'Lexus ES 350', 'De lujo', 'disponible', 1, 17200.10),
('LUX555EE', 'Jaguar XF', 'De lujo', 'mantenimiento', 1, 26500.65);

-- sucursales
INSERT INTO Sucursales (nombre, direccion, telefono) VALUES
('Sucursal Palermo', 'Av. Santa Fe 3456, Palermo, CABA', '011-4321-1000'),
('Sucursal Caballito', 'Av. Rivadavia 5400, Caballito, CABA', '011-4321-1001'),
('Sucursal Belgrano', 'Juramento 2345, Belgrano, CABA', '011-4321-1002'),
('Sucursal Recoleta', 'Av. Callao 1500, Recoleta, CABA', '011-4321-1003'),
('Sucursal Constitución', 'Lima 800, Constitución, CABA', '011-4321-1004');


--1
DELIMITER //

CREATE PROCEDURE sp_CrearReserva (IN p_idCliente INT, IN p_tipoVehiculo VARCHAR(50), IN p_fechaInicio DATE, IN p_fechaFin DATE)
BEGIN
    INSERT INTO Reservas (idCliente, tipoVehiculo, fechaInicio, fechaFin)
    VALUES (p_idCliente, p_tipoVehiculo, p_fechaInicio, p_fechaFin);
END //

DELIMITER ;

---2
DELIMITER //

CREATE PROCEDURE sp_RegistrarDevolucion (IN p_idAlquiler INT, IN p_kmFinal DECIMAL(10,2))
BEGIN
    UPDATE Alquileres SET fechaDevolucion = NOW(), kmFinal = p_kmFinal WHERE id = p_idAlquiler;

    UPDATE Vehiculos 
    SET estado = 'disponible' 
    WHERE id = (SELECT idVehiculo FROM Alquileres WHERE id = p_idAlquiler);

    UPDATE Reservas 
    SET estado = 'finalizada' 
    WHERE id = (SELECT idReserva FROM Alquileres WHERE id = p_idAlquiler);
END //

DELIMITER ;

--3 
DELIMITER //

CREATE PROCEDURE sp_reporteOcupacion()
BEGIN
    SELECT estado, COUNT(*) AS cantidad FROM Vehiculos GROUP BY estado;
END //

DELIMITER ;

--4
DELIMITER //

CREATE PROCEDURE sp_AsignarVehiculoAReserva (IN p_idReserva INT, IN p_idVehiculo INT)
BEGIN
    DECLARE v_tipoVehiculo VARCHAR(50);

    IF (SELECT estado FROM Vehiculos WHERE id = p_idVehiculo) != 'disponible' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El vehículo no está disponible';
    END IF;

    INSERT INTO Alquileres (idReserva, idVehiculo, kmInicial)
    VALUES (p_idReserva, p_idVehiculo, (SELECT kilometraje FROM Vehiculos WHERE id = p_idVehiculo));

    UPDATE Vehiculos SET estado = 'alquilado' WHERE id = p_idVehiculo;

    UPDATE Reservas SET estado = 'en curso' WHERE id = p_idReserva;
END //

DELIMITER ;

--5 
DELIMITER //

CREATE PROCEDURE sp_HistorialAlquileresPorCliente (IN p_idCliente INT)
BEGIN
    SELECT A.id AS alquiler_id, V.patente, V.modelo, A.fechaRetiro, A.fechaDevolucion, A.kmInicial, A.kmFinal
    FROM Alquileres A INNER JOIN Reservas R ON A.idReserva = R.id INNER JOIN Vehiculos V ON A.idVehiculo = V.id
    WHERE R.idCliente = p_idCliente
    ORDER BY A.fechaRetiro DESC;
END //

DELIMITER ;

--trg
DELIMITER //

CREATE TRIGGER trg_ActualizarEstadoVehiculo_AlRetirar
AFTER INSERT ON Alquileres
FOR EACH ROW
BEGIN
    UPDATE Vehiculos SET estado = 'alquilado' WHERE id = NEW.idVehiculo;
END //

DELIMITER ;

--2 
DELIMITER //

CREATE TRIGGER trg_ActualizarEstadoVehiculo_AlDevolver
AFTER UPDATE ON Alquileres
FOR EACH ROW
BEGIN
    IF NEW.fechaDevolucion IS NOT NULL AND OLD.fechaDevolucion IS NULL THEN
        UPDATE Vehiculos SET estado = 'disponible' WHERE id = NEW.idVehiculo;
    END IF;
END //

DELIMITER ;

--3
DELIMITER //

CREATE TRIGGER trg_RegistrarMantenimiento_Agregado
AFTER INSERT ON Mantenimiento
FOR EACH ROW
BEGIN
    UPDATE Vehiculos SET estado = 'mantenimiento' WHERE id = NEW.idVehiculo;
END //

DELIMITER ;

--4 
DELIMITER //

CREATE TRIGGER trg_FinalizarMantenimiento
AFTER UPDATE ON Mantenimiento
FOR EACH ROW
BEGIN
    IF NEW.estado = 'completado' AND OLD.estado != 'completado' THEN
        UPDATE Vehiculos SET estado = 'disponible' WHERE id = NEW.idVehiculo;
    END IF;
END //

DELIMITER ;
