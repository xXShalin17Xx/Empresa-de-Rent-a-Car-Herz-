-- V002_normalize_fk_bigint.sql
-- Propósito: unificar columnas camelCase -> snake_case y alinear PK/FK a BIGINT.
-- Requerimiento: tener respaldo previo (db/backup/herz.sql).

SET FOREIGN_KEY_CHECKS = 0;

-- 1) Asegurar columnas snake_case
ALTER TABLE `reservas`
  ADD COLUMN IF NOT EXISTS `id_cliente` BIGINT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `id_vehiculo` BIGINT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `id_sucursal` BIGINT DEFAULT NULL;

ALTER TABLE `alquileres`
  ADD COLUMN IF NOT EXISTS `id_reserva` BIGINT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `id_vehiculo` BIGINT DEFAULT NULL;

ALTER TABLE `vehiculos`
  ADD COLUMN IF NOT EXISTS `id_sucursal` BIGINT DEFAULT NULL;

-- 2) Copiar datos desde camelCase solo cuando exista la columna origen y destino está NULL
-- reservas
SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='idCliente');
IF @has_src = 1 THEN
  UPDATE `reservas` SET `id_cliente` = `idCliente` WHERE `id_cliente` IS NULL AND `idCliente` IS NOT NULL;
END IF;

SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='idVehiculo');
IF @has_src = 1 THEN
  UPDATE `reservas` SET `id_vehiculo` = `idVehiculo` WHERE `id_vehiculo` IS NULL AND `idVehiculo` IS NOT NULL;
END IF;

SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='reservas' AND COLUMN_NAME='idSucursal');
IF @has_src = 1 THEN
  UPDATE `reservas` SET `id_sucursal` = `idSucursal` WHERE `id_sucursal` IS NULL AND `idSucursal` IS NOT NULL;
END IF;

-- alquileres
SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='alquileres' AND COLUMN_NAME='idReserva');
IF @has_src = 1 THEN
  UPDATE `alquileres` SET `id_reserva` = `idReserva` WHERE `id_reserva` IS NULL AND `idReserva` IS NOT NULL;
END IF;

SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='alquileres' AND COLUMN_NAME='idVehiculo');
IF @has_src = 1 THEN
  UPDATE `alquileres` SET `id_vehiculo` = `idVehiculo` WHERE `id_vehiculo` IS NULL AND `idVehiculo` IS NOT NULL;
END IF;

-- vehiculos
SET @has_src := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='vehiculos' AND COLUMN_NAME='idSucursal');
IF @has_src = 1 THEN
  UPDATE `vehiculos` SET `id_sucursal` = `idSucursal` WHERE `id_sucursal` IS NULL AND `idSucursal` IS NOT NULL;
END IF;

-- 3) Eliminar columnas camelCase existentes (solo si existen)
-- Generar y ejecutar dinámicamente los ALTERs (si no soporta PREPARE en tu entorno, ejecuta manualmente)
SELECT GROUP_CONCAT(CONCAT('ALTER TABLE `', TABLE_NAME, '` DROP COLUMN `', COLUMN_NAME, '`') SEPARATOR '; ')
INTO @drops
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND ((TABLE_NAME='reservas' AND COLUMN_NAME IN ('idCliente','idVehiculo','idSucursal'))
    OR (TABLE_NAME='alquileres' AND COLUMN_NAME IN ('idReserva','idVehiculo'))
    OR (TABLE_NAME='vehiculos' AND COLUMN_NAME = 'idSucursal'));

IF @drops IS NOT NULL THEN
  PREPARE stmt FROM @drops;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END IF;

-- 4) Alinear PKs a BIGINT
ALTER TABLE `sucursales`    MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `clientes`      MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `vehiculos`     MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `reservas`      MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `alquileres`    MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `mantenimiento` MODIFY COLUMN `id` BIGINT AUTO_INCREMENT;
ALTER TABLE `roles`         MODIFY COLUMN `id` BIGINT;

-- 5) Alinear columnas FK a BIGINT (snake_case finales)
ALTER TABLE `reservas`   MODIFY COLUMN `id_cliente` BIGINT;
ALTER TABLE `reservas`   MODIFY COLUMN `id_vehiculo` BIGINT;
ALTER TABLE `reservas`   MODIFY COLUMN `id_sucursal` BIGINT;

ALTER TABLE `alquileres` MODIFY COLUMN `id_reserva` BIGINT;
ALTER TABLE `alquileres` MODIFY COLUMN `id_vehiculo` BIGINT;

ALTER TABLE `vehiculos`  MODIFY COLUMN `id_sucursal` BIGINT;
ALTER TABLE `mantenimiento` MODIFY COLUMN `id_vehiculo` BIGINT;

-- 6) Crear índices y FKs (si no existen, los ADD fallarán y se ignoran manualmente)
-- Nota: algunos servidores no soportan IF NOT EXISTS en ADD CONSTRAINT; en ese caso
-- ejecutar y si da "Duplicate" ignorar.
ALTER TABLE `reservas`
  ADD INDEX IF NOT EXISTS `idx_reservas_id_cliente` (id_cliente),
  ADD INDEX IF NOT EXISTS `idx_reservas_id_vehiculo` (id_vehiculo),
  ADD INDEX IF NOT EXISTS `idx_reservas_id_sucursal` (id_sucursal);

ALTER TABLE `alquileres`
  ADD INDEX IF NOT EXISTS `idx_alq_id_reserva` (id_reserva),
  ADD INDEX IF NOT EXISTS `idx_alq_id_vehiculo` (id_vehiculo);

ALTER TABLE `clientes`
  ADD CONSTRAINT IF NOT EXISTS `fk_clientes_rol`       FOREIGN KEY (`idRol`)      REFERENCES `roles`(`id`),
  ADD CONSTRAINT IF NOT EXISTS `fk_clientes_sucursal` FOREIGN KEY (`idSucursal`) REFERENCES `sucursales`(`id`);

ALTER TABLE `vehiculos`
  ADD CONSTRAINT IF NOT EXISTS `fk_vehiculos_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursales`(`id`);

ALTER TABLE `reservas`
  ADD CONSTRAINT IF NOT EXISTS `fk_reservas_cliente`  FOREIGN KEY (`id_cliente`)  REFERENCES `clientes`(`id`),
  ADD CONSTRAINT IF NOT EXISTS `fk_reservas_vehiculo` FOREIGN KEY (`id_vehiculo`) REFERENCES `vehiculos`(`id`),
  ADD CONSTRAINT IF NOT EXISTS `fk_reservas_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursales`(`id`);

ALTER TABLE `alquileres`
  ADD CONSTRAINT IF NOT EXISTS `fk_alquileres_reserva`  FOREIGN KEY (`id_reserva`)  REFERENCES `reservas`(`id`) ON DELETE CASCADE,
  ADD CONSTRAINT IF NOT EXISTS `fk_alquileres_vehiculo` FOREIGN KEY (`id_vehiculo`) REFERENCES `vehiculos`(`id`);

ALTER TABLE `mantenimiento`
  ADD CONSTRAINT IF NOT EXISTS `fk_mantenimiento_vehiculo` FOREIGN KEY (`id_vehiculo`) REFERENCES `vehiculos`(`id`);

SET FOREIGN_KEY_CHECKS = 1;