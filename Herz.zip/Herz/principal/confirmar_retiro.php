<?php
include("../principal/config.php");
session_start();

// Solo empleados y admin pueden acceder
/*$rolesPermitidos = [2, 5]; // 2 = empleado, 5 = admin
if (!isset($_SESSION['cliente_id']) || !isset($_SESSION['cliente_rol']) || !in_array($_SESSION['cliente_rol'], $rolesPermitidos)) {
    header("Location: ../Sesion/login.php");
    exit();
}*/

// Consulta reservas pendientes incluyendo sucursal y vehículos disponibles
$sql = "
    SELECT R.id AS idReserva, C.nombre, C.email, R.tipoVehiculo, R.fechaInicio, R.fechaFin, 
           S.nombre AS sucursal, V.modelo, V.patente
    FROM Reservas R
    INNER JOIN Clientes C ON R.idCliente = C.id
    INNER JOIN Sucursales S ON R.idSucursal = S.id
    LEFT JOIN Vehiculos V ON V.tipo = R.tipoVehiculo AND V.idSucursal = R.idSucursal
    WHERE R.estado = 'pendiente'
    ORDER BY R.fechaInicio ASC
";

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Pendientes - Herz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="principal.css">
</head>
<body>

<header class="main-header">
    <div class="left"><a href="../usuarios/empleado_home.php" class="logo">Herz</a></div>
    <div class="center"><h1>Reservas Pendientes</h1></div>
</header>

<main>
    <h2>Reservas en espera de confirmación</h2>

    <?php if ($resultado->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID Reserva</th>
                    <th>Cliente</th>
                    <th>Email</th>
                    <th>Tipo Vehículo</th>
                    <th>Sucursal</th>
                    <th>Modelo</th>
                    <th>Patente</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($reserva = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td><?= $reserva['idReserva'] ?></td>
                        <td><?= htmlspecialchars($reserva['nombre']) ?></td>
                        <td><?= htmlspecialchars($reserva['email']) ?></td>
                        <td><?= ucfirst($reserva['tipoVehiculo']) ?></td>
                        <td><?= htmlspecialchars($reserva['sucursal']) ?></td>
                        <td><?= htmlspecialchars($reserva['modelo'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($reserva['patente'] ?? '-') ?></td>
                        <td><?= $reserva['fechaInicio'] ?></td>
                        <td><?= $reserva['fechaFin'] ?></td>
                        <td>
                            <a class="btn" href="confirmar_retiro.php?idReserva=<?= $reserva['idReserva'] ?>">
                                Confirmar Retiro
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center;">No hay reservas pendientes.</p>
    <?php endif; ?>
</main>

</body>
</html>

<?php $conn->close(); ?>
