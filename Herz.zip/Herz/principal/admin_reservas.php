<?php
include("../principal/config.php");
session_start();

// Verificar si el empleado tiene sucursal asignada
$idSucursal = $_SESSION['cliente_idSucursal'] ?? null;
if (!$idSucursal) {
    die("No se ha asignado una sucursal a este empleado.");
}

// Consulta reservas pendientes de vehículos de su sucursal
$sql = "SELECT R.id AS idReserva, C.nombre, C.email, R.tipoVehiculo, R.fechaInicio, R.fechaFin, V.modelo, V.patente
        FROM Reservas R
        INNER JOIN Clientes C ON R.idCliente = C.id
        INNER JOIN Vehiculos V ON V.tipo = R.tipoVehiculo AND V.idSucursal = ?
        WHERE R.estado = 'pendiente'
        ORDER BY R.fechaInicio ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idSucursal);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Pendientes - Herz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="principal.css">
</head>
<body>

    <header class="main-header">
        <div class="left"><a href="../usuarios/empleado_home.php" class="logo">Herz</a></div>
        <div class="center"><h1>Reservas Pendientes</h1></div>
    </header>

    <main>
        <h2>Reservas en espera de confirmación</h2>

        <?php if ($resultado->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Reserva</th>
                        <th>Cliente</th>
                        <th>Email</th>
                        <th>Tipo Vehículo</th>
                        <th>Modelo</th>
                        <th>Patente</th>
                        <th>Fecha Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($reserva = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?= $reserva['idReserva'] ?></td>
                            <td><?= htmlspecialchars($reserva['nombre']) ?></td>
                            <td><?= htmlspecialchars($reserva['email']) ?></td>
                            <td><?= ucfirst($reserva['tipoVehiculo']) ?></td>
                            <td><?= htmlspecialchars($reserva['modelo']) ?></td>
                            <td><?= htmlspecialchars($reserva['patente']) ?></td>
                            <td><?= $reserva['fechaInicio'] ?></td>
                            <td><?= $reserva['fechaFin'] ?></td>
                            <td>
                                <a class="btn" href="confirmar_retiro.php?idReserva=<?= $reserva['idReserva'] ?>">
                                    Confirmar Retiro
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center;">No hay reservas pendientes para tu sucursal.</p>
        <?php endif; ?>
    </main>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
