<?php
session_start();
include("config.php");

// Verificar sesión
if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../Sesion/login.php");
    exit();
}

$idCliente = $_SESSION['cliente_id'];
$mensaje = '';

// 🔹 Cancelar reserva usando SP
if (isset($_GET['cancelar']) && is_numeric($_GET['cancelar'])) {
    $idReserva = $_GET['cancelar'];

    $stmtCancel = $conn->prepare("CALL sp_CancelarReserva(?, ?)");
    $stmtCancel->bind_param("ii", $idReserva, $idCliente);

    try {
        $stmtCancel->execute();
        $mensaje = "✅ Reserva cancelada correctamente.";
    } catch (mysqli_sql_exception $e) {
        $mensaje = "⚠️ " . $e->getMessage();
    }

    $stmtCancel->close();
    $conn->next_result(); // importante para liberar resultados de SP
}

// 🔹 Consultar reservas pendientes o confirmadas (directa, no hay SP para esto)
$sqlReservas = "SELECT 
    r.id AS idReserva,
    r.estado,
    r.fechaInicio,
    r.fechaFin,
    v.modelo,
    v.patente,
    s.nombre AS sucursal
FROM Reservas r
LEFT JOIN Vehiculos v ON r.idVehiculo = v.id
LEFT JOIN Sucursales s ON r.idSucursal = s.id
WHERE r.idCliente = ? AND r.estado IN ('pendiente','confirmada')
ORDER BY r.fechaInicio DESC";

$stmtReservas = $conn->prepare($sqlReservas);
$stmtReservas->bind_param("i", $idCliente);
$stmtReservas->execute();
$resultReservas = $stmtReservas->get_result();

// 🔹 Consultar historial de alquileres usando SP
$stmtAlquileres = $conn->prepare("CALL sp_HistorialAlquileresPorCliente(?)");
$stmtAlquileres->bind_param("i", $idCliente);
$stmtAlquileres->execute();
$resultAlquileres = $stmtAlquileres->get_result();
$stmtAlquileres->close();
$conn->next_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Reservas y Alquileres - Herz</title>
    <link rel="stylesheet" href="principal.css">
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: #f9f9f9; 
            margin: 0; 
        }

        header.main-header {
            background: #04926f;
            color: #fff;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header .logo { 
            color: white; 
            text-decoration: none; 
            font-size: 22px; 
            font-weight: bold; 
        }

        header .right a { 
            color: white; 
            margin-left: 15px; 
            text-decoration: none; 
        }

        h2 { 
            color: #04926f; 
            border-bottom: 2px solid #04926f; 
            padding-bottom: 5px; 
            text-align: center;
        }

        /* 🔹 Tablas más pequeñas y centradas */
        table {
            width: 80%;                
            max-width: 900px;          
            margin: 20px auto;         
            border-collapse: collapse;
            background: #fff;
            font-size: 14px;           
        }

        th, td {
            padding: 8px;              
            text-align: center;
            border: 1px solid #ccc;
        }

        th {
            background: #04926f;
            color: white;
            font-size: 15px;
        }

        tr:hover { 
            background: #f0f8f6; 
        }

        .btn-cancel {
            padding: 5px 10px;
            background: #d9534f;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 13px;
        }

        .btn-cancel:hover { 
            background: #c9302c; 
        }

        .message {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin: 15px auto;
            border-radius: 5px;
            text-align: center;
            width: 70%;
            max-width: 700px;
        }

        main.container {
            text-align: center;
            padding: 20px;
        }

        section {
            margin-bottom: 40px;
        }
    </style>
</head>
<body>

<header class="main-header">
    <div class="left"><a href="home.php" class="logo">Herz</a></div>
    <div class="center"><h1>Mis Reservas y Alquileres</h1></div>
    <div class="right">
        <a href="buscar_vehiculos.php">Buscar Vehículos</a>
        <a href="../Sesion/logout.php">Cerrar sesión</a>
    </div>
</header>

<main class="container">
    <?php if ($mensaje): ?>
        <p class="message"><?= htmlspecialchars($mensaje) ?></p>
    <?php endif; ?>

    <!-- 🔹 Reservas -->
    <section>
        <h2>Mis Reservas Pendientes o Confirmadas</h2>
        <?php if ($resultReservas->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Vehículo</th>
                    <th>Patente</th>
                    <th>Sucursal</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Estado</th>
                    <th>Acción</th>
                </tr>
                <?php while($reserva = $resultReservas->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($reserva['modelo'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($reserva['patente'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($reserva['sucursal'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($reserva['fechaInicio']) ?></td>
                        <td><?= htmlspecialchars($reserva['fechaFin']) ?></td>
                        <td><?= htmlspecialchars($reserva['estado']) ?></td>
                        <td>
                            <a href="?cancelar=<?= $reserva['idReserva'] ?>" class="btn-cancel"
                               onclick="return confirm('¿Seguro que desea cancelar esta reserva?');">
                                Cancelar
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No tenés reservas pendientes o confirmadas.</p>
        <?php endif; ?>
    </section>

    <!-- 🔹 Alquileres -->
    <section>
        <h2>Mis Alquileres</h2>
        <?php if ($resultAlquileres->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Vehículo</th>
                    <th>Patente</th>
                    <th>Sucursal</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Estado</th>
                    <th>Comprobante</th>
                </tr>
                <?php while($alq = $resultAlquileres->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($alq['modelo'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($alq['patente'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($alq['sucursal'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($alq['fechaRetiro'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($alq['fechaDevolucion'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($alq['estadoReserva'] ?? '-') ?></td>
                        <td>
                            <a href="comprobante.php?id=<?= $alq['idAlquiler'] ?>">Descargar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No tenés alquileres registrados.</p>
        <?php endif; ?>
    </section>
</main>

</body>
</html>
